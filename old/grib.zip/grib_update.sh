#!/bin/bash

cd /gip/tools/mchs_grib
echo >> grib_update.log
echo START $(date) >> grib_update.log
## set vars
# today="$(date +%Y%m%d)00"

# h_now=$(date --date="$(date) - 5 hours" '+%H' | sed 's/0//')
h_now=$(date '+%H' | sed 's/0//')
echo "NOW:" $h_now  >> grib_update.log

(("$h_now">=0 && "$h_now"<=1)) && today="$(date --date="1 days ago" '+%Y%m%d'12)" 
(("$h_now">=2 && "$h_now"<=7)) && today="$(date --date="1 days ago" '+%Y%m%d'18)" 
(("$h_now">=8 && "$h_now"<=13)) && today="$(date '+%Y%m%d'00)" 
(("$h_now">=14 && "$h_now"<=20)) && today="$(date '+%Y%m%d'06)" 
(("$h_now">=21 && "$h_now"<23)) && today="$(date '+%Y%m%d'12)" 

h0=0 # start hour
h1=384 # forecast hours (384 in 16 days)
h2=6 # forecast frequency (3 h/6 h)
# params='APCP surface'
params='TMP:PRATE:APCP:CRAIN:CSNOW:UGRD:VGRD:ICEC:DPT:VIS:TCDC:PRES:GUST:RH:CFRZR:CAPE surface:2_m_above_ground:10_m_above_ground:100_m_above_ground:975_mb:950_mb:925_mb:900_mb:850_mb:800_mb:700_mb:600_mb:500_mb:400_mb:300_mb:250_mb:200_mb:150_mb:entire_atmosphere'


####!!! EDIT !!! ####
bin_dir='/gip/tools/mchs_grib'
dload_dir='/gip/tools/mchs_grib/grib'
tif_dir='/gip/tools/mchs_grib/tif'
####!!! EDIT !!! ####

## download GRIB files
grib_dload()
{
    if [ ! -d "$dload_dir" ]; then
        mkdir $dload_dir
    else
        find "$dload_dir" -type f -exec rm -f {} \;
    fi
#    echo "today:" $today  >> grib_update.log
#    echo "h0:" $h0  >> grib_update.log
#    echo "h1:" $h1  >> grib_update.log
#    echo "h2:" $h2  >> grib_update.log
#    echo "params:" $params >> grib_update.log
#    echo "dload_dir:" $dload_dir >> grib_update.log
    $bin_dir/get_gfs.pl data $today $h0 $h1 $h2 $params $dload_dir >> grib_update.log 2>&1 
}


clean_out()
{
    ## TIF cleanup
    if [ ! -d $"tif_dir" ]; then
        mkdir -p $tif_dir
    else
        find "$tif_dir" -type f -exec rm -f "{}" \;
    fi

    ## DB cleanup
    export PGPASSWORD='Prime#52'
#    sql1="$bin_dir/batch_truncate_tables.sql"
    sql2="$bin_dir/precip_delete_old.sql"

#    psql --host=172.24.2.192 --username=bpd_owner --dbname=bpd_postgis_dev --file=$sql1 >> grib_update.log 2>&1
    psql --host=172.24.2.192 --username=bpd_owner --dbname=bpd_postgis_dev --file=$sql2 >> grib_update.log 2>&1
    psql --host=172.24.2.192 --username=bpd_owner --dbname=bpd_postgis_dmz --file=$sql2 >> grib_update.log 2>&1
}


proc_all()
{
    ## GRIB processing
    ## iter 1
    find "$dload_dir" -type f -name "gfs.*" | while read file; do
	echo Processing file: "$file" >> grib_update.log 2>&1
        $bin_dir/grib_proc1.sh $file $tif_dir
    done
    
    ## delete TIFs older than 10 days
    find /gip/data/grib/ -type f -name "*.tif*" -mtime +10 -exec rm "{}" \; 
    ## copy new TIFs with overwrite
    rsync -av $tif_dir/*.tif /gip/data/grib/ >> grib_update.log 2>&1
}


proc_wind()
{
    ## GRIB processing
    ## iter 2
   export PGPASSWORD='Prime#52'
   sql="$bin_dir/batch_truncate_tables_wind.sql"    
   psql --host=172.24.2.192 --username=bpd_owner --dbname=bpd_postgis_dev --file=$sql > /dev/null 2>&1
   # psql --host=172.24.2.192 --username=bpd_owner --dbname=bpd_postgis_dmz --file=$sql > /dev/null 2>&1

    ls $dload_dir/gfs.* | awk 'NR%2==0' | while read file; do
        echo Processing file: "$file" >> grib_update.log
        $bin_dir/grib_proc2.sh $file $tif_dir
    done
}


grib_dload
clean_out
proc_all
# proc_wind
echo FINISH $(date) >> grib_update.log


