﻿DELETE FROM is_grib.grib_precip_time_index
 WHERE time_data < (now() - '10 days'::interval);





