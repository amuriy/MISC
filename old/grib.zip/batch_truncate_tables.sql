﻿DO $$
DECLARE
    tables CURSOR FOR
       SELECT tablename
       FROM pg_tables
       WHERE schemaname = 'is_grib'
       AND tablename LIKE 'grib_precip_time%';
       -- or tablename LIKE 'grib_precip_time%'
       -- and tablename not like 'grib_towns%'
       -- and tablename not like 'grib_wind_speed%';
BEGIN
    FOR table_record IN tables LOOP
	EXECUTE 'TRUNCATE TABLE ' || '"is_grib".' || '"' || table_record.tablename || '" RESTART IDENTITY;' ;	
    END LOOP;
END$$;




