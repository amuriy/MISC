INSERT INTO is_grib.grib_dew_time_index (shape,location,time_data) 
VALUES (ST_GeomFromText('POLYGON ((-180 90,180 90,180 -90,-180 -90,-180 90))','4326'),'/gip/data/grib/dpt_2m_2019021315.tif','2019-02-13 15:00:00') ;
update gip.layer set timefield = 'time_data=0000-00-00/9999-30-31' where namefull like '%grib%' ;
