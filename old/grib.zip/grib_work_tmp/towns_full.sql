INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (103.184096985636657 52.865020994747361)','4326'),'','Мишелёвка',5615,'2019-02-13 15:00:00','9.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (103.715690985562674 52.695876994750499)','4326'),'','Тельма',5072,'2019-02-13 15:00:00','9.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (103.342330985614623 53.06626899474378)','4326'),'','Свирск',13110,'2019-02-13 15:00:00','9.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (103.288482985622124 52.960113994745662)','4326'),'','Михайловка',7478,'2019-02-13 15:00:00','9.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (107.599273985022066 50.588626994800869)','4326'),'','Бичура',9145,'2019-02-13 15:00:00','9.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.364798994937971 50.433497994805393)','4326'),'','Октябрьский',6964,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.012492194987011 50.608940794800283)','4326'),'','Борисовка',13661,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.456707094925186 50.523834694802737)','4326'),'8','Майский',8748,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.517832595612681 55.264377794717944)','4326'),'','Демидов',6585,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.37540459563251 54.866638994720866)','4326'),'','Голынки',3372,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.194997595657622 55.604522294716148)','4326'),'','Велиж',7078,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.435972995484867 54.889897594720665)','4326'),'','Кардымово',4561,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.265582995508595 55.85034199471518)','4326'),'','Жарковский',3558,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.68836089544974 55.066227894719297)','4326'),'','Ярцево',46219,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.406043395489036 55.190780294718436)','4326'),'','Духовщина',4125,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.345931995358207 54.981276994719941)','4326'),'','Верхнеднепровский',12242,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.298905095364759 54.914823594720445)','4326'),'','Дорогобуж',10168,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.409602995488541 55.580523994716224)','4326'),'','Озёрный',5519,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.237615895373288 55.108424794718985)','4326'),'','Сафоново',43477,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.771110995438221 56.226096994714354)','4326'),'','Нелидово',20508,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.939486995414782 55.833072994715238)','4326'),'','Белый',3393,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.001050995267015 45.019550695028364)','4326'),'','Аэрофлотский',2254,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.480033995339546 56.208991994714353)','4326'),'','Оленино',4919,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.860669595425762 53.948396494730559)','4326'),'','Рославль',51775,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.425930695486272 53.855549894731773)','4326'),'','Шумячи',4007,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.732086295304455 53.532960794736333)','4326'),'','Жуковка',17147,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.504989995336068 53.689776994734039)','4326'),'','Дубровка',7574,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.4407897954842 54.404775994725213)','4326'),'','Починок',8684,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.288102795366257 54.15166609472805)','4326'),'','Десногорск',28517,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.873248595424002 54.642041494722825)','4326'),'','Глинка',2000,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.08051129567356 54.945922594720216)','4326'),'','Рудня',9652,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.189169795380032 54.576495394723466)','4326'),'','Ельня',9463,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.054959495537915 54.794096494721465)','4326'),'4','Смоленск',330049,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.453864494925583 45.353400195011098)','4326'),'','Керчь',148932,'2019-02-13 15:00:00','2.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.389913095212883 45.709375494993154)','4326'),'','Джанкой',36665,'2019-02-13 15:00:00','2.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.375362795075709 45.033668995027618)','4326'),'8','Феодосия',70043,'2019-02-13 15:00:00','2.000000000000000',4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.775898495019952 45.297283995013956)','4326'),'','Ленино',7936,'2019-02-13 15:00:00','2.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.201074995099972 45.230648695017372)','4326'),'','Кировское',7024,'2019-02-13 15:00:00','2.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.291998394948109 45.376140195009924)','4326'),'','Багерово',3962,'2019-02-13 15:00:00','2.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.822279195013493 45.429144595007244)','4326'),'','Щёлкино',11231,'2019-02-13 15:00:00','2.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.021467395264175 45.019896395028319)','4326'),'','Комсомольское',4787,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.026487395263473 45.010177895028832)','4326'),'','Грэсовский',11139,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.048776895260367 45.016003895028533)','4326'),'','Аграрное',5938,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.05658999525928 45.009269995028902)','4326'),'','Молодёжное',7151,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.322670395222246 45.054729695026516)','4326'),'','Зуя',7027,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.023903395263837 45.11572939502333)','4326'),'','Гвардейское',12660,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.295092895226084 45.495959295003836)','4326'),'','Красногвардейское',10742,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.128562995249261 45.293160395014176)','4326'),'','Октябрьское',11489,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.594958995184342 45.058438495026337)','4326'),'','Белогорск',18208,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.301719995225163 45.564759995000401)','4326'),'','Вольное',2036,'2019-02-13 15:00:00','2.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.923534095138599 45.34589069501147)','4326'),'','Советский',9947,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.088154895115686 45.029392595027844)','4326'),'','Старый Крым',9446,'2019-02-13 15:00:00','2.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.565590495188424 45.58697099499927)','4326'),'','Азовское',3811,'2019-02-13 15:00:00','2.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.738435195164364 45.443025595006517)','4326'),'','Нижнегорский',9564,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.797946695295288 45.956534594981036)','4326'),'','Красноперекопск',30033,'2019-02-13 15:00:00','2.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.86407299528608 45.712406794993008)','4326'),'','Первомайское',9019,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.274768294672107 46.711087694945491)','4326'),'','Ейск',85760,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.662497094618139 46.628450594949285)','4326'),'','Старощербиновская',18010,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.021857994568109 45.844672994986496)','4326'),'','Переясловская',8424,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.963476494576241 46.13278519497252)','4326'),'','Стародеревянковская',12998,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.967855994575629 46.07480809497531)','4326'),'','Каневская',44386,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.955531994577342 46.317477994963738)','4326'),'','Новоминская',11971,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.975711594574527 45.035432895027526)','4326'),'4','Краснодар',829677,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.792896294599991 45.048057295026879)','4326'),'','Елизаветинская',24755,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.971260594575156 45.23608889501709)','4326'),'','Новотитаровская',24754,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.837708294593753 45.278780495014907)','4326'),'','Нововеличковская',9169,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.072969194561004 45.341947095011662)','4326'),'','Старомышастовская',10610,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.313026594527578 45.050655095026741)','4326'),'','Старокорсунская',12238,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.224975694539836 45.216871295018095)','4326'),'','Динская',34848,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.721174494609969 45.433042695007032)','4326'),'','Старовеличковская',13459,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.266279894534087 45.296242195014017)','4326'),'','Пластуновская',10264,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.016785794568818 45.452581195006026)','4326'),'','Медведовская',16793,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.177688994685624 46.0481069949766)','4326'),'','Приморско-Ахтарск',31887,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.950429894578058 45.612353094998006)','4326'),'','Тимашёвск',52641,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.004653994570511 45.800567994988661)','4326'),'','Брюховецкая',22024,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.73955499460741 45.734534994991925)','4326'),'','Роговская',7864,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.148005894828955 45.218818495017977)','4326'),'','Старотитаровская',12164,'2019-02-13 15:00:00','4.000000000000000',4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.719132594888663 45.215864595018154)','4326'),'','Тамань',10027,'2019-02-13 15:00:00','4.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.390548094795193 45.275166295015083)','4326'),'','Темрюк',39164,'2019-02-13 15:00:00','4.000000000000000',4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.502265994779641 45.024043995028123)','4326'),'','Гостагаевская',9772,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.956710994716381 45.430316995007168)','4326'),'','Петровская',13554,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.638736994760642 45.12129199502305)','4326'),'','Варениковская',14881,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.639483194621342 45.104446395023921)','4326'),'','Марьянская',10643,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.12446089469303 45.259087495015912)','4326'),'','Славянск-на-Кубани',65380,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.579521194629692 45.198731895019044)','4326'),'','Новомышастовская',10032,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.464299194645733 45.268741195015423)','4326'),'','Ивановская',9473,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.659813694618514 45.485662595004378)','4326'),'','Калининская',13391,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.215411994680366 45.361968995010656)','4326'),'','Полтавская',26490,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.861941994590367 47.568458994907964)','4326'),'','Матвеев Курган',15590,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.896758994585532 47.414279994914487)','4326'),'','Покровское',12369,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.06250559456246 46.535948794953526)','4326'),'','Староминская',29809,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.903364994584614 47.213689594923125)','4326'),'','Таганрог',251050,'2019-02-13 15:00:00','4.000000000000000',5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.226081987997233 57.070613994715153)','4326'),'','Первомайское',5121,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.141669988008985 56.999186994714954)','4326'),'','Асино',24539,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (89.311484987567738 56.539836994714193)','4326'),'','Тюхтет',4791,'2019-02-13 15:00:00','8.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.038930688162495 58.447559794724732)','4326'),'','Белый Яр',8156,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (87.960814987755754 65.795440994964849)','4326'),'','Туруханск',4662,'2019-02-13 15:00:00','8.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.458854988521651 65.704238994959766)','4326'),'','Красноселькуп',3907,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.129214992604354 67.676238995083295)','4326'),'','Искателей',7179,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.006862992621393 67.637992995080637)','4326'),'4','Нарьян-Мар',23939,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.775954991122312 67.553695995074804)','4326'),'','Комсомольский',706,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.601749692538583 67.834297895094423)','4326'),'','Красное',,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.109084991075932 67.600348995078008)','4326'),'','Северный',8481,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.783736991121238 67.581191995076694)','4326'),'','Воргашор',10450,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (88.200516987722395 69.349839395210694)','4326'),'4','Норильск',178018,'2019-02-13 15:00:00','8.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.175071988004319 69.406066995215355)','4326'),'','Дудинка',21513,'2019-02-13 15:00:00','8.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (80.870871888742684 59.059805294732364)','4326'),'','Каргасок',7276,'2019-02-13 15:00:00','7.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (79.570800988923665 57.561919994717371)','4326'),'','Кедровый',2041,'2019-02-13 15:00:00','7.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.066871988576196 57.020537994715013)','4326'),'','Бакчар',5594,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (81.50179298865487 58.713740994727779)','4326'),'','Парабель',6196,'2019-02-13 15:00:00','7.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.09040798829453 56.554416994714217)','4326'),'','Мельниково',7938,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.976386988310395 56.2601319947143)','4326'),'','Кожевниково',7974,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.760595788340424 57.581204294717509)','4326'),'','Молчаново',5263,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.930152988316834 57.34374199471624)','4326'),'','Кривошеино',5286,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.903556988459727 58.313666994723363)','4326'),'','Колпашево',23272,'2019-02-13 15:00:00','7.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.641540988496203 57.79375099471892)','4326'),'','Подгорное',4632,'2019-02-13 15:00:00','7.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.952323988174541 56.488711994714194)','4326'),'4','Томск',572740,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.881011988184468 56.60316099471423)','4326'),'','Северск',107922,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.022101988164835 56.426921994714199)','4326'),'','Зональная Станция',7782,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.621177987942232 56.834205994714573)','4326'),'','Зырянское',5090,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.103522988153486 56.578078994714218)','4326'),'','Светлый',7599,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.511395489906349 65.533623794950373)','4326'),'','Надым',44660,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (71.772010990009264 62.444140994813772)','4326'),'8','Нижнесортымский',12485,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (70.832015990140093 66.873412995029625)','4326'),'','Яр-Сале',6486,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (75.447580689497613 63.200291694841489)','4326'),'4','Ноябрьск',107129,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (74.488761989631072 62.267959994807853)','4326'),'6','Когалым',64704,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (76.673713989326927 61.945926994797496)','4326'),'','Новоаганск',9658,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (74.496932189629945 63.794797694865821)','4326'),'','Муравленко',32786,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (76.489808589352535 64.43378239489455)','4326'),'','Губкинский',27070,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (77.462615989217127 62.135314994803487)','4326'),'6','Радужный',43157,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (74.494796989630245 65.856574994968312)','4326'),'','Пангоды',10737,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (76.700585889323179 64.479120494896662)','4326'),'','Пурпе',9598,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (77.779458989173008 64.92199909491832)','4326'),'4','Тарко-Сале',21665,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (76.679916689326078 66.085195994981476)','4326'),'4','Новый Уренгой',115092,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (78.714920589042805 67.473532095069302)','4326'),'','Тазовский',7201,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (78.367980789091106 65.964232294974479)','4326'),'','Уренгой',10082,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.917127995835504 56.01761599471471)','4326'),'','Невель',16272,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.439448995623589 54.569438994723541)','4326'),'','Красный',4150,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.83896799556798 54.348548994725789)','4326'),'','Монастырщина',3755,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.686699995449978 52.845099994747727)','4326'),'','Унеча',24639,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.263705995369648 52.554282994753216)','4326'),'','Погар',8950,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.853000995426825 53.057998994743954)','4326'),'','Мглин',8052,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.393163295490837 53.013150094744717)','4326'),'','Сураж',10979,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.454535995343086 52.928779994746208)','4326'),'','Почеп',16681,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.215598995376347 53.38560099473856)','4326'),'','Клетня',12873,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.739722995581801 52.426166994755782)','4326'),'','Злынка',5526,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.197143295518124 52.379054194756719)','4326'),'6','Климово',13363,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.602849695600852 53.005655794744833)','4326'),'','Красная Гора',6131,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.933669995554794 52.537085994753568)','4326'),'6','Новозыбков',40765,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.615584188082209 50.269592694810271)','4326'),'','Усть-Кокса',4745,'2019-02-13 15:00:00','7.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.24009699551214 52.758510994749294)','4326'),'','Клинцы',61517,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.487414995338511 52.381846994756671)','4326'),'','Белая Берёзка',5965,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.76009799543975 52.584445994752635)','4326'),'','Стародуб',18868,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (79.719317588902982 51.821248594768875)','4326'),'','Михайловское',10756,'2019-02-13 15:00:00','7.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (88.662821787658032 49.994705494818731)','4326'),'','Кош-Агач',9212,'2019-02-13 15:00:00','7.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (80.188407988837682 51.36369299477991)','4326'),'','Угловское',4368,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (81.463858288660134 51.000464094789393)','4326'),'','Горняк',12972,'2019-02-13 15:00:00','7.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (22.571963496857958 54.632621594722927)','4326'),'','Нестеров',4333,'2019-02-13 15:00:00','3.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.106809488431452 54.757949994721756)','4326'),'','Бердск',103290,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (134.300672881305189 46.444319494957796)','4326'),'','Лучегорск',19720,'2019-02-13 15:00:00','11.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.303567588404036 54.642626894722817)','4326'),'','Искитим',57032,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (134.254821981311579 46.819362994940576)','4326'),'','Бикин',15928,'2019-02-13 15:00:00','11.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.207717988556581 55.021441994719616)','4326'),'','Коченёво',16956,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.210669988277786 54.345500994725825)','4326'),'','Маслянино',12807,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.693394588488999 54.995133494719816)','4326'),'','Обь',29194,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.442701788523877 54.994405594719851)','4326'),'','Чик',5189,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (134.757873981241517 47.533454994909427)','4326'),'','Вяземский',13187,'2019-02-13 15:00:00','11.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.923450888456983 55.028217094719587)','4326'),'4','Новосибирск',1602920,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.644006188495865 55.085900594719142)','4326'),'','Криводановка',10051,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.990586088447614 54.921108094720402)','4326'),'','Краснообск',23768,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.743346388482024 55.306879094717722)','4326'),'','Колывань',12429,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.611854988361145 55.304805994717704)','4326'),'','Мошково',9856,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.187138988420259 54.9367735947203)','4326'),'','Кольцово',15938,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.765212988200588 50.93200299479124)','4326'),'','Усть-Кан',4542,'2019-02-13 15:00:00','7.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.878760988323975 55.118285994718924)','4326'),'','Горный',9164,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.986086088169827 51.999485594764849)','4326'),'','Белокуриха',15264,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.679453788073317 51.291773994781764)','4326'),'','Шебалино',5011,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (79.228576988971298 53.984767994730085)','4326'),'','Краснозёрское',9216,'2019-02-13 15:00:00','7.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.93940698831554 53.393340994738438)','4326'),'','Новоалтайск',73712,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (79.667090988910246 54.495784994724239)','4326'),'','Довольное',6774,'2019-02-13 15:00:00','7.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (79.537765988928257 53.624282994734962)','4326'),'6','Хабары',5141,'2019-02-13 15:00:00','7.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (81.35163578867575 53.793676094732589)','4326'),'','Камень-на-Оби',41315,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (80.346228588815734 53.832738094732065)','4326'),'6','Панкрушиха',4941,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (79.679374988908535 55.306720994717701)','4326'),'','Убинское',5841,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (80.48784598879601 54.334765994725934)','4326'),'','Кочки',3972,'2019-02-13 15:00:00','7.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (80.970458988728822 55.089999994719129)','4326'),'','Чулым',11270,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (80.282825188824532 55.192989894718416)','4326'),'','Каргат',9519,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (81.904021988598871 54.366675994725618)','4326'),'','Ордынское',9727,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.316230988541477 53.783923994732739)','4326'),'','Сузун',15491,'2019-02-13 15:00:00','7.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.838424988329606 53.557067994735974)','4326'),'','Сибирский',11896,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.562010988368073 53.817630594732258)','4326'),'','Тальменка',19157,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.379073988393543 54.456458994724649)','4326'),'','Линёво',18468,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.370467988394736 54.226100994727176)','4326'),'','Черепаново',19612,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.288781388545317 51.600290194774118)','4326'),'','Курья',3375,'2019-02-13 15:00:00','7.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.734905581383941 45.933719494982142)','4326'),'','Дальнереченск',26461,'2019-02-13 15:00:00','11.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (81.824981988609863 51.991351994765019)','4326'),'','Поспелиха',11915,'2019-02-13 15:00:00','7.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.556988988368786 51.400848094779008)','4326'),'','Чарышское',3097,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (134.506571481276524 45.85150129498615)','4326'),'','Новопокровка',3646,'2019-02-13 15:00:00','11.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.730651988483814 51.669356994772443)','4326'),'','Краснощёково',4848,'2019-02-13 15:00:00','7.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.261626988549096 52.218867994760082)','4326'),'','Шипуново',13462,'2019-02-13 15:00:00','7.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.318351988262791 51.655627994772779)','4326'),'','Солонешное',4441,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.7730754884779 52.497022094754342)','4326'),'','Алейск',28735,'2019-02-13 15:00:00','7.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (81.631263988636846 52.706683994750279)','4326'),'','Мамонтово',8652,'2019-02-13 15:00:00','7.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.307525988403498 52.124251994762105)','4326'),'','Усть-Калманка',6371,'2019-02-13 15:00:00','7.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.338216988538434 53.075280294743656)','4326'),'','Ребриха',8207,'2019-02-13 15:00:00','7.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.115342988430257 52.817566894748211)','4326'),'','Топчиха',8906,'2019-02-13 15:00:00','7.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.668250988353279 52.391293894756487)','4326'),'','Усть-Чарышская Пристань',4809,'2019-02-13 15:00:00','7.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.577836088365871 53.298207594739935)','4326'),'','Власиха',9992,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.989911888447708 53.313335594739712)','4326'),'','Павловск',14445,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.778449588337949 53.347401994739158)','4326'),'4','Барнаул',633301,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.50119928141649 45.243522095016729)','4326'),'','Горные Ключи',4318,'2019-02-13 15:00:00','11.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (83.693885988349734 53.254748994740652)','4326'),'','Южный',19964,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.506202681415772 45.089762695024682)','4326'),'','Кировский',8439,'2019-02-13 15:00:00','11.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (81.217617388694393 51.527626394775858)','4326'),'','Рубцовск',145333,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (80.364971788813094 52.017122694764439)','4326'),'','Волчиха',10011,'2019-02-13 15:00:00','7.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.418215781428046 45.474774395004928)','4326'),'','Лесозаводск',36317,'2019-02-13 15:00:00','11.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (79.171431988979236 52.254905994759305)','4326'),'','Ключи',8660,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (80.892516988739658 51.758929994770327)','4326'),'','Новоегорьевское',5596,'2019-02-13 15:00:00','7.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (79.85595698888396 52.778659994748956)','4326'),'','Степное Озеро',6300,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (78.93544798901209 52.566558994752974)','4326'),'','Кулунда',14498,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (80.203498988835577 52.499648994754303)','4326'),'','Родино',8202,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (79.870568288881927 52.830601994748001)','4326'),'','Благовещенка',11577,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (81.226358988693192 52.618722894751969)','4326'),'','Романово',5624,'2019-02-13 15:00:00','7.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (81.394027988669862 52.210250994760258)','4326'),'','Новичиха',4140,'2019-02-13 15:00:00','7.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (80.919779988735868 52.838667494747838)','4326'),'','Завьялово',6763,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (80.773414988756244 53.274985994740341)','4326'),'','Баево',4188,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (81.497550988655448 53.319838994739591)','4326'),'','Тюменцево',5255,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (82.19799278855794 51.154465794785317)','4326'),'','Змеиногорск',10575,'2019-02-13 15:00:00','7.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (81.999640988585554 51.006228994789247)','4326'),'','Староалейское',4769,'2019-02-13 15:00:00','7.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.940368981494544 53.068480994743766)','4326'),'','Экимчан',1034,'2019-02-13 15:00:00','10.000000000000000',-29.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.035552981481288 51.134486994785853)','4326'),'','Чегдомын',12170,'2019-02-13 15:00:00','11.000000000000000',-28.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.637168987940001 56.192168994714379)','4326'),'','Ижморский',4879,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (112.903418984283718 58.310554994723326)','4326'),'','Мама',2969,'2019-02-13 15:00:00','9.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.45111098796589 56.202640994714379)','4326'),'','Яя',10810,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (114.837981984014391 56.355514994714227)','4326'),'','Таксимо',8114,'2019-02-13 15:00:00','9.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (87.332892987843152 53.606994994735224)','4326'),'','Осинники',43008,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (112.750213984305063 59.625266994741267)','4326'),'','Пеледуй',4708,'2019-02-13 15:00:00','10.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (87.286178987849667 53.519458994736524)','4326'),'','Калтан',20947,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (114.203828384102692 57.850031694719306)','4326'),'','Бодайбо',13104,'2019-02-13 15:00:00','9.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (88.070344287740525 53.686376294734089)','4326'),'','Междуреченск',97895,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (118.273232283536231 56.797934994714481)','4326'),'','Новая Чара',3973,'2019-02-13 15:00:00','10.000000000000000',-29.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (87.800315987778092 53.713859994733717)','4326'),'','Мыски',41682,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (114.913089684003992 60.71405549476367)','4326'),'','Ленск',23660,'2019-02-13 15:00:00','10.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (87.610343987804526 56.029399994714687)','4326'),'','Верх-Чебула',4584,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (113.462897984205838 63.046866994835568)','4326'),'','Светлый',3393,'2019-02-13 15:00:00','10.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (89.962890987477053 54.48763999472434)','4326'),'','Шира',9448,'2019-02-13 15:00:00','8.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (120.438750983234769 60.373015994755903)','4326'),'','Олёкминск',9202,'2019-02-13 15:00:00','10.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (88.313021587706729 55.763850994715483)','4326'),'','Тисуль',7801,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (117.646331983623483 62.157454994804198)','4326'),'','Сунтар',9794,'2019-02-13 15:00:00','10.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (87.751258987784936 56.206298994714381)','4326'),'','Мариинск',39091,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (89.186431987585138 55.535502994716467)','4326'),'','Шарыпово',37169,'2019-02-13 15:00:00','8.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (113.978583984134048 62.541076994817111)','4326'),'4','Мирный',35376,'2019-02-13 15:00:00','10.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (120.313682983252193 63.449897994851419)','4326'),'','Верхневилюйск',6214,'2019-02-13 15:00:00','10.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (88.517234987678307 56.113952994714509)','4326'),'','Тяжинский',10121,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (118.354148983524965 63.286647994844891)','4326'),'','Нюрба',9850,'2019-02-13 15:00:00','10.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (89.825736987496157 55.283450994717846)','4326'),'','Солнечный',10035,'2019-02-13 15:00:00','8.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (89.826621987496026 54.99296599471986)','4326'),'','Копьёво',4401,'2019-02-13 15:00:00','8.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (124.712360482639909 56.657964094714295)','4326'),'4','Нерюнгри',57247,'2019-02-13 15:00:00','10.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (121.626548983069441 63.754081994864094)','4326'),'','Вилюйск',10975,'2019-02-13 15:00:00','10.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (89.082671987599582 55.62273399471605)','4326'),'','Дубинино',8961,'2019-02-13 15:00:00','8.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (89.848658487492969 55.321635894717616)','4326'),'','Ужур',15568,'2019-02-13 15:00:00','8.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.276023987990285 54.603141994723195)','4326'),'','Полысаево',26510,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.166114988005575 54.665442994722603)','4326'),'','Ленинск-Кузнецкий',96921,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.402457988251086 55.237689994718124)','4326'),'','Тогучин',21159,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (127.671564182227968 52.000568194764803)','4326'),'','Шимановск',18706,'2019-02-13 15:00:00','10.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.380736987975709 54.534869994723856)','4326'),'','Грамотеино',12408,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.622874088081204 55.275196194717893)','4326'),'','Топки',27963,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (128.380919982129228 51.091205994786989)','4326'),'','Серышево',9855,'2019-02-13 15:00:00','10.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.638029288079096 54.918654994720413)','4326'),'','Промышленная',17821,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (128.472869982116435 50.921325994791523)','4326'),'','Белогорск',66445,'2019-02-13 15:00:00','10.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.934798988176993 55.713599994715672)','4326'),'','Юрга',81733,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (128.123427982165055 51.764972994770197)','4326'),'','Циолковский',6526,'2019-02-13 15:00:00','10.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.388549988253018 55.671565994715856)','4326'),'','Болотное',15629,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (128.134749982163498 51.37735399477959)','4326'),'','Свободный',54156,'2019-02-13 15:00:00','10.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.631324988080024 56.065070994714617)','4326'),'','Тайга',24183,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (125.804681382487857 53.451788994737555)','4326'),'','Магдагачи',10070,'2019-02-13 15:00:00','10.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.427688988108372 55.873088994715125)','4326'),'','Яшкино',13884,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (123.937345382747779 53.986256694730059)','4326'),'','Сковородино',9283,'2019-02-13 15:00:00','10.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.805854987916518 55.003924994719767)','4326'),'','Крапивинский',7375,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (127.271624582283636 53.740358394733327)','4326'),'','Зея',23505,'2019-02-13 15:00:00','10.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.08723398801655 55.355124994717421)','4326'),'4','Кемерово',556920,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (124.737588382636389 55.149693994718703)','4326'),'','Тында',33189,'2019-02-13 15:00:00','10.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.274528987990493 55.669925994715868)','4326'),'','Берёзовский',46859,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.60548398154117 51.071143994787498)','4326'),'','Новый Ургал',6332,'2019-02-13 15:00:00','11.000000000000000',-28.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.952476987896119 55.00462299471976)','4326'),'','Зеленогорский',4927,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (130.852828981785137 52.45704999475516)','4326'),'','Февральск',4782,'2019-02-13 15:00:00','10.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.246650987994371 56.083323994714561)','4326'),'','Рудничный',3752,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.019355988026007 56.07780799471459)','4326'),'','Анжеро-Судженск',71787,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (87.977332987753456 52.92631099474626)','4326'),'','Шерегеш',10109,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (87.284530987849891 53.402919994738305)','4326'),'','Малиновка',8835,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.926711988178099 53.703605994733849)','4326'),'','Заринск',46830,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (89.891723987486984 52.795859994748611)','4326'),'','Таштып',6423,'2019-02-13 15:00:00','8.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (134.960937981213277 47.882571994894995)','4326'),'','Хор',9545,'2019-02-13 15:00:00','11.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.913283988040774 53.462802994737366)','4326'),'','Тогул',4349,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (134.778888681238641 48.55647789486855)','4326'),'','Николаевка',6652,'2019-02-13 15:00:00','11.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.736045988204637 53.995154994729951)','4326'),'','Залесово',7370,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.813836881372964 48.595670094867081)','4326'),'','Смидович',4555,'2019-02-13 15:00:00','11.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.737662987926015 53.890971994731309)','4326'),'','Прокопьевск',196406,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (87.136100987870563 53.757606994733074)','4326'),'','Новокузнецк',552445,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.798385988056765 54.232520994727103)','4326'),'','Салаир',7589,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.635477087940231 54.004987194729821)','4326'),'','Киселёвск',90980,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.104758988014126 54.283137994726523)','4326'),'','Бачатский',14028,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.931090988038292 54.284953994726507)','4326'),'','Гурьевск',23089,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.448096987966338 54.157386994727979)','4326'),'','Краснобродский',11715,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.296218987987459 54.306170994726273)','4326'),'','Новый Городок',14835,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.441680987967217 54.432643994724906)','4326'),'','Инской',12099,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.303428987986464 54.419322994725036)','4326'),'','Белово',72843,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (131.053803781757154 49.0145148948517)','4326'),'','Облучье',8811,'2019-02-13 15:00:00','11.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.141513188009014 50.745402094796411)','4326'),'','Онгудай',5586,'2019-02-13 15:00:00','7.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (129.675741681949006 49.742906294826803)','4326'),'','Прогресс',10078,'2019-02-13 15:00:00','10.000000000000000',-22.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.336745988121024 51.945144994766039)','4326'),'','Алтайское',14235,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.898742988042798 52.004683994764711)','4326'),'','Майма',17824,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (129.873410481921468 49.79396039482517)','4326'),'','Новобурейский',7040,'2019-02-13 15:00:00','10.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.003570988028187 51.406905994778832)','4326'),'','Чемал',4011,'2019-02-13 15:00:00','7.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (129.403365981986923 49.796889994825051)','4326'),'','Райчихинск',17590,'2019-02-13 15:00:00','10.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.545722987952729 52.005321994764707)','4326'),'','Чоя',1916,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (129.440234081981771 50.111153994815119)','4326'),'','Завитинск',10743,'2019-02-13 15:00:00','10.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.963652988033758 51.957774994765771)','4326'),'4','Горно-Алтайск',63295,'2019-02-13 15:00:00','7.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (130.0858307818919 49.422428294837481)','4326'),'','Архара',8842,'2019-02-13 15:00:00','10.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.079383988156849 52.305301994758253)','4326'),'','Смоленское',8985,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.386985988253244 52.372764994756871)','4326'),'','Быстрый Исток',3460,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.622380781538823 47.934442494892906)','4326'),'','Ленинское',6109,'2019-02-13 15:00:00','11.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.214867288137981 52.539490494753522)','4326'),'','Бийск',203108,'2019-02-13 15:00:00','7.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.409720988110877 52.28260399475873)','4326'),'','Советское',4824,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.579506788226439 53.361951694738941)','4326'),'6','Косиха',5118,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.928208181496245 48.788166794859926)','4326'),'4','Биробиджан',74777,'2019-02-13 15:00:00','11.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (84.677627988212762 52.981387994745269)','4326'),'','Троицкое',9634,'2019-02-13 15:00:00','7.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.46623748156054 49.001632994852173)','4326'),'','Бира',2889,'2019-02-13 15:00:00','11.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (86.195273988001517 52.296340994758452)','4326'),'','Красногорское',5850,'2019-02-13 15:00:00','7.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (85.661757988075792 53.078261994743606)','4326'),'','Целинное',4836,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (87.848266987771424 52.759402994749308)','4326'),'','Таштагол',23107,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.72743798013218 46.957427294934405)','4326'),'4','Южно-Сахалинск',194882,'2019-02-13 15:00:00','11.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (87.117537987873135 52.25995599475921)','4326'),'','Турочак',5582,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.048712480226641 47.05458749493009)','4326'),'','Холмск',28217,'2019-02-13 15:00:00','11.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.186461989812372 61.253276994777337)','4326'),'8','Барсово',5677,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.063477980224576 47.761208694899956)','4326'),'','Томари',3774,'2019-02-13 15:00:00','11.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.781014680124713 46.632814994949079)','4326'),'','Корсаков',33213,'2019-02-13 15:00:00','11.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.252440989803191 61.262725994777576)','4326'),'8','Белый Яр',17384,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.064353180224487 49.080207094849371)','4326'),'','Углегорск',9070,'2019-02-13 15:00:00','11.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.183585989812755 61.280467994778071)','4326'),'8','Солнечный',11317,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.797936080122355 47.324145594918328)','4326'),'','Долинск',11708,'2019-02-13 15:00:00','11.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.723044989737659 61.607440994787289)','4326'),'8','Фёдоровский',23375,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.396399989783134 61.254031994777385)','4326'),'4','Сургут',360590,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.107001280218526 49.159243494846571)','4326'),'','Шахтёрск',6731,'2019-02-13 15:00:00','11.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.832006580117621 49.742353094826839)','4326'),'','Смирных',7624,'2019-02-13 15:00:00','11.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (143.101575880080077 49.221636594844377)','4326'),'','Поронайск',15311,'2019-02-13 15:00:00','11.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (75.59723698947677 61.744189994791299)','4326'),'6','Покачи',17905,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (136.640059980979544 50.723807994796999)','4326'),'','Солнечный',11975,'2019-02-13 15:00:00','11.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (75.189277989533551 61.247256994777175)','4326'),'6','Лангепас',43534,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (136.338332981021551 51.394053994779163)','4326'),'','Эворон',1211,'2019-02-13 15:00:00','11.000000000000000',-30.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (76.108214989405667 61.035403994771613)','4326'),'6','Мегион',48283,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (140.4412079804504 52.370986994756912)','4326'),'','Богородское',3670,'2019-02-13 15:00:00','11.000000000000000',-29.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (77.865844989160976 60.431445994757176)','4326'),'','Александровское',6866,'2019-02-13 15:00:00','7.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (136.489379981000525 52.422847994755848)','4326'),'','имени Полины Осипенко',2117,'2019-02-13 15:00:00','11.000000000000000',-30.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (76.889540489296877 60.956283994769578)','4326'),'','Излучинск',19597,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.159166680211257 50.897499994792192)','4326'),'','Александровск-Сахалинский',9586,'2019-02-13 15:00:00','11.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (76.580367989339933 60.93404399476902)','4326'),'6','Нижневартовск',274575,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (140.252334980476718 49.058680994850135)','4326'),'','Октябрьский',5816,'2019-02-13 15:00:00','11.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (77.600806989197878 60.7327579947641)','4326'),'','Стрежевой',41733,'2019-02-13 15:00:00','7.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.839980989860578 60.755115994764651)','4326'),'6','Пыть-Ях',40798,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (140.284957980472143 48.966296994853437)','4326'),'','Советская Гавань',24671,'2019-02-13 15:00:00','11.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (71.896201989991965 60.995170994770568)','4326'),'8','Пойковский',26436,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (140.260863980475534 49.090480994848988)','4326'),'','Ванино',15485,'2019-02-13 15:00:00','11.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.610099989892589 61.090308994773018)','4326'),'6','Нефтеюганск',126157,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (139.125915980633494 50.097514994815555)','4326'),'','Высокогорный',3055,'2019-02-13 15:00:00','11.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.606574989753895 56.467624994714193)','4326'),'','Колосовка',5313,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.16513798995453 61.622493994787689)','4326'),'8','Лянтор',40024,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.821982989723907 57.127402994715347)','4326'),'','Знаменское',5294,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (74.369865189647641 56.902586994714689)','4326'),'','Тара',28116,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (75.306060989517306 56.945617994714794)','4326'),'','Седельниково',5316,'2019-02-13 15:00:00','7.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.527514980160021 46.71477679494533)','4326'),'','Анива',9430,'2019-02-13 15:00:00','11.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (75.237197989526891 56.369391994714206)','4326'),'','Муромцево',10350,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (141.859942680252942 46.687921894946548)','4326'),'','Невельск',10681,'2019-02-13 15:00:00','11.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (78.364951989091523 56.35014299471424)','4326'),'','Северное',4988,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (99.708838486120428 70.187008595282634)','4326'),'','Рецкий',,'2019-02-13 15:00:00','8.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (76.624587989333762 56.559569994714217)','4326'),'','Кыштовка',5282,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.563308981407857 62.360934994810947)','4326'),'','Ытык-Кюёль',6623,'2019-02-13 15:00:00','10.000000000000000',-36.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.391173981431791 67.552726995074721)','4326'),'','Верхоянск',1131,'2019-02-13 15:00:00','11.000000000000000',-41.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (128.868545982061335 71.636603995420913)','4326'),'','Тикси',4604,'2019-02-13 15:00:00','10.000000000000000',-32.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (136.613729280983193 45.050404595026734)','4326'),'','Терней',3360,'2019-02-13 15:00:00','11.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (134.635070981258679 67.654906995081816)','4326'),'','Батагай',3676,'2019-02-13 15:00:00','11.000000000000000',-38.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (69.01915699039246 61.0034599947708)','4326'),'5','Ханты-Мансийск',98692,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (135.054946981200203 47.968635994891493)','4326'),'','Переяславка',7621,'2019-02-13 15:00:00','11.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (135.829437081092408 46.448000994957617)','4326'),'','Восток',3925,'2019-02-13 15:00:00','11.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (135.076934981197127 48.481402994871409)','4326'),'4','Хабаровск',616242,'2019-02-13 15:00:00','11.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (135.058898981199661 48.222678994881385)','4326'),'','Корфовский',5837,'2019-02-13 15:00:00','11.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (135.454224281144604 48.467410694871944)','4326'),'','Князе-Волконское',9169,'2019-02-13 15:00:00','11.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (135.231826981175573 48.352229994876367)','4326'),'','Некрасовка',9170,'2019-02-13 15:00:00','11.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (136.509414980997718 50.101787994815389)','4326'),'','Эльбан',11438,'2019-02-13 15:00:00','11.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (136.137176981049549 48.194724994882485)','4326'),'','Мухен',3682,'2019-02-13 15:00:00','11.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (137.020781980926557 50.550876994801939)','4326'),'4','Комсомольск-на-Амуре',249810,'2019-02-13 15:00:00','11.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (136.901534980943154 50.229941994811476)','4326'),'','Амурск',40106,'2019-02-13 15:00:00','11.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (125.388221982545801 58.608413994726547)','4326'),'','Алдан',20700,'2019-02-13 15:00:00','10.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (124.904715982613112 56.840407994714582)','4326'),'','Чульман',8101,'2019-02-13 15:00:00','10.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (67.663939990581099 56.476645994714218)','4326'),'','Омутинское',9201,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (126.266852982423501 58.968535994731099)','4326'),'','Томмот',7046,'2019-02-13 15:00:00','10.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (89.531638987537093 56.211463994714357)','4326'),'','Боготол',20245,'2019-02-13 15:00:00','8.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (125.529326982526143 58.819114994729098)','4326'),'','Нижний Куранах',5329,'2019-02-13 15:00:00','10.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (68.647445990444197 56.865016994714608)','4326'),'','Аромашево',5373,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (129.135650982024146 61.484027994783702)','4326'),'','Покровск',9177,'2019-02-13 15:00:00','10.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (68.375068990482106 56.395541994714215)','4326'),'','Голышманово',14123,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (128.947860982050287 61.397860994781311)','4326'),'','Мохсоголлох',6178,'2019-02-13 15:00:00','10.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (68.250594990499451 58.201285994722255)','4326'),'','Тобольск',98886,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (134.536498981272359 60.416438994756867)','4326'),'','Усть-Мая',2633,'2019-02-13 15:00:00','10.000000000000000',-31.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (69.807471990282721 56.62953899471426)','4326'),'','Большое Сорокино',5317,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (131.979979981628247 60.894217994768056)','4326'),'','Амга',6578,'2019-02-13 15:00:00','10.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (70.453025990192856 56.28902399471427)','4326'),'','Абатское',7959,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (127.466758982256465 63.923617994871393)','4326'),'','Сангар',3861,'2019-02-13 15:00:00','10.000000000000000',-34.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (69.01258639039338 57.935222394719951)','4326'),'','Вагай',5013,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (126.699836982363237 62.098288994802296)','4326'),'','Бердигестях',6462,'2019-02-13 15:00:00','10.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.625716989890407 56.949042994714809)','4326'),'','Большие Уки',3968,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (129.911345981916185 61.957065994797823)','4326'),'','Нижний Бестях',3924,'2019-02-13 15:00:00','10.000000000000000',-31.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (70.605361990171659 56.815154994714511)','4326'),'','Викулово',6995,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (71.169967990093042 57.69346199471822)','4326'),'','Усть-Ишим',4802,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (129.732085981941168 62.027286994800015)','4326'),'4','Якутск',307911,'2019-02-13 15:00:00','10.000000000000000',-32.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (129.664245981950614 62.718226994823411)','4326'),'','Намцы',9683,'2019-02-13 15:00:00','10.000000000000000',-34.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.398910989921987 57.51366799471711)','4326'),'','Тевриз',6893,'2019-02-13 15:00:00','7.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (129.843108981925695 62.164103994804407)','4326'),'','Жатай',9079,'2019-02-13 15:00:00','10.000000000000000',-32.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (68.894774990409772 59.142657994733561)','4326'),'','Уват',5002,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.425200981566263 61.999667994799154)','4326'),'','Чурапча',10131,'2019-02-13 15:00:00','10.000000000000000',-33.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (131.166060981741566 62.670791994821698)','4326'),'','Борогонцы',5222,'2019-02-13 15:00:00','10.000000000000000',-35.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.188670994127293 55.544070994716407)','4326'),'','Навашино',15406,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.759837294047784 54.890632794720666)','4326'),'','Вознесенское',6332,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.334605993967777 54.934630994720315)','4326'),'','Саров',94417,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.511878994082302 55.429286994717017)','4326'),'','Кулебаки',33684,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.096803694000876 55.24104079471811)','4326'),'','Ардатов',8782,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.245517993980172 55.041686994719491)','4326'),'','Дивеево',9000,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.200504493986443 55.46775669471679)','4326'),'','Мухтолово',4706,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.028171994010421 55.390555994717218)','4326'),'','Гремячево',5174,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (147.90216097941186 70.619239995322019)','4326'),'','Чокурдах',2095,'2019-02-13 15:00:00','12.000000000000000',-38.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.67903499405903 56.20656999471435)','4326'),'','Гороховец',13233,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (166.444851476830678 68.055030495110259)','4326'),'','Билибино',5348,'2019-02-13 15:00:00','12.000000000000000',-44.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.772098994046075 55.801028994715367)','4326'),'','Вача',5424,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (161.330040677542684 68.752177495162755)','4326'),'','Черский',2600,'2019-02-13 15:00:00','12.000000000000000',-39.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.024192994010981 55.997848994714772)','4326'),'','Тумботино',7011,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.166953993991108 55.805163994715329)','4326'),'','Сосновское',8350,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.058345994006231 56.132815994714491)','4326'),'','Горбатов',2049,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.071113994004456 55.965136994714861)','4326'),'','Павлово',58582,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.182654993988926 56.224303994714326)','4326'),'','Володарск',10102,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.955367994020563 56.227473994714344)','4326'),'','Ильиногорск',7560,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.27486799411529 54.7678529947217)','4326'),'','Ермишь',3885,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.465598894088743 54.565532694723558)','4326'),'','Кадом',5216,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.673625993920588 53.529990994736373)','4326'),'','Нижний Ломов',21626,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.210982993984985 54.631495994722926)','4326'),'','Темников',6489,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.914954993886987 54.037898994729431)','4326'),'','Ковылкино',20560,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.699470993916982 53.87941699473145)','4326'),'','Наровчат',4398,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.371406993823449 53.867740994731612)','4326'),'','Инсар',8431,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (149.625533979171934 62.522063994816456)','4326'),'','Ягодное',3538,'2019-02-13 15:00:00','12.000000000000000',-42.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.605342993790885 53.439216994737727)','4326'),'','Мокшан',11710,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (148.153609979376824 62.779731994825639)','4326'),'','Сусуман',4899,'2019-02-13 15:00:00','12.000000000000000',-43.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.83964499375827 53.865588994731631)','4326'),'','Исса',5271,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (152.393299278786657 62.93177419483122)','4326'),'','Сеймчан',2231,'2019-02-13 15:00:00','12.000000000000000',-41.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.421386993816498 54.027385994729542)','4326'),'','Кадошкино',4427,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (150.893325978995477 65.733596994961417)','4326'),'','Зырянка',2860,'2019-02-13 15:00:00','12.000000000000000',-38.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.785197993905051 54.424033994724986)','4326'),'','Краснослободск',9713,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (153.707091978603813 67.455459995068054)','4326'),'4','Среднеколымск',3488,'2019-02-13 15:00:00','12.000000000000000',-39.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.954390993742294 54.058734994729164)','4326'),'','Рузаевка',46213,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (155.782351378314928 62.512764294816137)','4326'),'','Омсукчан',3763,'2019-02-13 15:00:00','12.000000000000000',-39.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.463557993810625 54.304255994726297)','4326'),'','Старое Шайгово',5185,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (158.647218677916129 53.019969294744612)','4326'),'4','Петропавловск-Камчатский',180454,'2019-02-13 15:00:00','12.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.875976993892415 54.620688994723047)','4326'),'','Ельники',5500,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (158.405382977949813 52.931833994746142)','4326'),'','Вилючинск',21942,'2019-02-13 15:00:00','12.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.854751993756174 54.701041994722289)','4326'),'','Починки',12500,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (158.609878977921312 54.690410994722384)','4326'),'','Мильково',8251,'2019-02-13 15:00:00','12.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (158.383671177952806 53.186497194741783)','4326'),'','Елизово',38771,'2019-02-13 15:00:00','12.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.752692994187981 54.969169994720012)','4326'),'','Елатьма',3145,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (159.951294277734604 59.082760494732682)','4326'),'','Палана',2922,'2019-02-13 15:00:00','12.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.395179994237743 54.939692994720254)','4326'),'','Касимов',31494,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.180040794128487 55.318773994717631)','4326'),'','Выкса',53628,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (177.506092475290927 64.731687494908869)','4326'),'4','Анадырь',15468,'2019-02-13 15:00:00','12.000000000000000',-35.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.631406294204872 55.336837394717513)','4326'),'','Меленки',14302,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (159.235930977834187 61.919208994796655)','4326'),'','Эвенск',1471,'2019-02-13 15:00:00','12.000000000000000',-31.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.858688594312426 55.951570294714884)','4326'),'','Судогда',10794,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (146.187285979650568 68.537009995146136)','4326'),'','Белая Гора',2074,'2019-02-13 15:00:00','12.000000000000000',-41.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.103892994139088 55.397334994717156)','4326'),'','Досчатое',5207,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (139.964522980516819 69.303710995206899)','4326'),'','Депутатский',2967,'2019-02-13 15:00:00','11.000000000000000',-41.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.763751194186447 55.868921594715133)','4326'),'','Красная Горбатка',8268,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (143.136507680075255 51.795361694769475)','4326'),'','Ноглики',10005,'2019-02-13 15:00:00','11.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.149131994271997 55.9464149947149)','4326'),'','Андреево',5326,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.654999980142264 50.845555994793628)','4326'),'','Тымовское',7460,'2019-02-13 15:00:00','11.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.137576994134399 56.245139994714329)','4326'),'','Вязники',37866,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (140.724929980410906 53.138728994742557)','4326'),'','Николаевск-на-Амуре',19135,'2019-02-13 15:00:00','11.000000000000000',-29.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.044699994147322 55.573799994716261)','4326'),'','Муром',110746,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (141.497786980303346 52.209216994760268)','4326'),'','Лазарев',1027,'2019-02-13 15:00:00','11.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.837424994036986 54.079963994728907)','4326'),'','Зубова Поляна',10162,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (147.875184479415594 45.229041295017467)','4326'),'','Курильск',1547,'2019-02-13 15:00:00','11.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.619906994067257 53.49782599473685)','4326'),'','Земетчино',10143,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (142.950096380101201 53.590509994735477)','4326'),'','Оха',20916,'2019-02-13 15:00:00','11.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.188643993988087 53.931312994730774)','4326'),'','Спасск',7232,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (138.181733880764966 56.460900694714198)','4326'),'','Аян',854,'2019-02-13 15:00:00','11.000000000000000',-28.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.044307994008186 53.689246994734035)','4326'),'','Вадинск',5020,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.838509094036837 54.41617939472507)','4326'),'','Явас',7713,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (135.575094181127781 62.647793894820879)','4326'),'','Хандыга',6166,'2019-02-13 15:00:00','10.000000000000000',-36.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.245143993980228 54.074531994728972)','4326'),'','Торбеево',9112,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (143.241081580060666 59.364392094736957)','4326'),'4','Охотск',3488,'2019-02-13 15:00:00','11.000000000000000',-28.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.926642994163764 54.35391999472575)','4326'),'','Сасово',26871,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (150.798861679008667 59.560476794740147)','4326'),'4','Магадан',92711,'2019-02-13 15:00:00','12.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.447992794230395 54.268521794726688)','4326'),'','Чучково',2717,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (143.237838980061127 64.566375994900866)','4326'),'','Усть-Нера',5434,'2019-02-13 15:00:00','11.000000000000000',-42.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.176036994407454 55.130866994718843)','4326'),'','Спас-Клепики',5610,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (150.937000578989426 60.10222079475021)','4326'),'','Палатка',3757,'2019-02-13 15:00:00','12.000000000000000',-31.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.814918994179315 54.575683994723462)','4326'),'','Пителино',2094,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (151.299069878939008 59.578098094740476)','4326'),'','Ола',6229,'2019-02-13 15:00:00','12.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.613122394346611 55.45259329471687)','4326'),'','Курлово',6348,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (147.181533979512153 63.047439994835585)','4326'),'','Мяунджа',1618,'2019-02-13 15:00:00','12.000000000000000',-44.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.550246994355355 55.14642699471873)','4326'),'','Тума',5961,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (149.632476979170974 61.133162994774146)','4326'),'','Усть-Омчуг',3273,'2019-02-13 15:00:00','12.000000000000000',-39.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.877653294448976 55.660376494715898)','4326'),'','Рошаль',21167,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.543758394495462 55.578402994716257)','4326'),'','Шатура',33308,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.620157094484831 55.928786194714959)','4326'),'','Костерёво',8641,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.459948894507129 55.931031294714941)','4326'),'','Петушки',13915,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.015080194429856 55.990397594714793)','4326'),'','Собинка',18510,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.946557994439388 56.015092994714706)','4326'),'','Лакинск',14895,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.670866494338576 55.614996794716077)','4326'),'','Гусь-Хрустальный',56676,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.012197494430261 56.132228694714499)','4326'),'','Ставрово',7591,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.407520294375232 56.128889894714497)','4326'),'4','Владимир',352681,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.329441094386091 55.99395869471477)','4326'),'','Радужный',18369,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.296763993973038 56.216468994714354)','4326'),'','Решетиха',6806,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.275485993976005 55.988101994714796)','4326'),'8','Ворсма',10793,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.461740493950074 56.238215694714327)','4326'),'','Дзержинск',234284,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.516818993942408 56.103415994714524)','4326'),'','Богородск',34676,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.127810993857359 55.188022994718445)','4326'),'','Шатки',8930,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.805410593902238 54.866649094720849)','4326'),'','Первомайск',13828,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.840812893897308 55.398946294717177)','4326'),'','Арзамас',104831,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.785300093905036 55.38001939471728)','4326'),'','Выездное',7826,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.492724993806561 55.03482099471951)','4326'),'','Лукоянов',14218,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.209251693846028 55.531378894716468)','4326'),'','Вад',6700,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.198031993847579 56.14955099471446)','4326'),'','Кстово',67375,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.094024993862064 55.807769994715322)','4326'),'','Дальнее Константиново',4274,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.891452993751059 55.568862994716305)','4326'),'','Бутурлино',6399,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.544845993799306 55.596545994716159)','4326'),'','Перевоз',9041,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.776318493767086 55.783750394715412)','4326'),'','Большое Мурашкино',5080,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (27.608184996156908 57.81330499471904)','4326'),'','Печоры',11164,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (27.921060996113358 57.062907994715147)','4326'),'','Пыталово',5819,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.009025996101112 57.540538994717267)','4326'),'','Палкино',2926,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.348086994801108 55.602550194716144)','4326'),'','Московский',17363,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.97811739485261 56.18540309471441)','4326'),'','Солнечногорск',52554,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.395545394794496 55.687759994715769)','4326'),'','Заречье',6087,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.272796294811592 55.671150694715848)','4326'),'','Одинцово',141429,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.475762194783329 55.570321694716299)','4326'),'','Коммунарка',4599,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.363302494798987 55.705143894715718)','4326'),'','Новоивановское',5834,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.340414194802172 55.821743994715291)','4326'),'','Красногорск',137587,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.858538194869254 55.729361294715623)','4326'),'','Звенигород',19384,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.695280194891978 55.575548594716253)','4326'),'','Кубинка',21017,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.988762494851123 55.614960194716083)','4326'),'','Голицыно',17301,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.973588794853242 55.55907839471633)','4326'),'','Калининец',20882,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.011098594848008 55.632157194716015)','4326'),'','Большие Вязёмы',12487,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.03950569484406 55.597178694716163)','4326'),'','Краснознаменск',39273,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.206896594820755 55.640227494715965)','4326'),'','Лесной Городок',8806,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.173982194825335 55.599444194716142)','4326'),'','Кокошкино',11225,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.177185894824895 55.839497694715213)','4326'),'','Нахабино',39913,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.191978594822835 55.6838590947158)','4326'),'','Власиха',25699,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.859548194869113 55.914599294714982)','4326'),'','Истра',34995,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.120644894832765 55.859780794715171)','4326'),'','Дедовск',29480,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.198461594821943 55.996417294714782)','4326'),'','Зеленоград',223902,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.141052794829925 55.979693194714812)','4326'),'','Андреевка',10858,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.054288594841999 56.075854094714607)','4326'),'','Поварово',8118,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.233223694817099 56.036999094714666)','4326'),'','Менделеево',7465,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.218862894819097 54.870770294720813)','4326'),'','Протвино',37261,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.117160494833243 54.886516594720675)','4326'),'','Кремёнки',10854,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.52208419533369 44.605443395050372)','4326'),'4','Севастополь',416283,'2019-02-13 15:00:00','2.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.595988294905794 55.195977894718396)','4326'),'','Ермолино',10329,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.60432709532224 44.618104295049697)','4326'),'','Инкерман',11918,'2019-02-13 15:00:00','2.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.219356094819027 54.973675794719988)','4326'),'','Оболенск',4835,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.600258795322809 44.509291295055583)','4326'),'','Балаклава',22620,'2019-02-13 15:00:00','2.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.982169994852043 55.515375394716564)','4326'),'','Селятино',12823,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.739967794885757 55.387990594717223)','4326'),'','Наро-Фоминск',62268,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.543753795330666 44.775507895041265)','4326'),'','Кача',5173,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.41955329479115 54.915524694720432)','4326'),'','Серпухов',126728,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.072945094839405 55.545419994716418)','4326'),'','Апрелевка',24004,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.958499394716135 55.121233494718908)','4326'),'','Михнево',11583,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.454532794786289 55.142660294718759)','4326'),'','Чехов',69028,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.301746494807553 55.472816794716756)','4326'),'','Троицк',37591,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.485480494781974 55.255802894718009)','4326'),'','Столбовая',5132,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.567354394770589 55.506913594716607)','4326'),'','Щербинка',32321,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.545305594773652 55.430884094716994)','4326'),'','Подольск',223896,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.620768594902351 55.611577794716091)','4326'),'','Новый Городок',9154,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.75427199474457 55.444793994716925)','4326'),'','Домодедово',112052,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.846189194731764 56.010427394714732)','4326'),'','Пушкино',108253,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.927731894720409 56.080765194714594)','4326'),'','Лесной',8515,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.858795894730008 56.063028094714603)','4326'),'','Правдинский',10496,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.94381789471818 56.162628194714429)','4326'),'','Ашукино',9954,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.93058669472002 56.137426994714474)','4326'),'','Софрино',15326,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.559885294632416 54.854208994720949)','4326'),'','Озёры',25891,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.077258894699604 54.886597994720695)','4326'),'','Ступино',66463,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.438988494649251 55.459502894716849)','4326'),'','Белоозёрский',18162,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.259061194674288 55.421993794717061)','4326'),'','Бронницы',21925,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.027718794567299 54.96555729472005)','4326'),'','Луховицы',29893,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.767012094603587 55.0938742947191)','4326'),'','Коломна',144253,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.681682394615457 55.3225179947176)','4326'),'','Воскресенск',93824,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.339612994523875 54.944245994720212)','4326'),'','Белоомут',6266,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.974370494713924 55.608603394716113)','4326'),'','Октябрьский',17222,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.035622294566195 55.382976494717248)','4326'),'','Егорьевск',71285,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.856579394730325 55.762261294715479)','4326'),'','Реутов',94180,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.867511694728805 55.818890294715288)','4326'),'','Восточный',12400,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.964648794715274 55.803622494715341)','4326'),'','Балашиха',260704,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.467083094784542 56.010447294714744)','4326'),'','Лобня',84225,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.514241694777972 55.93414909471494)','4326'),'','Долгопрудный',98788,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.491357794781166 56.081768794714577)','4326'),'','Некрасовский',10562,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.561353994771416 56.071887094714597)','4326'),'','Марфино',4234,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.733935794747396 55.909492794714993)','4326'),'','Мытищи',187119,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.520367994777118 56.242252994714313)','4326'),'','Деденево',6513,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.832628894733659 55.92048979471496)','4326'),'','Королёв',220947,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.780433094740921 55.969332894714832)','4326'),'','Черкизово',3998,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.920073894721483 55.971409794714837)','4326'),'','Ивантеевка',69265,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.92791929472039 55.920458394714977)','4326'),'','Загорянский',7407,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.946400894717826 55.65338979471592)','4326'),'','Томилино',31159,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.617660594763585 55.75071779471552)','4326'),'2','Москва',12380700,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.708714194750904 55.557149594716343)','4326'),'','Видное',59334,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.444989594787614 55.889284694715052)','4326'),'','Химки',232066,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.750277994745119 55.590277994716196)','4326'),'','Развилка',9778,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.7310226947478 55.586901094716197)','4326'),'','совхоза имени Ленина',4742,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.908481494723091 55.582582294716239)','4326'),'','Лыткарино',56360,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.850116594731219 55.631065294716024)','4326'),'','Дзержинский',51306,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.893769994725147 55.67831419471581)','4326'),'','Люберцы',189123,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.867307294728832 55.661667994715891)','4326'),'','Котельники',41308,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.798280394320834 51.836718794768537)','4326'),'','Эртиль',10740,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.616954994206871 51.095145994786876)','4326'),'','Новохопёрск',6380,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.470366994227277 51.843932994768345)','4326'),'','Жердевка',14556,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.960776994159019 51.450347994777772)','4326'),'','Грибановский',15255,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.161799994270233 51.993899994764966)','4326'),'','Токарёвка',6795,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.590941994210496 51.684981994772066)','4326'),'','Терновка',5671,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.075168994143098 51.368014994779827)','4326'),'','Борисоглебск',63678,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.59368989448852 52.604187694752255)','4326'),'4','Липецк',510152,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.739999594468152 52.050692894763699)','4326'),'','Усмань',19739,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.477210194365526 52.165835694761192)','4326'),'','Добринка',10300,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.955161994438193 52.496119994754359)','4326'),'','Грязи',46289,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.26029999439573 52.633201994751687)','4326'),'6','Петровское',6100,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.762286994325841 52.089057994762875)','4326'),'','Мордово',6077,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.44775679450882 53.212540994741339)','4326'),'','Лев Толстой',8800,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.810206594458371 52.86133689474741)','4326'),'','Доброе',5484,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.170550694547416 55.918616894714987)','4326'),'','Покров',17708,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.872125494588964 56.159222894714432)','4326'),'','Киржач',27439,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.496940994501976 50.982078994789873)','4326'),'','Лиски',54788,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.432597994510935 50.713000994797305)','4326'),'','Каменка',8594,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.030779794427666 51.09679989478682)','4326'),'','Бобров',19956,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.422358994512358 51.159373994785177)','4326'),'','Давыдовка',5258,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.72812299433059 51.115409994786326)','4326'),'','Таловая',11736,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.587321994350191 50.828490994794095)','4326'),'','Бутурлиновка',25230,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.410700894513987 51.643969194773064)','4326'),'','Новая Усмань',29270,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.39104659451673 51.614925094773746)','4326'),'','Новая Усмань',29270,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.417392994373841 51.488498994776812)','4326'),'','Анна',16729,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.932101394441403 51.843818794768353)','4326'),'','Верхняя Хава',8154,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.924502994303261 50.64514899479925)','4326'),'','Воробьёвка',4103,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.134345994413252 51.648147994772941)','4326'),'','Панино',6238,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.575610994212632 51.082877994787204)','4326'),'','Новохопёрский',7465,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.005186594152832 50.797097194794979)','4326'),'','Урюпинск',39171,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.65078379461977 55.781335694715409)','4326'),'','Павловский Посад',65800,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.441189794648942 55.855351094715161)','4326'),'','Ногинск',102247,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.991557594711537 55.920649894714977)','4326'),'','Щёлково',118962,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.651481794619663 55.812848094715314)','4326'),'','Большие Дворы',5073,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.056769094702453 55.954617994714873)','4326'),'','Фрязино',58942,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.139708194690918 55.90167729471505)','4326'),'','Свердловский',6674,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.383522394656971 56.006116494714753)','4326'),'','Черноголовка',21925,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.145765494690067 56.121089494714496)','4326'),'','Красноармейск',26594,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.92258239458193 55.577139094716273)','4326'),'','Куровское',21246,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.445347694648355 56.133940194714484)','4326'),'','Фряново',11182,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.956909094577156 55.704310094715701)','4326'),'','Ликино-Дулёво',30345,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.858501094590849 55.607804994716112)','4326'),'','Давыдово',10918,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.849134094592159 55.744809294715544)','4326'),'','Дрезна',11831,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.785872094600968 55.879298294715106)','4326'),'','Электрогорск',23028,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.116332894554965 55.56295669471632)','4326'),'','Авсюнино',4947,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.979003794574076 55.808327794715325)','4326'),'','Орехово-Зуево',120184,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.100294694696395 55.618082594716064)','4326'),'','Ильинский',10915,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.076181594699747 55.63115959471601)','4326'),'','Быково',10834,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.004238494709767 55.645261594715961)','4326'),'','Малаховка',25606,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.119986294693653 55.597280094716176)','4326'),'','Жуковский',107815,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.044818094704127 55.635997894715992)','4326'),'','Удельная',15251,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.980075094713129 55.658565194715898)','4326'),'','Красково',23386,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.228209894678585 55.570936094716281)','4326'),'','Раменское',106264,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.062847894701612 55.652441794715912)','4326'),'','Родники',5300,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.113063694694617 55.877422094715101)','4326'),'','Звёздный городок',5737,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.222819194679346 55.718446694715645)','4326'),'','Электроугли',20652,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.196747594682968 55.841370994715206)','4326'),'','Монино',21023,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.17741719468566 55.807032294715327)','4326'),'','Старая Купавна',21937,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.272697094672402 55.831465794715236)','4326'),'','Обухово',10119,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.203270094682061 55.870559294715129)','4326'),'','Лосино-Петровский',24726,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.440571094649023 55.790378494715384)','4326'),'','Электросталь',158222,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.341380994662835 55.725647894715621)','4326'),'','имени Воровского',5136,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.01921099442928 53.920989994730903)','4326'),'','Кораблино',11390,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.605292994486902 54.121352994728397)','4326'),'','Пронск',4818,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.209983394402727 53.475405394737173)','4326'),'','Александро-Невский',3867,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.744010994467587 54.04301099472935)','4326'),'','Новомичуринск',17257,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.682607294336933 53.943380994730632)','4326'),'','Сапожок',3312,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.488273994363979 53.791137994732608)','4326'),'','Ухолово',4644,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.508861194500319 54.726841494722059)','4326'),'','Рыбное',18969,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.91138799444429 54.228332994727161)','4326'),'','Старожилово',5150,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.380538994378981 54.407880094725158)','4326'),'','Спасск-Рязанский',6776,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.742503894467802 54.629568694722941)','4326'),'4','Рязань',532772,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.996957594293178 53.721430094733577)','4326'),'','Сараи',5338,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.466308994367047 54.212546994727333)','4326'),'','Лесной',7833,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.712600994193558 54.02868699472954)','4326'),'','Шацк',6262,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.813098994179569 53.442901994737689)','4326'),'','Моршанск',39583,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.887767994308376 54.318343994726121)','4326'),'','Шилово',14853,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.121108994275893 54.160556994727941)','4326'),'','Путятино',3122,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.413062493956851 52.966933794745529)','4326'),'','Белинский',8151,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.781913994044714 52.873252994747212)','4326'),'6','Гавриловка 2-я',2000,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.319671993969848 53.32662599473948)','4326'),'','Пачелма',7979,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.036024394009338 53.212220394741358)','4326'),'','Башмаково',10205,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.703944593916354 52.458120694755131)','4326'),'','Беково',6567,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.787852993904679 52.259883994759207)','4326'),'','Ртищево',40043,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.21392399384537 52.461505994755065)','4326'),'','Сердобск',33553,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.535476993800614 52.702632994750367)','4326'),'','Колышлей',8049,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.349944293826432 52.053545394763646)','4326'),'','Екатериновка',5995,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.052895893867785 53.184952994741799)','4326'),'','Каменка',37530,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.957034993741928 52.467509994754934)','4326'),'','Малая Сердоба',5353,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.443789994509387 53.58039499473562)','4326'),'','Милославское',4376,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.999999993735948 53.200000994741544)','4326'),'4','Пенза',522823,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.549273994494698 53.823523994732199)','4326'),'','Скопин',27444,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.062983994423192 53.70887799473379)','4326'),'','Ряжск',21666,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.258395994117585 51.989844994765043)','4326'),'','Уварово',24792,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.48239899408641 51.850699994768206)','4326'),'','Мучкапский',6592,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.171762093990445 51.537083994775628)','4326'),'','Балашов',77391,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.75572439404835 51.741027794770737)','4326'),'','Романовка',6832,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.743037993910924 50.946433994790873)','4326'),'','Елань',14138,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.489097993946274 51.94291299476609)','4326'),'','Аркадак',12149,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.556605993797668 50.796790994794975)','4326'),'','Рудня',6841,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.706763093915974 51.186000294784492)','4326'),'','Самойловка',6936,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.822497993760656 50.882701994792583)','4326'),'','Линёво',5807,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.72562799377414 50.699695994797686)','4326'),'','Красный Яр',6427,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.48458099380769 51.499946994776543)','4326'),'','Калининск',15960,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.778907993766722 50.978778994789998)','4326'),'','Жирновск',16247,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.724959994052647 52.654754994751279)','4326'),'','Кирсанов',17042,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.498000994084236 52.327300994757785)','4326'),'','Инжавино',8794,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.255023993978845 52.53982199475351)','4326'),'','Тамала',6797,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.47890099436529 52.896998994746788)','4326'),'','Мичуринск',95864,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.966800994436575 53.243014994740847)','4326'),'','Чаплыгин',12083,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.285098994392271 53.244998994740797)','4326'),'','Первомайский',12024,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.780200994323337 52.892798994746848)','4326'),'6','Дмитриевка',7898,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.443255994231045 52.411597994756072)','4326'),'','Знаменка',5996,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.69921879433462 53.322711094739553)','4326'),'','Староюрьево',6900,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.455359994229362 52.728789994749874)','4326'),'4','Тамбов',288895,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.447204994230496 52.650538994751358)','4326'),'','Строитель',18174,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.499424894223239 52.587041894752574)','4326'),'','Котовск',31136,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.027301994149759 52.13520099476186)','4326'),'','Ржакса',4735,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.369201994241358 53.232200994741014)','4326'),'','Сосновка',8747,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.879001994170395 52.658698994751198)','4326'),'','Рассказово',44760,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.366271994102568 50.974929994790074)','4326'),'','Новониколаевский',9557,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.056445994006495 50.741515994796515)','4326'),'','Преображенская',5463,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.240939994120012 51.199275994784152)','4326'),'','Поворино',17286,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.637248993786443 48.93345999485463)','4326'),'','Ерзовка',6264,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.857696993755759 48.712867994862712)','4326'),'','Средняя Ахтуба',14228,'2019-02-13 15:00:00','4.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.830775993759495 49.060519994850061)','4326'),'','Дубовка',14325,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.756321393769866 48.873189894856829)','4326'),'','Краснооктябрьский',10893,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.589446994071501 49.879844994822392)','4326'),'','Кумылженская',11000,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.730163994051921 49.580607994832164)','4326'),'','Серафимович',9106,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.234387693981724 50.079632894816086)','4326'),'','Михайловка',58380,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.667361994060649 50.529674994802562)','4326'),'','Новоаннинский',16777,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.653951593923324 49.764571094826096)','4326'),'','Фролово',38129,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.979026993878072 49.30628599484146)','4326'),'','Иловля',11278,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.120514393858372 50.351962594807802)','4326'),'','Даниловка',4856,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.562556993796839 49.852687994823263)','4326'),'','Ольховка',5302,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.801642993763565 50.322207994808686)','4326'),'','Котово',22909,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.016172094290496 50.4259518948056)','4326'),'','Калач',19248,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.885333994308716 50.093230994815684)','4326'),'','Петропавловка',5250,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.225615994122151 48.422198994873682)','4326'),'','Чернышковский',5190,'2019-02-13 15:00:00','4.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.752253994188045 50.408290994806137)','4326'),'','Нехаевская',4704,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.499114994084081 48.536387994869322)','4326'),'','Обливская',9543,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.082660994002843 48.362914994875943)','4326'),'','Нижний Чир',4700,'2019-02-13 15:00:00','4.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.524062993941399 48.692698994863434)','4326'),'','Калач-на-Дону',25133,'2019-02-13 15:00:00','4.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.844146994036045 48.605140994866723)','4326'),'','Суровикино',19387,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.67474399378122 47.956241994892025)','4326'),'','Малые Дербеты',6434,'2019-02-13 15:00:00','4.000000000000000',4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.653125993923439 47.968593994891499)','4326'),'','Октябрьский',5950,'2019-02-13 15:00:00','4.000000000000000',4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.05889099386696 48.676364994864059)','4326'),'','Новый Рогачик',7061,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.785167993765853 48.477431994871559)','4326'),'','Светлый Яр',11957,'2019-02-13 15:00:00','4.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.563795893796666 48.704584794863024)','4326'),'','Краснослободск',16996,'2019-02-13 15:00:00','4.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.516803993803215 48.710677994862785)','4326'),'4','Волгоград',1015590,'2019-02-13 15:00:00','4.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.777984293766856 48.782101994860156)','4326'),'','Волжский',326602,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.476081993808876 48.810126994859132)','4326'),'','Городище',21702,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.280864994253655 48.193870994882523)','4326'),'','Тацинская',11276,'2019-02-13 15:00:00','4.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.959937994298336 48.292438994878673)','4326'),'','Горняцкий',8056,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.008044994291637 49.036998994850897)','4326'),'','Кашары',6529,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.828761994177377 48.352378994876368)','4326'),'','Морозовск',26290,'2019-02-13 15:00:00','4.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.669490994199563 48.62787999486585)','4326'),'','Милютинская',2518,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.85411499445226 49.702281994828141)','4326'),'','Кантемировка',11113,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.576485694490913 50.19618739481249)','4326'),'','Россошь',62688,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.149513794411142 49.379969594838919)','4326'),'','Чертково',10814,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.396610394376744 50.167764594813356)','4326'),'','Верхний Мамон',8561,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.638831994482231 50.403613994806264)','4326'),'','Подгоренский',5750,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.139966294412467 50.452021394804838)','4326'),'','Павловск',25081,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.554475394354768 49.93244979482072)','4326'),'','Богучар',11162,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.725104994191824 49.628993994830559)','4326'),'','Вёшенская',9519,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.13894999427341 49.793971994825135)','4326'),'','Казанская',4721,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.962079994437232 48.297269994878484)','4326'),'','Краснодарський',344,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.950948794438787 48.338286394876903)','4326'),'','Донецк',48979,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.118560994415454 48.020644994889402)','4326'),'','Зверево',22121,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.265067894395052 48.321080694877566)','4326'),'','Каменск-Шахтинский',91159,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.326010994386579 48.524293194869777)','4326'),'6','Глубокий',8820,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.391853994377414 48.919626394855115)','4326'),'','Миллерово',35873,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.364463194381223 48.725920594862224)','4326'),'','Тарасовский',9017,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.123733994275526 48.169379994883499)','4326'),'','Жирнов',5436,'2019-02-13 15:00:00','4.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.790212394321955 48.175177794883268)','4326'),'','Белая Калитва',41734,'2019-02-13 15:00:00','4.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.859485995008313 52.089343994762856)','4326'),'','Фатеж',5922,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.768336995021009 52.688125994750635)','4326'),'','Кромы',6719,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.302086794946703 52.319215594757992)','4326'),'','Поныри',4801,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.379904294935876 52.084766394762951)','4326'),'','Золотухино',4613,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.504020994918598 52.399577994756314)','4326'),'','Малоархангельск',3359,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.322837994943818 52.499465994754289)','4326'),'','Глазуновка',5540,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.195243995100782 52.853957994747553)','4326'),'','Шаблыкино',2985,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.380111994935845 52.672191994750939)','4326'),'8','Змиёвка',5970,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.39810899507254 53.12651799474277)','4326'),'','Хотынец',3670,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.722098995027444 52.967601994745507)','4326'),'','Нарышкино',9987,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.986678994990619 52.896079994746771)','4326'),'','Знаменка',11849,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.195315994822366 50.810740994794578)','4326'),'','Короча',5903,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.069247694979119 52.968543294745501)','4326'),'4','Орёл',319550,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.694109394892145 51.236022994783177)','4326'),'','Пристень',5148,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.732020994886867 51.034369994788506)','4326'),'','Прохоровка',9170,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.767466995299536 52.583499994752657)','4326'),'','Трубчевск',13921,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.075949595256596 52.316132994758021)','4326'),'','Суземка',8922,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.075438995117466 52.128489994762006)','4326'),'','Дмитриев-Льговский',6845,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.494571995198314 52.15602099476142)','4326'),'','Севск',6847,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.571667395187582 52.572231994752883)','4326'),'8','Локоть',9557,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.788485995157401 52.416152994755976)','4326'),'','Комаричи',8027,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.068297995257652 53.097735994743267)','4326'),'','Выгоничи',4858,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.14572499510767 52.509417994754109)','4326'),'','Дмитровск',5332,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.366828795216094 53.242377794740833)','4326'),'4','Брянск',407256,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.100615995253158 53.369975994738795)','4326'),'6','Сельцо',16957,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.996757995128412 53.124190994742825)','4326'),'','Карачев',18392,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.506400995196664 52.827598994748023)','4326'),'','Навля',14840,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.780978995019247 52.44810499475534)','4326'),'6','Тросна',2662,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.35150109507903 52.330619294757724)','4326'),'','Железногорск',99683,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.832400995012087 50.833621994793965)','4326'),'','Ракитное',10418,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.771949995020499 50.792064994795098)','4326'),'','Пролетарский',8977,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.23224299495643 50.68301799479817)','4326'),'','Томаровка',7983,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.270854995090261 51.190707994784361)','4326'),'','Суджа',5684,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.485427994921181 50.785235994795286)','4326'),'','Строитель',24185,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.558913994910959 50.676467994798358)','4326'),'','Северный',10138,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.276244994950304 51.211078994783819)','4326'),'','Обоянь',13422,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.137351994969642 51.062304994787745)','4326'),'','Ивня',7573,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.576011995047779 51.647277994772963)','4326'),'','Иванино',2620,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.477492995061496 51.623195994773553)','4326'),'','имени Карла Либкнехта',7870,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.283999895088428 51.690658694771948)','4326'),'','Льгов',19905,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.658862995036237 51.659465994772702)','4326'),'','Курчатов',39395,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.118045994972327 51.417705994778579)','4326'),'','Медвенка',4316,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.292968995087179 51.846328994768299)','4326'),'','Конышёвка',3473,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.179603994963749 51.739432994770787)','4326'),'4','Курск',443212,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.937194994997505 51.653869994772812)','4326'),'','Прямицыно',5314,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.283713395227672 51.275256194782195)','4326'),'','Тёткино',3743,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.63730989517844 51.339131494780553)','4326'),'','Глушково',4781,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.897090995142285 51.414233994778677)','4326'),'','Коренево',5598,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.683505995172013 51.570537994774803)','4326'),'','Рыльск',16221,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.555450295189836 51.921439294766593)','4326'),'','Хомутовка',3731,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.655227995036761 50.800700994794859)','4326'),'','Красная Яруга',7948,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.447814095204826 53.864715594731635)','4326'),'','Людиново',39239,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.945716995274715 54.014193994729709)','4326'),'','Бетлица',3800,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.735446995164786 53.748542994733214)','4326'),'','Жиздра',5509,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.302607995225038 54.074321994728983)','4326'),'','Киров',31039,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.032397995262649 54.411799994725122)','4326'),'','Спас-Деменск',4377,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.105517995113267 53.933387994730751)','4326'),'','Думиничи',5718,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.978953995130894 54.487292994724349)','4326'),'','Мосальск',4165,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.318555495222824 54.781304294721579)','4326'),'','Угра',4586,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.345820995079826 54.099658994728649)','4326'),'','Сухиничи',15424,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.230483995095874 54.050517994729276)','4326'),'','Середейский',1751,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.002231994988449 53.448993994737585)','4326'),'','Болхов',11087,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.780101995019365 54.037101994729412)','4326'),'','Козельск',16273,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.959117994994443 54.051665994729241)','4326'),'','Сосенский',11210,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.137000994969689 53.811797994732352)','4326'),'','Белёв',13448,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.500026994919153 54.122359994728399)','4326'),'','Суворов',17829,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.244843794954676 54.097094894728698)','4326'),'','Чекалин',964,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.690242994753483 52.780711994748877)','4326'),'6','Красная Заря',2088,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.446628994787382 52.854114994747562)','4326'),'6','Хомутово',4196,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.358794994799609 53.266395994740456)','4326'),'6','Корсаково',1485,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.349596094661692 52.324387894757855)','4326'),'','Долгоруково',5343,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.278388994671595 52.146827994761594)','4326'),'','Тербуны',7313,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.488452994642365 52.613814994752062)','4326'),'','Елец',105989,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.969355894714624 52.693165894750543)','4326'),'','Измалково',4015,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.116187994694187 53.141833994742512)','4326'),'','Ефремов',36181,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.926719994581354 52.387797994756546)','4326'),'','Задонск',9601,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.127592994553396 53.012614594744733)','4326'),'','Лебедянь',20117,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.657120594618881 53.424752594737953)','4326'),'','Куркино',5113,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.415458695209324 53.452662494737538)','4326'),'','Фокино',13238,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.159179794548997 53.253309494740684)','4326'),'','Данков',19600,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.15380499524575 53.623115994734995)','4326'),'','Старь',4718,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.338099995220098 53.601001994735334)','4326'),'','Дятьково',27535,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.131398994692063 51.8292175947687)','4326'),'','Касторное',3527,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.363799994659708 51.545899994775404)','4326'),'','Нижнедевицк',5839,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.786651494600854 51.577921694774638)','4326'),'','Хохольский',7549,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.756979594604978 51.562450194775032)','4326'),'','Хохол',7510,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.21294899454152 51.654879694772795)','4326'),'4','Воронеж',1023570,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.901112394584928 51.656860294772727)','4326'),'','Латная',7359,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.342143994523532 51.910380994766854)','4326'),'','Рамонь',8381,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.022185994568062 51.690402994771944)','4326'),'','Семилуки',26617,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.866260994868178 52.607848994752167)','4326'),'','Покровское',4225,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.028605994845577 52.222735994759979)','4326'),'','Колпна',5850,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.608848994764806 52.425452994755794)','4326'),'','Ливны',48327,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.529574894775841 52.055263694763596)','4326'),'6','Долгое',4028,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.239924994816157 52.810466994748353)','4326'),'','Верховье',7060,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.893153994864434 52.902419994746673)','4326'),'','Залегощь',5074,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.576076994908568 53.278983994740258)','4326'),'','Мценск',39181,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.041907994843719 52.972938994745427)','4326'),'','Новосиль',3346,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.863337994729378 50.764426994795869)','4326'),'','Новый Оскол',18930,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.685302994893362 51.298488994781579)','4326'),'','Кировский',2628,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.534659994775133 51.283713994781955)','4326'),'','Губкин',87405,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.803782994737666 50.941905994790972)','4326'),'','Чернянка',14900,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.749900994884371 51.419551994778551)','4326'),'','Солнцево',4163,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.833201994733578 51.298037994781595)','4326'),'','Старый Оскол',221254,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.913189594861635 51.870820994767733)','4326'),'','Щигры',15963,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.12257799483249 51.621745994773583)','4326'),'','Тим',3059,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.724219994748751 51.848979994768236)','4326'),'','Кшенский',5710,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.262405294813028 51.887675094767381)','4326'),'','Черемисиново',3482,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.643905794620728 51.080556994787251)','4326'),'','Репьёвка',5332,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.399928094654683 50.649164194799134)','4326'),'6','Бирюч',7269,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.077243994560405 50.864901994793094)','4326'),'8','Острогожск',32944,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.686715394614765 50.629936394799671)','4326'),'','Алексеевка',38626,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.0349159947055 51.521560994776003)','4326'),'','Горшечное',5691,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.216005394541085 51.309049994781319)','4326'),'','Нововоронеж',31560,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (131.998631481625637 43.369534995120041)','4326'),'','Вольно-Надеждинское',6694,'2019-02-13 15:00:00','11.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.160254994688053 53.978511994730162)','4326'),'','Узловая',52825,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (131.885576781641362 43.115067795135133)','4326'),'4','Владивосток',606589,'2019-02-13 15:00:00','11.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.995974994710927 54.087970994728813)','4326'),'','Шварцевский',4780,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.185362881599644 43.357037695120788)','4326'),'','Артём',103925,'2019-02-13 15:00:00','11.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.290942994669862 54.011012994729761)','4326'),'','Новомосковск',127214,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.0621367816168 43.298628595124249)','4326'),'','Трудовое',18522,'2019-02-13 15:00:00','11.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.318336694666051 53.965650994730339)','4326'),'','Донской',64403,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.266560994673256 54.350627494725778)','4326'),'','Венёв',14198,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.532699994636211 53.969899994730291)','4326'),'','Кимовск',26591,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.890555894586392 54.225277994727172)','4326'),'','Октябрьский',5510,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.150511894689409 54.837448994721093)','4326'),'','Кашира',39929,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.027537994567318 54.230216994727137)','4326'),'','Михайлов',10807,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.722332994609808 54.467838494724553)','4326'),'','Серебряные Пруды',9358,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.881813694587606 54.758569394721789)','4326'),'','Зарайск',23951,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.28153199453196 54.370803994725563)','4326'),'','Захарово',3500,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.661339694896704 55.08972499471912)','4326'),'','Белоусово',8726,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.611912994903584 55.095173794719081)','4326'),'','Обнинск',109365,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.748899994884518 55.033799994719537)','4326'),'','Жуков',12505,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.657556394897227 55.178357894718509)','4326'),'','Балабаново',25505,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.701899994751855 53.940299994730651)','4326'),'','Липки',9011,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.632085794761572 53.934658794730737)','4326'),'','Советск',7347,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.813418994736331 53.995276994729949)','4326'),'','Бородинский',6020,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.929915994720112 53.926711994730844)','4326'),'','Киреевск',24911,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.959185594855235 54.15249249472803)','4326'),'','Дубна',5883,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.829108994734149 54.085093994728823)','4326'),'','Болохово',9144,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.066721294840271 54.502810294724192)','4326'),'','Алексин',58716,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.762458994882621 54.515605994724055)','4326'),'','Ферзиково',4837,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.61753999476359 54.19303209472757)','4326'),'4','Тула',487841,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.181553794824282 54.729353594722035)','4326'),'','Таруса',9353,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.398978094794025 54.733173294722)','4326'),'','Заокский',6934,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.693328994753045 54.479270794724442)','4326'),'','Ясногорск',15872,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.006322394709485 53.553592794735998)','4326'),'','Волово',3563,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.613968494764094 54.83472129472112)','4326'),'','Пущино',21226,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.093745994697308 53.992293994730005)','4326'),'','Брусянский',3500,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.126964994692678 53.773570994732879)','4326'),'','Богородицк',31363,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.459024594924855 55.012180994719685)','4326'),'','Малоярославец',28401,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.856999995008664 54.969499994720024)','4326'),'','Медынь',7713,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.033470294984099 55.501638294716635)','4326'),'','Можайск',30513,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.185144994962982 55.343237994717477)','4326'),'','Верея',5282,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.510203595056936 56.031463994714699)','4326'),'','Шаховская',10704,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.48138829492175 55.206718594718332)','4326'),'','Боровск',11418,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.194699194961657 55.699890694715727)','4326'),'','Руза',13419,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.639902895038894 56.228890994714348)','4326'),'','Лотошино',5282,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.947732494996032 56.031879594714702)','4326'),'','Волоколамск',21212,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.466297294923848 55.601442794716135)','4326'),'','Тучково',18144,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.660848794896765 53.735520494733393)','4326'),'','Арсеньево',4774,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.910102994862072 53.450927994737548)','4326'),'','Чернь',6367,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.291440494808988 53.707017694733786)','4326'),'','Плавск',15992,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.687900994892999 53.936797994730711)','4326'),'','Одоев',5691,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.517907894777458 54.00446499472983)','4326'),'','Щёкино',58344,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.590084994767416 53.622849594735001)','4326'),'','Тёплое',5007,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.746145395024101 54.388812994725356)','4326'),'','Бабынино',3293,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.285158795088265 54.317554294726136)','4326'),'','Мещовск',3961,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.226439295096441 54.741576594721934)','4326'),'','Юхнов',6292,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.892599981501178 42.82464889515262)','4326'),'','Находка',151420,'2019-02-13 15:00:00','11.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.05009799498179 54.474601994724473)','4326'),'','Воротынск',10620,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.358584281575503 42.884111595149022)','4326'),'','Дунай',7392,'2019-02-13 15:00:00','11.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.162398994966154 54.264300994726753)','4326'),'','Перемышль',3235,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.350910381576625 43.112119395135295)','4326'),'','Большой Камень',38637,'2019-02-13 15:00:00','11.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.997738794989075 54.742624994721901)','4326'),'','Полотняный Завод',4803,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.404904981569075 42.977208395143414)','4326'),'','Фокино',23167,'2019-02-13 15:00:00','11.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.938140594997364 54.677432594722525)','4326'),'','Товарково',14207,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.456375781561917 43.287494495124889)','4326'),'','Смоляниново',6715,'2019-02-13 15:00:00','11.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.259811494952586 54.51010869472411)','4326'),'4','Калуга',342936,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.360090981575354 43.320960095122913)','4326'),'','Шкотово',4973,'2019-02-13 15:00:00','11.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.9321999949982 54.80279999472139)','4326'),'','Кондрово',15405,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.143696781466218 43.141327495133567)','4326'),'','Партизанск',37689,'2019-02-13 15:00:00','11.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.301032295225255 55.630032994716025)','4326'),'10','Новодугино',3865,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.07824618147535 42.892236595148525)','4326'),'','Владимиро-Александровское',5708,'2019-02-13 15:00:00','11.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.299518695225473 55.210356294718309)','4326'),'','Вязьма',54269,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.227371381593827 44.187874095073248)','4326'),'','Ярославский',8535,'2019-02-13 15:00:00','11.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.9968639951284 55.553382994716365)','4326'),'','Гагарин',29916,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.277045495228592 55.826990794715272)','4326'),'','Сычёвка',8246,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.288911281446047 44.160800795074763)','4326'),'','Арсеньев',53543,'2019-02-13 15:00:00','11.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.680365095033252 54.89481119472061)','4326'),'','Мятлево',1627,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.44301128156377 44.203067595072419)','4326'),'','Сибирцево',8355,'2019-02-13 15:00:00','11.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.585181995185707 56.170070994714415)','4326'),'','Зубцов',6456,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.815700981511895 44.598013495050772)','4326'),'','Спасск-Дальний',42020,'2019-02-13 15:00:00','11.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.569507481546168 44.340020195064852)','4326'),'','Черниговка',13046,'2019-02-13 15:00:00','11.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.872967781364736 44.168666695074336)','4326'),'','Чугуевка',12171,'2019-02-13 15:00:00','11.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (133.474221081420239 44.426299895060112)','4326'),'','Яковлевка',4480,'2019-02-13 15:00:00','11.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.00326088162501 43.937043795087313)','4326'),'','Михайловка',9153,'2019-02-13 15:00:00','11.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (131.952075181632125 43.797244695095287)','4326'),'','Уссурийск',168137,'2019-02-13 15:00:00','11.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (131.701332981667036 44.198739495072672)','4326'),'','Липовцы',6286,'2019-02-13 15:00:00','11.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (131.632260781676678 43.951793695086486)','4326'),'','Покровка',10360,'2019-02-13 15:00:00','11.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.167830381602101 44.026258095082291)','4326'),'','Новошахтинский',7414,'2019-02-13 15:00:00','11.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (131.382505981711404 44.403115095061388)','4326'),'','Пограничный',10103,'2019-02-13 15:00:00','11.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.046790281618939 44.742198395043019)','4326'),'','Камень-Рыболов',10909,'2019-02-13 15:00:00','11.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (132.081661581614071 44.425258495060177)','4326'),'','Хороль',10860,'2019-02-13 15:00:00','11.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.894011994864307 50.409152994806107)','4326'),'','Шебекино',43331,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.58464429490737 50.537592294802337)','4326'),'','Дубовое',8627,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.685870994893286 50.534713994802424)','4326'),'','Разумное',18168,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.969093394157852 45.0433244950271)','4326'),'4','Ставрополь',425853,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.493462594224063 45.297599495013941)','4326'),'','Солнечнодольск',11675,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.712115394193624 45.374079595010045)','4326'),'','Изобильный',38263,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.02633039414988 45.132491295022454)','4326'),'','Михайловск',82743,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.863700994311721 46.078418994975131)','4326'),'','Белая Глина',17320,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.975638194156943 45.454815595005918)','4326'),'','Донское',14925,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.514590994221123 45.840507994986694)','4326'),'','Красногвардейское',15997,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.084556994280973 46.184348994970044)','4326'),'','Песчанокопское',11300,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.628089994483723 46.552562994952744)','4326'),'','Кущёвская',30200,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.934268994162707 46.082850994974898)','4326'),'','Городовиковск',8799,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.690974994474978 46.937503994935263)','4326'),'','Самарское',10530,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.417693894513015 47.106558494927789)','4326'),'','Азов',81995,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.649504494341535 46.563081394952263)','4326'),'','Егорлыкская',17262,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.554179994494014 47.076579994929105)','4326'),'','Кулешовка',13692,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.745826494328135 47.085515294928719)','4326'),'','Весёлый',9175,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.304812994389522 46.844844994939415)','4326'),'','Зерноград',24657,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.59847299434864 45.393477895009035)','4326'),'','Красносельский',7676,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.440601794370629 45.407484395008325)','4326'),'','Казанская',10991,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.658186194340338 45.402464095008582)','4326'),'','Гирей',6441,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.57502739435192 45.434441295006955)','4326'),'','Кропоткин',79795,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.69622559433504 45.356511895010939)','4326'),'','Гулькевичи',34347,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.669756594338722 45.439340495006718)','4326'),'','Кавказская',11164,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.783207494462133 46.13500809497242)','4326'),'','Павловская',31327,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.389553994516916 46.321244894963563)','4326'),'','Ленинградская',36940,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.962913994437109 46.321864994963526)','4326'),'','Крыловская',13621,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.810299594458357 46.283792294965316)','4326'),'','Октябрьская',11252,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.154658994410426 45.917323994982937)','4326'),'','Фастовецкая',8573,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.128123994414125 45.854678994986003)','4326'),'','Тихорецк',59597,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.036689594287651 45.108318395023716)','4326'),'','Новокубанск',35251,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.707202994333514 45.953814994981144)','4326'),'','Новопокровская',19684,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.219797894262165 45.495302295003896)','4326'),'','Новоалександровск',26894,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.149028394272008 45.014306395028612)','4326'),'','Старая Станица',7612,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.100226994696406 50.211295994812033)','4326'),'','Валуйки',34296,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.043906994704237 50.08506799481593)','4326'),'','Уразово',6984,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.297152994529789 50.280742994809927)','4326'),'','Ольховатка',3523,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.44530889464837 50.151896194813851)','4326'),'','Вейделевка',6492,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.58614779448957 45.144355595021842)','4326'),'','Красногвардейское',9419,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.420046294512687 45.118326195023187)','4326'),'','Васюринская',13339,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.689672494475147 45.217802695018058)','4326'),'','Усть-Лабинск',42062,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.567082794492222 45.21204759501834)','4326'),'','Воронежская',8562,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.926851094442135 45.307659295013437)','4326'),'','Ладожская',14828,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.787437094461538 45.26417479501567)','4326'),'','Двубратский',8541,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.449518194508585 45.463076495005524)','4326'),'','Кореновск',41828,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.390385694516816 45.391980995009114)','4326'),'','Платнировская',12004,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.229111894400063 45.020113995028311)','4326'),'','Хакуринохабль',4018,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.657423694479647 45.580622094999597)','4326'),'','Выселки',19426,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.275405994393616 45.679553994994649)','4326'),'','Архангельская',8714,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.189834194405528 45.363568095010557)','4326'),'','Тбилисская',25317,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.74053999488568 50.462668994804545)','4326'),'','Маслова Пристань',5890,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.586932994907059 50.595298994800665)','4326'),'4','Белгород',384425,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.865397994729094 50.483699994803892)','4326'),'','Волоконовка',11029,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.892005994586192 49.914729994821286)','4326'),'6','Ровеньки',10646,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.07189899442195 47.89155199489462)','4326'),'','Красный Сулин',39212,'2019-02-13 15:00:00','4.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.944192494439726 48.053030294888117)','4326'),'','Гуково',65336,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.26070399383886 46.41106799495936)','4326'),'','Троицкое',12431,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.656047993923025 46.561179994952361)','4326'),'','Ремонтное',7300,'2019-02-13 15:00:00','4.000000000000000',5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.528315993801606 47.304370994919203)','4326'),'','Кетченеры',3908,'2019-02-13 15:00:00','4.000000000000000',5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.888068993890734 47.117553994927313)','4326'),'','Заветное',6763,'2019-02-13 15:00:00','4.000000000000000',5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.5240249938022 47.776473994899334)','4326'),'','Садовое',6530,'2019-02-13 15:00:00','4.000000000000000',4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.868747994311022 47.640223994904972)','4326'),'','Усть-Донецкий',11361,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.097083994279238 47.582351994907391)','4326'),'','Константиновск',17437,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.171760594129644 47.512817694910304)','4326'),'','Волгодонск',170230,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.021464994150563 47.541865994909067)','4326'),'','Романовская',8248,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.843471594036146 45.335506595012006)','4326'),'','Светлоград',37819,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.09823199413988 47.65058499490452)','4326'),'','Цимлянск',14622,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.272609694115602 46.33852649496275)','4326'),'','Яшалта',4299,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.42086799395576 45.100856995024095)','4326'),'','Благодарный',31720,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.341800993966764 45.910304994983278)','4326'),'','Дивное',14094,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.916285994025998 45.719722994992651)','4326'),'','Ипатово',24966,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.212684993845542 45.369193995010278)','4326'),'','Арзгир',14732,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.512431993943018 46.100688994974057)','4326'),'','Приютное',6010,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.464969994088825 47.148917994925952)','4326'),'','Зимовники',18070,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.270186993837541 46.306998994964218)','4326'),'4','Элиста',104005,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.141486993994661 47.633315994905246)','4326'),'','Котельниково',20489,'2019-02-13 15:00:00','4.000000000000000',5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.764224994047176 47.41116699491463)','4326'),'','Дубовское',8544,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.716485994471419 47.224694894922656)','4326'),'4','Ростов-на-Дону',1114810,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.501517994501341 47.283454994920106)','4326'),'','Чалтырь',15334,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.861361994451251 47.268695994920726)','4326'),'','Аксай',43558,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.742347994467821 47.138526994926394)','4326'),'','Батайск',119807,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.93598699444086 47.755888594900163)','4326'),'','Новошахтинск',109139,'2019-02-13 15:00:00','4.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.701252894473548 47.613540594906077)','4326'),'','Родионово-Несветайская',6439,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.166274294408808 47.395444994915309)','4326'),'','Кривянская',10612,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.10198599441776 47.410659994914631)','4326'),'','Новочеркасск',172817,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.205290394403384 47.669209594903748)','4326'),'','Каменоломни',10716,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.382903994378665 47.321433994918472)','4326'),'','Багаевская',15459,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.028213994288819 46.533633994953632)','4326'),'','Целина',11092,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.211569894402494 47.711916694901994)','4326'),'','Шахты',237233,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.724078994191963 46.700160994945982)','4326'),'','Пролетарск',19623,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.541007994217445 46.47666899495627)','4326'),'','Сальск',59126,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.809918594319214 47.51595099491017)','4326'),'','Семикаракорск',22496,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.051864994146328 46.869868994938315)','4326'),'','Орловский',19354,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.520072294777165 56.345069494714245)','4326'),'','Дмитров',65716,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.483282694782282 56.289395794714288)','4326'),'','Яхрома',13768,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.600303894765993 56.526849494714192)','4326'),'','Вербилки',7019,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.42553879479032 56.562649994714207)','4326'),'','Запрудня',12651,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.352099994800547 56.882499994714642)','4326'),'','Кимры',46771,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.528015994776055 56.730940994714395)','4326'),'','Талдом',13258,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.840488294732552 57.240020594715794)','4326'),'','Калязин',13345,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.513181994778122 56.965454094714858)','4326'),'','Белый Городок',2135,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.295615994808408 57.579341994717481)','4326'),'','Кесова Гора',3768,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.611453994764446 57.361754994716321)','4326'),'','Кашин',15029,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.136085494691415 56.308949694714244)','4326'),'','Сергиев Посад',106007,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.990810694711634 56.254123394714306)','4326'),'','Хотьково',21687,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.173634694686186 56.415810094714196)','4326'),'','Пересвет',13950,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.140448294690806 56.367050594714229)','4326'),'','Скоропусковский',6732,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.24433899467634 56.440506994714184)','4326'),'','Краснозаводск',13515,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.182557194684946 56.493906194714192)','4326'),'','Богородское',9142,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.46652759506302 57.124443694715346)','4326'),'','Лихославль',12025,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.225898794957317 56.911826094714726)','4326'),'','Орша',2240,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.045399894982445 57.345300094716244)','4326'),'','Рамешки',4214,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.23080799509583 57.279498794715956)','4326'),'','Калашниково',4941,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.004199995127372 57.8779979947195)','4326'),'','Удомля',28972,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.049602995260258 57.885203994719575)','4326'),'','Бологое',21845,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.512076995195876 58.895762994730113)','4326'),'','Хвойная',6144,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.906827495280126 58.389008994724129)','4326'),'','Боровичи',53141,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.814472195014581 58.60004489472643)','4326'),'','Пестово',15773,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.879039995005606 57.797324994718934)','4326'),'','Максатиха',7840,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.429728994928944 58.843135994729401)','4326'),'','Устюжна',8859,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.41137299493149 58.461375994724882)','4326'),'','Сандово',3292,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.777565394880526 56.713157194714341)','4326'),'','Конаково',40617,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.735214694886416 56.335554294714242)','4326'),'','Клин',79249,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.32883909480379 56.375267894714213)','4326'),'','Новосиньково',8073,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.137557594830412 56.757385394714404)','4326'),'','Дубна',75176,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.387099995491674 66.857451995028612)','4326'),'','Зеленоборский',6800,'2019-02-13 15:00:00','4.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.180171995659681 65.200095994932568)','4326'),'','Калевала',4028,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.495791995476552 67.374083995062549)','4326'),'','Полярные Зори',15100,'2019-02-13 15:00:00','4.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.413055095488062 67.151441995047691)','4326'),'','Кандалакша',36600,'2019-02-13 15:00:00','4.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.931491995137499 56.507823994714187)','4326'),'','Старица',8116,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.330150995221203 56.259261994714294)','4326'),'','Ржев',60334,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.415450995209326 57.622420994717771)','4326'),'','Красномайский',4905,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.179663695242148 57.031465694715038)','4326'),'','Кувшиново',9428,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.571399995187619 57.588302994717573)','4326'),'','Вышний Волочёк',48844,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.973372995131669 57.040793994715074)','4326'),'','Торжок',46690,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.552170794911895 56.320509694714247)','4326'),'','Высоковск',10676,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.993278795128894 57.421531094716627)','4326'),'','Спирово',5943,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.210570194959445 56.626012194714257)','4326'),'','Изоплит',1644,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.261504594952356 56.513793894714205)','4326'),'','Козлово',3891,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.290991094948247 56.645783994714279)','4326'),'','Редкино',11455,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.920828394999774 56.858674994714605)','4326'),'4','Тверь',414006,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (90.44172098741042 50.380003494806957)','4326'),'','Мугур-Аксы',4270,'2019-02-13 15:00:00','8.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.596907595740877 64.587301294901835)','4326'),'','Костомукша',29356,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.345855995497416 62.082009394801766)','4326'),'','Суоярви',9126,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.093940194279675 56.931544794714767)','4326'),'','Кохма',29258,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.88732899430844 56.775676994714466)','4326'),'','Лежнево',7907,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.010924894152041 56.584042794714236)','4326'),'','Южа',13019,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.379600994239908 56.844100994714573)','4326'),'','Шуя',58795,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.846986994314051 57.007912894714984)','4326'),'','Ново-Талицы',8800,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.853911994173885 56.802417994714489)','4326'),'','Палех',4929,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.109229994277541 57.248755994715815)','4326'),'','Фурманов',35061,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.973739394296409 56.998445194714947)','4326'),'4','Иваново',409285,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.157180994270874 57.440104994716712)','4326'),'','Волгореченск',16804,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.281177994253603 57.380332994716426)','4326'),'','Приволжск',16137,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.72838999419136 57.105224994715257)','4326'),'','Родники',25142,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.237620994259672 57.509318994717113)','4326'),'','Красное-на-Волге',7864,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.511352994221568 57.459186994716823)','4326'),'','Плёс',1984,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.924560594164056 57.220221994715722)','4326'),'','Вичуга',35792,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.140099894134053 57.443099994716754)','4326'),'','Кинешма',85344,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.962230994158816 57.473788194716896)','4326'),'','Наволоки',9814,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.375993094518819 56.293978394714273)','4326'),'','Кольчугино',44125,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.940795994579396 61.509120994784425)','4326'),'','Каргополь',10048,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.12056689441517 56.558550094714235)','4326'),'','Гаврилов Посад',5939,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.67863999447669 56.497194794714204)','4326'),'','Юрьев-Польский',19031,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.385871994378235 56.658332994714279)','4326'),'','Нерль',1959,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.448789294369483 56.419390794714218)','4326'),'','Суздаль',9978,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.413844994513553 57.186844394715557)','4326'),'','Ростов',30824,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.540586294356707 56.855475294714608)','4326'),'','Тейково',33276,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.853769694452311 57.303282694716039)','4326'),'','Гаврилов-Ям',17514,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.537358394496351 57.299563694716042)','4326'),'','Семибратово',6940,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.377601994379397 57.027320994715048)','4326'),'','Комсомольск',8561,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.893370494446799 57.626387694717785)','4326'),'4','Ярославль',603961,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.997097994293156 56.34625749471423)','4326'),'','Камешково',12722,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.573798994352082 57.460654994716826)','4326'),'','Нерехта',21719,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.216231994262657 56.590697994714233)','4326'),'','Савино',5193,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.311675994249363 56.374602994714223)','4326'),'','Ковров',140117,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.848995195288175 59.472902094738686)','4326'),'','Бокситогорск',15494,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.119700994554492 58.503200994725326)','4326'),'','Пошехонье',5868,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.66182909517503 59.497463194739112)','4326'),'','Ефимовский',3668,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.177357295242466 59.512978694739381)','4326'),'','Пикалёво',20732,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.940424994997052 59.396994194737438)','4326'),'','Бабаево',11491,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.329368995082113 59.163829994733881)','4326'),'','Чагода',6389,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.390006995212872 61.790038994792681)','4326'),'4','Петрозаводск',275346,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.162353995244558 60.914290994768535)','4326'),'','Подпорожье',18043,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.536044994914135 61.808433994793241)','4326'),'','Пудож',9183,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.451121994925963 61.006354994770845)','4326'),'','Вытегра',10274,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.916388994721999 59.128695994733327)','4326'),'','Череповец',318107,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.148608994828869 59.199218994734373)','4326'),'','Кадуй',11247,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.500960994640621 59.207034994734492)','4326'),'','Шексна',21195,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.784218894740398 60.031989994748855)','4326'),'','Белозерск',9172,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.971445194714327 60.262201094753529)','4326'),'','Липин Бор',3845,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.37601099465801 59.858809994745485)','4326'),'','Кириллов',7439,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.698127394613174 56.308443094714256)','4326'),'','Карабаново',14923,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.585999994628786 56.373999994714204)','4326'),'','Струнино',13829,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.841899994593163 56.507199994714185)','4326'),'','Балакирево',9808,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.721159894609976 56.393527794714224)','4326'),'','Александров',60205,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.316688994666265 57.526782994717202)','4326'),'','Углич',32496,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.84628209459256 56.73661039471439)','4326'),'6','Переславль-Залесский',40028,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.692534994892355 57.78135699471882)','4326'),'','Бежецк',22697,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.147695194550593 57.257817894715849)','4326'),'','Борисоглебский',5612,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (36.766113694882115 58.163025494721921)','4326'),'','Молоково',2005,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.15690199482772 57.777934994718777)','4326'),'','Сонково',3984,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.862067994729557 58.302268994723235)','4326'),'','Брейтово',3710,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.114730994833586 58.056506994720976)','4326'),'','Красный Холм',5320,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.063005394701584 57.908057194719753)','4326'),'','Новый Некоуз',3816,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.267600994812305 58.665999994727215)','4326'),'','Весьегонск',6455,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.83463699459417 58.050372994720917)','4326'),'','Рыбинск',193341,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (21.891272496952709 55.077994994719205)','4326'),'','Советск',41212,'2019-02-13 15:00:00','3.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.4515949946475 57.784724994718829)','4326'),'','Мышкин',5866,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (22.029357796933489 55.035965594719514)','4326'),'','Неман',11346,'2019-02-13 15:00:00','3.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (22.491362596869173 54.941758394720246)','4326'),'','Краснознаменск',3324,'2019-02-13 15:00:00','3.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (21.227366997045127 54.615577494723077)','4326'),'','Знаменск',4036,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (22.014358996935574 54.408740994725157)','4326'),'','Озёрск',4357,'2019-02-13 15:00:00','3.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (22.201520896909521 54.592143994723301)','4326'),'','Гусев',28511,'2019-02-13 15:00:00','3.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (21.808919996964175 54.63805399472286)','4326'),'','Черняховск',37521,'2019-02-13 15:00:00','3.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (20.22590999718453 54.948226994720187)','4326'),'','Пионерский',11475,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (20.154603997194457 54.941550994720238)','4326'),'','Светлогорск',12014,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (20.475018797149854 54.960036494720093)','4326'),'','Зеленоградск',14308,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (21.107026997061876 54.86025199472089)','4326'),'','Полесск',7115,'2019-02-13 15:00:00','3.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (21.679072996982242 55.04548999471946)','4326'),'','Славск',4330,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.7231089944705 43.585482295107461)','4326'),'5','Сочи',389946,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (21.308057097033895 54.358992294725695)','4326'),'','Железнодорожный',2830,'2019-02-13 15:00:00','1.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.135444993577892 42.132293995195589)','4326'),'','Бежта',8600,'2019-02-13 15:00:00','4.000000000000000',5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (19.94143029722413 54.463626394724578)','4326'),'','Мамоново',8075,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.742793993354155 41.462913995238807)','4326'),'','Ахты',13152,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (20.294053697175045 54.44590189472477)','4326'),'','Корнево',3000,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (20.173440897191831 54.571266594723497)','4326'),'','Ладушкин',4068,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.783660993348462 41.584109995230882)','4326'),'','Курах',5142,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (19.911056297228356 54.655478294722691)','4326'),'','Балтийск',33095,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.424483993398454 41.533537595234193)','4326'),'','Рутул',3958,'2019-02-13 15:00:00','4.000000000000000',4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.116424993441342 42.170382995193201)','4326'),'','Кумух',1930,'2019-02-13 15:00:00','4.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.215087993427609 42.071982995199434)','4326'),'','Вачи',894,'2019-02-13 15:00:00','4.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (20.640512397126816 54.386819094725375)','4326'),'','Багратионовск',6197,'2019-02-13 15:00:00','1.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.630506693369782 42.163808995193605)','4326'),'','Уркарах',5182,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (21.01398999707483 54.447143994724755)','4326'),'','Правдинск',4241,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (21.071943097066757 54.647826494722779)','4326'),'','Гвардейск',13321,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (20.510516597144914 54.706642194722235)','4326'),'4','Калининград',453461,'2019-02-13 15:00:00','3.000000000000000',3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.482557496035195 56.289339294714289)','4326'),'','Себеж',6342,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.65681799601094 56.711669994714342)','4326'),'','Опочка',11545,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.284594996062747 56.830653994714567)','4326'),'','Красногородск',3869,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.368456495911875 56.33506319471423)','4326'),'','Пустошка',4603,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.896962995977511 56.33211899471425)','4326'),'','Идрица',4982,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.917531995974652 57.018420994715008)','4326'),'','Пушкинские Горы',5207,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.357816996052563 57.344630994716248)','4326'),'','Остров',21700,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.037681993591491 43.214423995129202)','4326'),'','Гелдаган',,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.997683993597072 43.240695995127673)','4326'),'','Цоци-Юрт',,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.090785993584113 43.200049995130072)','4326'),'','Курчалой',23610,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.590293693932182 43.564423595108664)','4326'),'','Чегем',17957,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.098714793583 42.968518395143924)','4326'),'','Ведено',3186,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.919062494025624 43.395906395118523)','4326'),'','Тырныауз',20551,'2019-02-13 15:00:00','4.000000000000000',2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.196727993569361 43.218379995128991)','4326'),'','Бачи-Юрт',16485,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.131116093578491 43.203632895129857)','4326'),'','Майртуп',11838,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.282889593557371 43.216561895129097)','4326'),'','Аллерой',11132,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.379867693543872 43.09455809513635)','4326'),'','Ножай-Юрт',8433,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.909213493609386 43.250864595127055)','4326'),'','Мескер-Юрт',10843,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.868891793614999 43.295045495124441)','4326'),'','Аргун',34078,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.890403993611997 43.497142995112611)','4326'),'','Червлённая',10431,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.157783993853187 43.160560995132435)','4326'),'','Дигора',10273,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.774621593628126 43.441562495115839)','4326'),'','Толстой-Юрт',8097,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.220450993844459 43.039840995139635)','4326'),'','Алагир',20270,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.253069293561516 43.266538595126121)','4326'),'','Ойсхара',11267,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.804334494319988 44.544663095053679)','4326'),'','Владимирская',7217,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.0958706935834 43.343902095121571)','4326'),'','Гудермес',51215,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.789944594321994 44.413804095060797)','4326'),'','Мостовской',25006,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.550979993520052 42.444213995176021)','4326'),'','Хебда',2666,'2019-02-13 15:00:00','4.000000000000000',4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.170872894268975 44.782016195040882)','4326'),'','Советская',9021,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.333468993550333 43.506141995112081)','4326'),'','Шелковская',11679,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.125224094275318 44.998697495029454)','4326'),'','Армавир',191568,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.538424993661003 43.133101995134069)','4326'),'','Урус-Мартан',55783,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.385048494239157 44.834654795038105)','4326'),'','Успенское',12409,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.471976993670253 43.166160995132081)','4326'),'','Гехи',12671,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.325342994247464 44.861735495036676)','4326'),'','Коноково',7880,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.621860993649392 43.164168995132208)','4326'),'','Гойты',16177,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.937135494162298 44.331443295065299)','4326'),'','Адыге-Хабль',3886,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.567676993656924 43.228614995128375)','4326'),'','Алхан-Юрт',11100,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.525112594219657 44.3972773950617)','4326'),'','Отрадная',23204,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.163657993713166 43.315833995123235)','4326'),'','Серноводское',,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.050582993728909 43.313674995123343)','4326'),'','Сунжа',64493,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.940868394161782 44.633355895048879)','4326'),'','Невинномысск',117868,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.542808993660387 43.262397995126378)','4326'),'','Алхан-Кала',,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.297358993694559 43.289405995124781)','4326'),'','Самашки',11275,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.739741993632975 43.118648995134897)','4326'),'','Старые Атаги',11500,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.698966993638656 43.316844995123155)','4326'),'4','Грозный',283659,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.786776993626425 43.19672399513027)','4326'),'','Чечен-Аул',8233,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.770213993628744 43.128608995134307)','4326'),'','Новые Атаги',9068,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.906577993609751 43.153941995132811)','4326'),'','Шали',51268,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.176214394407431 44.50936159505558)','4326'),'','Тульский',10825,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.736651993633409 43.226813995128488)','4326'),'','Гикало',9426,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.056498194424087 44.875585295035926)','4326'),'','Гиагинская',13954,'2019-02-13 15:00:00','4.000000000000000',16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.000430993596687 43.164988995132148)','4326'),'','Автуры',16044,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.72421849433114 44.634795295048789)','4326'),'','Лабинск',60971,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.920716493607785 43.188207895130773)','4326'),'','Герменчук',11234,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.104052994417472 44.606207895050332)','4326'),'4','Майкоп',144055,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.349528993269686 41.616153695228782)','4326'),'','Магарамкент',10000,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.496363094362863 44.896499795034828)','4326'),'','Кошехабль',7183,'2019-02-13 15:00:00','4.000000000000000',16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.151632393297234 41.675811795224888)','4326'),'','Касумкент',12000,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.657970594340362 44.768525495041615)','4326'),'','Родниковская',8346,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.834342293341415 42.120647795196334)','4326'),'','Маджалис',6815,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.599912394348443 44.99073799502986)','4326'),'','Михайловская',8245,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.949555893325375 41.952247795207072)','4326'),'','Хучни',3397,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.589539494349893 44.889010195035233)','4326'),'','Курганинск',49037,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.388584893264252 41.871046995212261)','4326'),'','Белиджи',11583,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.391922295769415 59.622195494741234)','4326'),'','Коммунар',21575,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.462807094228332 43.887495895090133)','4326'),'','Сторожевая',9952,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.119787993301671 42.169145195193259)','4326'),'','Мамедкала',11052,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.548963895747551 59.569803194740345)','4326'),'','Форносово',6443,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.185107994266986 43.916137795088531)','4326'),'','Медногорский',5478,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.186420093292398 42.1152433951967)','4326'),'','Дагестанские Огни',28887,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.415730995766097 59.722255994743016)','4326'),'','Пушкин',100753,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.191790594266052 43.952875495086438)','4326'),'','Преградная',6566,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.29380679327744 42.057698695200344)','4326'),'','Дербент',122354,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.433263995763657 59.684852994742307)','4326'),'','Павловск',16495,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.79029889432195 44.109265495077658)','4326'),'','Псебай',10613,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.122168993579734 42.539374995170121)','4326'),'','Агвали',2644,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.612121995738761 59.726497994743056)','4326'),'','посёлок Тельмана',14047,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.9119789941658 43.771559395096752)','4326'),'','Карачаевск',20976,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.877364495701837 59.541277694739854)','4326'),'','Тосно',39077,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.585361094211265 43.854975195091974)','4326'),'','Зеленчукская',21025,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.047361393729354 43.239084295127739)','4326'),'','Нестеровская',22938,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.765956095717346 59.640555794741573)','4326'),'','Ульяновка',12688,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.056764994145645 44.225024795071199)','4326'),'4','Черкесск',123128,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.217860993566418 42.665549995162351)','4326'),'','Ботлих',10400,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.604478995739825 59.748443994743461)','4326'),'','Колпино',144412,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.972255694157411 44.085896095078951)','4326'),'','Усть-Джегута',30245,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.287929093695872 43.19262519513051)','4326'),'','Ачхой-Мартан',21000,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.180129993710871 43.238570995127795)','4326'),'','Ассиновская',10248,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.786108395714542 59.703479894742657)','4326'),'','Никольское',21160,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.408121493679133 43.178773195131349)','4326'),'','Валерик',9000,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.058227995815859 59.852633994745396)','4326'),'','Стрельна',13350,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.369735993684479 43.16884539513191)','4326'),'','Катар-Юрт',12806,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.075997995813388 59.808730994744565)','4326'),'','Новоселье',2810,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.605142095878925 60.256650994753386)','4326'),'','Рощино',14315,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.959760595829568 60.09810839475017)','4326'),'','Сестрорецк',38812,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.253799395371033 57.979141394720315)','4326'),'','Валдай',15152,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.522857995472783 58.24766499472269)','4326'),'','Крестцы',9905,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.300462595364543 58.373839394723973)','4326'),'','Окуловка',11587,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.536948394496413 44.423103195060293)','4326'),'','Хадыженск',22430,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.686656995310777 57.868052994719442)','4326'),'','Озёрный',10591,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (41.743698794189228 43.44109889511585)','4326'),'','Теберда',8709,'2019-02-13 15:00:00','4.000000000000000',5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.226356996070859 59.375827994737136)','4326'),'','Ивангород',10736,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.741047994467998 44.461804595058176)','4326'),'','Апшеронск',40244,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (135.283368181168441 43.74256649509843)','4326'),'','Ольга',3782,'2019-02-13 15:00:00','11.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.70349849447323 44.355565095063994)','4326'),'','Нефтегорск',5188,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.483859095895813 59.445338394738236)','4326'),'','Волосово',12212,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.953460794438435 44.674024195046684)','4326'),'','Ханская',11549,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.611297996017274 59.376494994737143)','4326'),'','Кингисепп',47969,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (135.575924081127681 44.559456995052848)','4326'),'','Дальнегорск',35556,'2019-02-13 15:00:00','11.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.867992294450325 44.765811495041767)','4326'),'','Белореченск',52322,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.076491995952516 59.896949994746194)','4326'),'','Сосновый Бор',67397,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (135.055497681200109 44.267363695068859)','4326'),'','Кавалерово',14659,'2019-02-13 15:00:00','11.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.616672996016526 60.36666499475578)','4326'),'','Приморск',5791,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.085796895951219 60.446457594757511)','4326'),'','Каменка',8212,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (136.286378981028776 44.758981795042139)','4326'),'','Пластун',5114,'2019-02-13 15:00:00','11.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.130508295805804 59.570627294740341)','4326'),'','Гатчина',96334,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.068036995814492 59.355140994736814)','4326'),'','Сиверский',12545,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.349683095775287 59.412662094737719)','4326'),'','Вырица',12493,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.085940995812003 59.733920994743215)','4326'),'','Красное Село',50251,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.085864995533612 56.258967994714304)','4326'),'','Западная Двина',8467,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.64107699559553 56.496478994714188)','4326'),'','Торопец',12149,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.182677995659336 57.150760994715426)','4326'),'','Холм',3829,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.265319995508634 56.646800994714283)','4326'),'','Андреаполь',7397,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.452285995343402 56.855632994714568)','4326'),'','Селижарово',6166,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.744605995441916 56.923789994714745)','4326'),'','Пено',3845,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.123832995389122 57.140231994715407)','4326'),'','Осташков',16837,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.464683995480875 57.64236099471789)','4326'),'','Демянск',5252,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.698058995309189 57.481044994716946)','4326'),'','Фирово',2199,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.329167893968538 44.230039595070927)','4326'),'','Александрийская',11761,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.065060295397302 57.200950494715613)','4326'),'','Солнечный',2166,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.134968993995564 44.210737695071991)','4326'),'','Минеральные Воды',75974,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.649847995594303 57.971322594720256)','4326'),'','Парфино',7018,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.508231094082809 44.461642895058169)','4326'),'','Курсавка',11815,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.363490495634167 57.989892294720399)','4326'),'','Старая Русса',30901,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.473632993948421 44.148791995075456)','4326'),'','Георгиевск',70803,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.275786195646376 58.520986194725545)','4326'),'4','Великий Новгород',216200,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.060806393866685 43.627356795105023)','4326'),'','Майский',26831,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.202563095656568 58.500039694725302)','4326'),'','Панковка',10299,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.000499994014284 44.712477295044629)','4326'),'','Александровское',27490,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.631099993926512 43.961890995085938)','4326'),'','Новопавловск',26221,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.218635995515129 58.844214994729434)','4326'),'','Малая Вишера',11998,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.014900793873075 43.758754495097477)','4326'),'','Прохладный',58083,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.152924995802682 56.347384994714226)','4326'),'','Новосокольники',8089,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.45172899381226 44.036101995081758)','4326'),'','Курская',12045,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.332917995916823 57.031180994715044)','4326'),'','Новоржев',3678,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.653613993784163 43.735583995098821)','4326'),'','Моздок',40042,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.527921995750479 56.342360994714241)','4326'),'','Великие Луки',96514,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.88416299389128 44.403174995061377)','4326'),'','Зеленокумск',35639,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.144481995803851 56.824782994714511)','4326'),'','Локня',3877,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.594409493792412 44.268863095068774)','4326'),'','Степное',5611,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.945296995831576 57.551204994717317)','4326'),'','Дедовичи',8747,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.985076993738019 44.752204995042504)','4326'),'','Нефтекумск',25152,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.88453089584004 56.973884594714868)','4326'),'','Бежаницы',4328,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.163356993852403 44.780532995040993)','4326'),'','Будённовск',63338,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.111592995947632 58.269954994722902)','4326'),'','Струги Красные',8485,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.334367996055825 57.817397994719094)','4326'),'4','Псков',206730,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.551877995886343 57.765288994718695)','4326'),'','Порхов',10572,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.910333993748424 43.309490895123602)','4326'),'','Карабулак',38973,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.370599995911579 58.42061199472446)','4326'),'','Плюсса',3437,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.911466393748277 43.274532995125654)','4326'),'','Яндаре',8680,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.309678995780853 58.119002994721512)','4326'),'','Сольцы',10317,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.723703294052811 43.914358295088618)','4326'),'','Кисловодск',130007,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.961135695829377 57.828827694719138)','4326'),'','Дно',8800,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.982910093738326 43.30646869512379)','4326'),'','Троицкая',17418,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.128798993718014 43.67726899510216)','4326'),'','Знаменское',10828,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.847501295845195 58.735698994728068)','4326'),'','Луга',36496,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.856501794034315 44.046838895081144)','4326'),'','Ессентуки',104288,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.724807995723072 58.211699994722359)','4326'),'','Шимск',3452,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.496119993388476 42.975539995143492)','4326'),'4','Махачкала',587876,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.874233094031851 44.021651595082538)','4326'),'','Ессентукская',21000,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.311900993692532 43.650588995103696)','4326'),'','Наурская',9377,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.667743995591813 56.279960994714287)','4326'),'','Старая Торопа',1783,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.539440593939261 43.663245595102964)','4326'),'','Дыгулыбгей',20214,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.339187993688732 43.623462995105285)','4326'),'','Надтеречное',8475,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.982844995687159 56.294902994714285)','4326'),'','Кунья',3110,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.217930793984003 43.899631595089446)','4326'),'','Залукокоаже',9993,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.205893993707299 44.797065995040114)','4326'),'','Затеречный',7744,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.53447299533196 59.643199794741591)','4326'),'','Тихвин',58253,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (42.97314659401809 44.105046795077868)','4326'),'','Лермонтов',22741,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.873195993614395 44.164782995074553)','4326'),'','Терекли-Мектеб',7080,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.314762595501747 60.105242494750307)','4326'),'','Новая Ладога',8585,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.53765059393951 43.676755295102183)','4326'),'','Баксан',37782,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.712484693497558 43.843772395092621)','4326'),'','Кизляр',48237,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.563750195467087 60.139707294750998)','4326'),'','Сясьстрой',13305,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.095070094001116 44.029099895082162)','4326'),'','Горячеводский',36761,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.645137993646152 44.662230995047324)','4326'),'','Южно-Сухокумск',10388,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.343832995497699 59.9170999947466)','4326'),'','Волхов',46076,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.070472494004541 44.022486895082508)','4326'),'','Свободы',17863,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.537162993521967 44.074500995079582)','4326'),'','Тарумовка',5713,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.974937595409848 60.979275994770184)','4326'),'','Олонец',8249,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.093105494001385 44.093928595078509)','4326'),'','Иноземцево',27663,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.777511993488524 43.600265995106589)','4326'),'','Бабаюрт',16130,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.47442109561873 61.57178069478622)','4326'),'','Питкяранта',10751,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.066662594005074 44.041083495081473)','4326'),'3','Пятигорск',145971,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.988801593319906 42.388316795179506)','4326'),'','Новокаякент',6000,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.622737995319675 61.693156994789774)','4326'),'','Пряжа',3542,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.080789894003104 44.237992395070485)','4326'),'','Анджиевский',6460,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.902103993331977 42.388955195179449)','4326'),'','Каякент',11027,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.545773095330389 60.733932294764152)','4326'),'','Лодейное Поле',20135,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.009075094013092 44.142403395075803)','4326'),'','Железноводск',24950,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.617554593928382 43.49226509511287)','4326'),'4','Нальчик',239040,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.609117393929573 43.319190495123024)','4326'),'','Кашхатау',5390,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.14284169385526 43.480104095113582)','4326'),'','Терек',19426,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.851714193895795 43.55661929510913)','4326'),'','Нарткала',30497,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.963828993462577 42.387134995179579)','4326'),'','Гуниб',2544,'2019-02-13 15:00:00','4.000000000000000',5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.538970693800131 43.18999579513067)','4326'),'','Беслан',37063,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.834105993480634 42.2382619951889)','4326'),'','Цуриб',1789,'2019-02-13 15:00:00','4.000000000000000',1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.305388993832644 43.175818995131493)','4326'),'','Ардон',19453,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.868969693475783 42.687031395161029)','4326'),'','Шамилькала',4830,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.060171293449173 42.502240295172413)','4326'),'','Гергебиль',5464,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.682109993780202 43.024592995140537)','4326'),'4','Владикавказ',308190,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.646610593785148 43.230958295128225)','4326'),'','Кантышево',17347,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.323260993412553 42.430694995176871)','4326'),'','Леваши',11026,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.809197793762507 43.169289195131896)','4326'),'4','Магас',6880,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.344592993409577 42.277636995186448)','4326'),'','Акуша',4697,'2019-02-13 15:00:00','4.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.649886993784691 43.099971995136045)','4326'),'','Заводской',16630,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.121962393440576 42.826090595152543)','4326'),'','Буйнакск',63888,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.124848195806585 61.038528494771683)','4326'),'','Приозерск',18844,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.818618993761199 43.208068395129594)','4326'),'','Экажево',17734,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.665370993364924 42.453341995175435)','4326'),'','Сергокала',7627,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.873083795841634 61.121167494773843)','4326'),'','Кузнечное',4390,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.765907993768543 43.217778395129002)','4326'),'','Назрань',113288,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.203892695795584 61.517926494784675)','4326'),'','Лахденпохья',7512,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.587721493793339 43.510051095111841)','4326'),'','Малгобек',36114,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.57667769337727 42.710599395159598)','4326'),'','Карабудахкент',16861,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.254060895788594 60.557098694760022)','4326'),'','Сосново',7209,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.901826293749615 43.187077795130847)','4326'),'','Сурхахи',11793,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.871334293475456 43.199904895130061)','4326'),'','Кизилюрт',35762,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.244206995650767 59.346324994736648)','4326'),'','Любань',4615,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.837651993758548 43.283655995125116)','4326'),'','Плиево',15249,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.838096993480086 43.021823995140721)','4326'),'','Дубки',5406,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.691230995727746 61.702739994790058)','4326'),'','Сортавала',18830,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.811642493762164 43.262029795126395)','4326'),'','Барсуки',11153,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.293708993416665 43.050410995138982)','4326'),'','Тюбе',6999,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.672725795591116 59.124697294733288)','4326'),'','Чудово',15093,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.580848993515893 43.242743995127555)','4326'),'','Хасавюрт',138420,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.060954395676283 59.756935894743606)','4326'),'','Мга',10285,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.496791393388392 42.945517895145315)','4326'),'','Тарки',15544,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.98553309568678 59.88139539474593)','4326'),'','Кировск',25705,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.397410993402225 42.989287995142668)','4326'),'','Семендер',13931,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.010577995544097 59.450324994738324)','4326'),'','Кириши',52494,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.040366695679143 59.973929594747709)','4326'),'','посёлок имени Морозова',10712,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.033695495680075 59.940430994747032)','4326'),'','Шлиссельбург',14803,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.5866569956031 59.842399994745207)','4326'),'','Назия',4865,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (31.324960995639525 59.875022994745805)','4326'),'','Приладожский',5792,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.646041995734038 60.02400599474867)','4326'),'','Всеволожск',66245,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.930303995694462 59.847693994745285)','4326'),'','Дубровка',6965,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.525270395750848 60.159162494751406)','4326'),'','Токсово',5677,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.29312869578316 60.218693694752623)','4326'),'','Агалатово',5155,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.669743896009141 60.532537994759451)','4326'),'','Советский',7064,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.744050995998791 60.709216994763544)','4326'),'','Выборг',79897,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.870103595981245 61.111254194773544)','4326'),'','Светогорск',15827,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.13034009594503 60.952610194769498)','4326'),'','Каменногорск',6781,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.163764695801174 60.121179094750616)','4326'),'','Песочный',8522,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (29.707158495864729 60.197075094752165)','4326'),'','Зеленогорск',14524,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.37582999577165 59.807456994744541)','4326'),'','Шушары',43430,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.207805995795038 60.143706994751071)','4326'),'','Сертолово',50899,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.575076995743913 59.809058994744596)','4326'),'','Металлострой',27925,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.316228995779948 59.93873199474703)','4326'),'4','Санкт-Петербург',5225690,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.394813995769006 60.068557994749568)','4326'),'','Бугры',6154,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.279567295785046 60.083701794749871)','4326'),'','Парголово',12225,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.4458471957619 60.046067094749105)','4326'),'','Мурино',7023,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.561452995745814 59.947417994747177)','4326'),'','Янино-1',5109,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.492522795755402 60.109759394750384)','4326'),'','Кузьмоловский',10098,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.475434995757784 60.058024994749353)','4326'),'','Новое Девяткино',13120,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.655817495732677 59.796399394744348)','4326'),'','посёлок имени Свердлова',9804,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.630954995736136 59.782927994744092)','4326'),'','Понтонный',8734,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.802026995712318 59.772662994743932)','4326'),'','Отрадное',25481,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (30.629722995736309 59.929294994746826)','4326'),'','Старая',8868,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.076683194699683 44.56094469505279)','4326'),'','Геленджик',69341,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.071887494561153 44.098474695078259)','4326'),'','Туапсе',63417,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.98801769471202 44.929588895033049)','4326'),'','Крымск',56939,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.533905994636044 44.370734495063168)','4326'),'','Архипо-Осиповка',7853,'2019-02-13 15:00:00','4.000000000000000',12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.295450394669231 44.842204595037707)','4326'),'','Ахтырский',20863,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.157818894688397 44.864952795036487)','4326'),'','Абинск',36986,'2019-02-13 15:00:00','4.000000000000000',11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.494406494641531 44.849995995037276)','4326'),'','Черноморский',8512,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.388964894656205 44.845979295037502)','4326'),'','Холмская',17585,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.570261494630977 44.854574995037048)','4326'),'','Ильский',24831,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.67812529461596 44.853420995037098)','4326'),'','Северская',24867,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.136361294552167 44.634265295048827)','4326'),'','Горячий Ключ',34585,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.842682094593052 44.904043495034422)','4326'),'','Афипский',19956,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.907142394584078 44.923072695033426)','4326'),'','Энем',19091,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.156847395106126 44.938281595032635)','4326'),'','Щебетовка',3434,'2019-02-13 15:00:00','2.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.188269395101756 44.914340895033881)','4326'),'','Курортное',326,'2019-02-13 15:00:00','2.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (35.238127195094812 44.963347795031304)','4326'),'','Коктебель',2844,'2019-02-13 15:00:00','2.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.316886994805451 44.894271995034956)','4326'),'','Анапа',73410,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.260719494813266 44.989706595029908)','4326'),'','Витязево',7936,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.549258994773098 44.835357995038059)','4326'),'','Раевская',10020,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.383221594796218 44.900285595034617)','4326'),'','Анапская',16107,'2019-02-13 15:00:00','4.000000000000000',7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.769071094742507 44.723957795044001)','4326'),'','Новороссийск',262250,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.939529194718773 44.6515717950479)','4326'),'','Кабардинка',7550,'2019-02-13 15:00:00','4.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.696895594752547 44.787027995040631)','4326'),'','Гайдук',7484,'2019-02-13 15:00:00','4.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.844797694592764 44.253359295069643)','4326'),'','Новомихайловский',10792,'2019-02-13 15:00:00','4.000000000000000',13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (37.860879294729727 44.864091795036558)','4326'),'','Нижнебаканская',8277,'2019-02-13 15:00:00','4.000000000000000',10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.188543795240918 44.531063295054402)','4326'),'','Советское',579,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.219525895236607 44.513143095055391)','4326'),'','Восход',448,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.853478195287558 44.752296295042484)','4326'),'','Бахчисарай',26215,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.409539295210145 44.677111995046516)','4326'),'','Алушта',28919,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.962255595272417 44.834761795038112)','4326'),'','Почтовое',3147,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.102485795252889 44.952145695031895)','4326'),'4','Симферополь',336430,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.864545295286021 44.631345495048983)','4326'),'','Куйбышево',2368,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.93828409457975 44.986434095030084)','4326'),'','Яблоновский',32039,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.994717994571893 44.92128619503351)','4326'),'','Тахтамукай',5413,'2019-02-13 15:00:00','4.000000000000000',14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.090700094558528 44.981582795030349)','4326'),'','Тлюстенхабль',5668,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.190962494544571 44.883377495035504)','4326'),'','Адыгейск',12689,'2019-02-13 15:00:00','4.000000000000000',15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (27.815685396128025 58.743065994728163)','4326'),'','Гдов',3971,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (28.086978996090256 59.117259994733175)','4326'),'','Сланцы',33300,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.818229991673235 58.360499994723817)','4326'),'','Верхняя Тура',9214,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.481011391720173 58.698169694727618)','4326'),'','Качканар',40036,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.789657991677217 58.636439994726842)','4326'),'','Лесной',49338,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.867396991666375 58.618426994726633)','4326'),'','Нижняя Тура',20782,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.714677191548446 58.071351994721098)','4326'),'','Нижняя Салда',17376,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.554831991570701 58.043597994720855)','4326'),'','Верхняя Салда',43887,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.675242991414741 57.984412994720358)','4326'),'','Верхняя Синячиха',9780,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.694999991411983 57.850810994719303)','4326'),'','Алапаевск',37857,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.595973991564968 59.052733994732264)','4326'),'','Новая Ляля',12087,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.809337991535273 58.861701994729685)','4326'),'','Верхотурье',8748,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.803695792092853 59.408417094737651)','4326'),'','Березники',146626,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.779593992096217 59.649436994741698)','4326'),'','Соликамск',95191,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.683080292109651 59.418025094737814)','4326'),'','Усолье',6110,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.586123191983951 59.15938609473379)','4326'),'','Александровск',13108,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.26615499202849 59.33214909473643)','4326'),'','Яйва',10033,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.043127991502722 56.754982194714422)','4326'),'','Верхнее Дуброво',4983,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.850453591529551 56.69546489471432)','4326'),'','Арамиль',14781,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.32059359146411 56.814970594714516)','4326'),'','Заречный',27619,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.414256991451076 56.761641994714438)','4326'),'','Белоярский',12087,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.573892591568047 56.972468194714871)','4326'),'','Верхняя Пышма',65781,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.468879991582654 56.991630994714924)','4326'),'','Среднеуральск',21982,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.397662991453387 57.116122994715312)','4326'),'','Малышева',9407,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.458183391444948 57.00523399471497)','4326'),'','Асбест',66108,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.404286491452453 57.370646994716346)','4326'),'','Реж',37706,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.678348991414303 57.091529994715238)','4326'),'','Рефтинский',16205,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.878089991664908 57.736388994718517)','4326'),'','Черноисточинск',3814,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.762328991681017 58.281756994723018)','4326'),'','Кушва',29131,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.902698991661474 58.063064994721003)','4326'),'','Горноуральский',3651,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.950846591654766 57.90514899471971)','4326'),'','Нижний Тагил',356773,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.394431991593024 58.037658994720772)','4326'),'','Свободный',8403,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.037444991642715 58.35706299472379)','4326'),'','Красноуральск',23508,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.300029991745369 56.661899994714311)','4326'),'','Нижние Серги',9552,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.124190991769851 56.444537994714189)','4326'),'','Михайловск',9306,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.086806991635854 56.69834099471435)','4326'),'','Дегтярск',15974,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.165858991624845 56.442107994714178)','4326'),'','Полевской',62718,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.943118991655858 56.904857994714703)','4326'),'','Первоуральск',125495,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.910872991660334 56.800013994714469)','4326'),'','Ревда',62209,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.823024991672568 56.964145994714848)','4326'),'','Билимбай',6000,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.323365891742114 57.228209494715749)','4326'),'','Староуткинск',3094,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.138949991628586 57.26383599471589)','4326'),'','Верх-Нейвинский',5217,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.095817991634597 57.247046994715809)','4326'),'','Новоуральск',82594,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.066592691638661 57.426527094716675)','4326'),'','Кировград',20305,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.952033991654609 57.377719994716394)','4326'),'','Верхний Тагил',11357,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.809321491535272 56.503017494714214)','4326'),'','Сысерть',20964,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.2106929916186 57.492473994716995)','4326'),'','Невьянск',23767,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.812011991534902 56.909789994714721)','4326'),'','Берёзовский',56052,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.608249991563255 56.839103994714556)','4326'),'4','Екатеринбург',1500390,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.53269059185218 56.425570294714177)','4326'),'','Арти',12890,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.898391991940493 56.801307994714492)','4326'),'','Ачит',4971,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.729230591824823 57.246190794715815)','4326'),'','Шаля',6524,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.054324991779559 56.851039994714569)','4326'),'','Бисерть',9814,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.413687192147151 58.290905694723129)','4326'),'','Полазна',12976,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.313525992161097 57.735309994718499)','4326'),'','Звёздный',9049,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.424544692145638 58.453457094724804)','4326'),'','Добрянка',33194,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.748655592100526 58.03974469472081)','4326'),'','Сылва',8324,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.587695991983722 58.941524994730706)','4326'),'','Углеуральский',9250,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.555057991988278 58.842406994729416)','4326'),'','Губаха',20645,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.802846091953782 58.105055994721361)','4326'),'','Лысьва',63083,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.653499991974556 59.049251994732195)','4326'),'','Кизел',16173,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.821074991951242 58.282054994723026)','4326'),'','Чусовой',45546,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.729312991964001 58.283687994723067)','4326'),'','Лямино',4525,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.325057991881089 58.374000994723971)','4326'),'','Горнозаводск',11511,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.833388991949526 58.566596994726055)','4326'),'','Гремячинск',9208,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.331336991184202 61.315051994779012)','4326'),'6','Югорск',37150,'2019-02-13 15:00:00','6.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.858127991250079 61.19885599477589)','4326'),'8','Пионерский',4957,'2019-02-13 15:00:00','6.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.046340991084676 61.473044994783407)','4326'),'8','Зеленоборск',2233,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.57353999115049 61.362098994780304)','4326'),'6','Советский',29456,'2019-02-13 15:00:00','6.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.02207199080965 59.330279994736422)','4326'),'8','Мортка',3506,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.483382991023845 61.678859994789363)','4326'),'8','Коммунистический',2019,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.9083329908255 59.592402994740702)','4326'),'','Междуреченский',11149,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.884774490828761 59.721016594742963)','4326'),'8','Луговой',1507,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (67.411818990616183 59.651790994741731)','4326'),'8','Кондинское',2953,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.803626990979268 60.129119994750781)','4326'),'6','Урай',40559,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.444762990750817 61.549872994785588)','4326'),'','Талинка',3559,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.300170992023752 63.84433699486798)','4326'),'','Вуктыл',10430,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.780585990843264 56.964118994714845)','4326'),'','Винзили',12320,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.542273990876453 57.153533994715431)','4326'),'4','Тюмень',744554,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.539260990737645 56.509292994714194)','4326'),'','Заводоуковск',25408,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.267188990775537 56.312377994714247)','4326'),'','Упорово',6296,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (67.39254799061888 56.818595994714528)','4326'),'','Юргинское',4546,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.312751990769186 56.654933994714291)','4326'),'','Ялуторовск',38838,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.271998590914052 58.041374294720825)','4326'),'','Тавда',34074,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (67.07176999066354 57.40559399471654)','4326'),'','Ярково',7017,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.172324990788752 57.665194994718021)','4326'),'','Нижняя Тавда',6846,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.971641990816664 58.809100994728972)','4326'),'8','Куминский',2758,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.352469991320454 59.42744099473795)','4326'),'','Гари',2237,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.673430991275787 61.160449994774865)','4326'),'8','Таёжный',2074,'2019-02-13 15:00:00','6.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.990153991370896 61.017913994771156)','4326'),'','Пелым',3253,'2019-02-13 15:00:00','6.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.805285991257442 61.197005994775829)','4326'),'8','Малиновский',2541,'2019-02-13 15:00:00','6.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.246531991196022 56.950694994714809)','4326'),'','Пышма',9784,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.712153991270391 56.84616099471458)','4326'),'','Камышлов',26573,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.634208991002836 56.519568994714191)','4326'),'','Шатрово',5688,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.879756591386261 57.349309994716272)','4326'),'','Артёмовский',31167,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.764804991123867 57.3937109947165)','4326'),'','Байкалово',5789,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.730243991128674 57.014815994714986)','4326'),'','Талица',16105,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.38491799103754 57.617969994717726)','4326'),'','Туринская Слобода',5955,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.640632991001937 57.058982994715116)','4326'),'','Тугулым',5803,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.697551991133231 58.04145399472084)','4326'),'','Туринск',17305,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.06377799122145 57.674041994718095)','4326'),'','Ирбит',37405,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.328605990906183 56.475379994714189)','4326'),'','Исетское',7479,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.55661109101365 58.519667794725521)','4326'),'','Таборы',2100,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.727103990850708 57.041526994715063)','4326'),'','Боровский',17489,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.894622990827386 56.894069994714663)','4326'),'','Богандинский',10348,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.076704492054866 60.401783694756531)','4326'),'','Красновишерск',15644,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.475275192138575 60.404680694756586)','4326'),'','Чердынь',4686,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.012320691646217 59.762904894743734)','4326'),'','Карпинск',27638,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.733489992102641 60.743034094764347)','4326'),'','Ныроб',4945,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.079635991636849 59.937869994747011)','4326'),'','Волчанск',9376,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.193533791620986 59.764473994743767)','4326'),'','Краснотурьинск',58581,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.574042991568021 59.605190494740953)','4326'),'','Серов',98041,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.960516991653428 60.150159994751213)','4326'),'','Североуральск',27148,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.417258291589846 60.697328694763264)','4326'),'','Ивдель',16378,'2019-02-13 15:00:00','6.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.86193499138875 59.173888994734035)','4326'),'','Сосьва',8695,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.917796991380975 56.415450994714199)','4326'),'','Каменск-Уральский',170922,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.885615991385457 56.399188994714208)','4326'),'','Мартюш',3961,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.035023291364659 56.904738894714711)','4326'),'','Сухой Лог',34213,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.052077391362282 56.768340694714446)','4326'),'','Богданович',29421,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.939162991238796 56.258655994714296)','4326'),'','Далматово',13015,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.579081991288916 56.290912994714276)','4326'),'','Катайск',12891,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (127.987967982183918 49.618552994830885)','4326'),'','Константиновка',5412,'2019-02-13 15:00:00','10.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (128.069884982172539 50.09801899481554)','4326'),'','Тамбовка',7374,'2019-02-13 15:00:00','10.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (128.650969982091652 49.621154994830817)','4326'),'','Поярково',6965,'2019-02-13 15:00:00','10.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (128.003127982181837 50.358142994807615)','4326'),'6','Ивановка',6360,'2019-02-13 15:00:00','10.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (129.107192982028153 50.371283994807236)','4326'),'','Екатеринославка',9383,'2019-02-13 15:00:00','10.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.730632991128623 67.496055995070847)','4326'),'','Заполярный',1555,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.66650399071996 63.715514994862446)','4326'),'','Белоярский',20142,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.800916290840433 66.815162995025929)','4326'),'','Харп',6053,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.04009999108554 67.49495699507078)','4326'),'4','Воркута',59231,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.615746890727024 66.537538695008564)','4326'),'4','Салехард',48313,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.386183090758962 66.65963919501614)','4326'),'','Лабытнанги',26549,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (127.514265782249865 50.333915394808336)','4326'),'','Чигири',9402,'2019-02-13 15:00:00','10.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (127.527160982248077 50.290526994809639)','4326'),'4','Благовещенск',224419,'2019-02-13 15:00:00','10.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.557126691987982 65.995730994976299)','4326'),'','Усинск',39025,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.161625392043028 65.115503494928191)','4326'),'','Печора',40653,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.00923899122904 61.928264994796919)','4326'),'8','Агириш',2296,'2019-02-13 15:00:00','6.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.131579991629621 66.039748994978851)','4326'),'','Инта',26983,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.434757190891418 62.144635994803799)','4326'),'','Нягань',57765,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.424300991032069 63.191512994841133)','4326'),'8','Игрим',7477,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.648429990861658 62.545253994817251)','4326'),'8','Приобье',6783,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.045066990806447 62.459540994814297)','4326'),'6','Октябрьское',3094,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.886161990828569 62.516005994816254)','4326'),'8','Андра',1529,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.053565990944463 63.935245994871899)','4326'),'6','Берёзово',7050,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.490256989770074 55.603385994716142)','4326'),'','Саргатское',8028,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (74.362555989648641 55.371032994717318)','4326'),'','Горьковское',5451,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (74.938003989568543 55.433589994716989)','4326'),'','Нижняя Омка',4821,'2019-02-13 15:00:00','7.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (74.58242798961804 55.049090994719428)','4326'),'','Калачинск',22781,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (75.706016989461645 55.563933994716336)','4326'),'','Усть-Тарка',3819,'2019-02-13 15:00:00','7.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (74.639518989610096 56.094584994714566)','4326'),'','Большеречье',10427,'2019-02-13 15:00:00','7.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (77.308539989238554 54.364928994725631)','4326'),'','Купино',13781,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (76.582343989339648 54.712203994722181)','4326'),'','Чистоозёрное',5628,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (77.671882989187978 54.09681299472868)','4326'),'','Баган',5510,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (78.0323719891378 53.734469994733416)','4326'),'','Карасук',27196,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (75.962195989425993 55.216960994718264)','4326'),'','Татарск',23956,'2019-02-13 15:00:00','7.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (78.667594989049391 54.703967994722255)','4326'),'','Здвинск',4986,'2019-02-13 15:00:00','7.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (76.739028989317845 55.681033994715797)','4326'),'','Венгерово',6616,'2019-02-13 15:00:00','7.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (76.75960498931498 55.308063994717692)','4326'),'','Чаны',8229,'2019-02-13 15:00:00','7.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (78.322229389097444 55.445425794716911)','4326'),'','Куйбышев',44246,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (78.347815989093888 55.351783994717437)','4326'),'','Барабинск',29122,'2019-02-13 15:00:00','7.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (78.56356798906387 52.919703994746385)','4326'),'','Яровое',18159,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (78.330684189096274 53.336428794739327)','4326'),'','Бурла',4026,'2019-02-13 15:00:00','7.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (78.646250989052362 52.989242794745138)','4326'),'','Славгород',30186,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.556487989760853 54.205005994727394)','4326'),'','Павлоградка',7154,'2019-02-13 15:00:00','7.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.882102989715534 53.780356994732792)','4326'),'','Русская Поляна',6171,'2019-02-13 15:00:00','7.000000000000000',-16.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (74.696036989602234 54.170615994727818)','4326'),'','Нововаршавка',6093,'2019-02-13 15:00:00','7.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.637435989749576 54.586673994723348)','4326'),'','Таврическое',12669,'2019-02-13 15:00:00','7.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (75.082305989548459 54.839362994721078)','4326'),'','Оконешниково',4825,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (74.79749868958811 54.154066994728005)','4326'),'','Черлак',10472,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (74.092223989686289 55.002612994719762)','4326'),'','Кормиловка',9783,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.371528989786597 54.991374994719862)','4326'),'4','Омск',1178390,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.026870989834578 54.703849994722269)','4326'),'','Азово',5997,'2019-02-13 15:00:00','7.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (71.349364990068096 55.564895994716316)','4326'),'','Называевск',11249,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (71.25998699008052 54.904891994720536)','4326'),'','Исилькуль',23151,'2019-02-13 15:00:00','7.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (71.925879989987834 54.93946799472026)','4326'),'','Москаленки',9271,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (71.511306990045554 56.006350994714744)','4326'),'','Крутинка',6878,'2019-02-13 15:00:00','7.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.699004989880223 55.156714994718655)','4326'),'','Любинский',10435,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.637946989888704 54.960658994720092)','4326'),'','Марьяновка',8720,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.923888989848919 55.240088994718114)','4326'),'','Красный Яр',5206,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (73.02780198983443 54.94896699472018)','4326'),'','Лузино',8964,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.196616989950158 55.870555994715119)','4326'),'','Тюкалинск',10326,'2019-02-13 15:00:00','7.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (67.887153990550033 55.064662994719306)','4326'),'','Петухово',10537,'2019-02-13 15:00:00','6.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (67.90946199054693 55.56825599471631)','4326'),'','Частоозерье',2749,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (68.308906990491323 55.805537994715344)','4326'),'','Бердюжье',5158,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (67.685401990578114 55.945128994714921)','4326'),'','Армизонское',4776,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (69.235228990362387 55.645736994715968)','4326'),'','Казанское',6174,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (71.760138990010901 54.363894994725648)','4326'),'','Полтавка',6860,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (69.473365990329228 56.110911994714527)','4326'),'','Ишим',65289,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.965537989843114 54.20968999472737)','4326'),'','Одесское',6148,'2019-02-13 15:00:00','7.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (131.089666881752152 47.694658794902715)','4326'),'','Амурзет',5051,'2019-02-13 15:00:00','11.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (72.392821989922837 54.631045994722932)','4326'),'','Шербакуль',6595,'2019-02-13 15:00:00','7.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.728808991268082 54.410705994725134)','4326'),'','Октябрьское',6780,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.540389991294305 54.988410994719878)','4326'),'','Сафакулево',3629,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.664241991137871 54.504119994724171)','4326'),'','Целинное',6228,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (62.747771991265445 55.208907994718317)','4326'),'','Щучье',10310,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.893073991384412 55.283095994717847)','4326'),'','Миасское',9755,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.282500991191007 55.228206994718164)','4326'),'','Шумиха',17582,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.428382991031484 54.909465994720499)','4326'),'','Куртамыш',16906,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.90423199110446 55.341727994717509)','4326'),'','Мишкино',7840,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (63.629481991142711 56.087363994714572)','4326'),'','Шадринск',77031,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.455787991027677 55.374957994717306)','4326'),'','Юргамыш',7541,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.658149991556321 55.999278994714764)','4326'),'','Вишневогорск',4219,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.753993991542984 55.890498994715053)','4326'),'','Касли',16263,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.550902991432039 55.698970994715729)','4326'),'','Кунашак',6296,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.732673991545944 56.087008994714573)','4326'),'','Снежинск',50323,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.698504991689902 55.34432199471749)','4326'),'','Магнитка',4831,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.445937991725046 55.336520994717525)','4326'),'','Куса',17521,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.370089991596416 54.97779499471995)','4326'),'','Чебаркуль',39914,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.108336991632839 55.065303994719294)','4326'),'','Миасс',151856,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.598628991703812 56.055507994714631)','4326'),'','Нязепетровск',11752,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.209540991618766 55.485808994716706)','4326'),'','Карабаш',11178,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.875422991526072 55.490626994716692)','4326'),'','Аргаяш',10284,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.226447991616411 56.052028994714654)','4326'),'','Верхний Уфалей',27879,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.407962991451953 54.889922994720642)','4326'),'','Коркино',34967,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.175014991484367 54.865738494720858)','4326'),'','Первомайский',10904,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.4025546914527 55.159840794718626)','4326'),'4','Челябинск',1198860,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.45379599144556 54.909942994720488)','4326'),'','Роза',12647,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.341578991461176 55.346209994717462)','4326'),'','Долгодеревенское',7700,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.621633191422198 55.113195094718954)','4326'),'','Копейск',147573,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.705100991549784 55.760459994715497)','4326'),'','Озёрск',79518,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.551207991571204 55.709922994715676)','4326'),'','Кыштым',37480,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.21137999175771 53.878001994731463)','4326'),'','Верхнеуральск',10054,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.961375991792508 55.704635994715716)','4326'),'','Новобелокатай',6446,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.374541991735001 54.14802599472808)','4326'),'','Межозёрный',7217,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.815555991673605 53.522315994736473)','4326'),'','Фершампенуаз',4368,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.005446991647169 54.373420994725528)','4326'),'','Уйское',7352,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.384635991733589 54.316596994726176)','4326'),'','Учалы',37516,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.551990991431886 54.084548994728834)','4326'),'','Троицк',75231,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.649146991557565 53.812179994732347)','4326'),'','Чесма',6313,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.268273091471386 54.442536394724826)','4326'),'','Южноуральск',37801,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.807090991535581 54.369811994725573)','4326'),'','Пласт',17531,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.234538991476079 54.603564994723207)','4326'),'','Красногорский',12575,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.354396991459389 54.441993994724797)','4326'),'','Увельский',10500,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.313197991465138 54.759120994721783)','4326'),'','Еманжелинск',29921,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.23646499147582 54.787490994721523)','4326'),'','Зауральский',7642,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.679262491692583 55.167421294718594)','4326'),'','Златоуст',167978,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (61.592036991426319 54.828303994721175)','4326'),'','Еткуль',6760,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.620356593092794 56.787795394714479)','4326'),'','Мари-Турек',4573,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.393392093124376 56.705278494714349)','4326'),'','Параньга',5513,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.527689093105693 57.409543394716543)','4326'),'','Лебяжье',3178,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.211417193010519 56.344622994714221)','4326'),'','Балтаси',8115,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.042283693034058 57.278879294715964)','4326'),'','Аркуль',1912,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.000306693039903 57.110111794715294)','4326'),'','Уржум',9975,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.502166092970043 57.505265594717073)','4326'),'','Нема',3491,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.929466793049755 57.557957694717388)','4326'),'','Нолинск',9703,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.337259593271398 58.305352394723265)','4326'),'','Котельнич',24169,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.303594593276081 57.679348394718126)','4326'),'','Арбаж',3245,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.104039093164658 58.014058194720612)','4326'),'','Верхошижемье',4193,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.640680993229154 58.303942994723236)','4326'),'','Мирный',4247,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.056496493171281 58.401308094724257)','4326'),'','Оричи',7496,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.95843659332413 58.770560594728522)','4326'),'','Даровской',6718,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.917313493051445 58.110076094721414)','4326'),'','Кумёны',4767,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.885076493195143 58.536317394725714)','4326'),'','Орлов',6834,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.01194399345588 57.732840994718458)','4326'),'','Тоншаево',4496,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.685554993501313 57.964442994720194)','4326'),'','Вахтан',5223,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (119.764855383328609 53.733541694733432)','4326'),'','Могоча',13442,'2019-02-13 15:00:00','10.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.512542993386205 58.276999994722971)','4326'),'','Свеча',4262,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (118.734122983472062 53.559806994735922)','4326'),'','Ксеньевка',2717,'2019-02-13 15:00:00','10.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.088344993445247 58.316150994723365)','4326'),'','Ленинское',4744,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.895396093332906 56.632714394714263)','4326'),'4','Йошкар-Ола',263190,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.474291993252322 56.762982094714445)','4326'),'','Советский',10356,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.894456793333035 56.915423894714721)','4326'),'','Оршанка',6113,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.916761393190725 56.811432794714506)','4326'),'','Куженер',4984,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.998050793179424 56.430257194714194)','4326'),'','Морки',9176,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.877305493335427 57.301251194716059)','4326'),'','Яранск',16283,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.146916293158696 56.93476169471478)','4326'),'','Сернур',8227,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.740331493215287 57.003290594714933)','4326'),'','Новый Торъял',6055,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.937372293327059 57.605383494717664)','4326'),'','Тужа',4287,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.958697793184903 57.586188794717536)','4326'),'','Советск',15719,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.533831993244029 57.460223994716841)','4326'),'','Пижанка',3750,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (117.55070498363682 52.204761994760375)','4326'),'','Кокуй',6988,'2019-02-13 15:00:00','10.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.788276293626225 57.460639494716801)','4326'),'','Урень',12137,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (117.013709983711578 52.51406899475402)','4326'),'','Чернышевск',12868,'2019-02-13 15:00:00','10.000000000000000',-29.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.084921593724133 57.396694994716505)','4326'),'','Варнавино',3352,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (113.590468984188078 54.443377994724784)','4326'),'','Багдарин',4735,'2019-02-13 15:00:00','9.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.546285493520706 56.332434594714236)','4326'),'','Козьмодемьянск',20682,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (117.695540983616638 52.243190994759559)','4326'),'','Сретенск',6643,'2019-02-13 15:00:00','10.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.974999993600235 57.488055594716961)','4326'),'','Арья',4839,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.25269469342237 56.94040359471478)','4326'),'','Санчурск',4261,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.859489393477098 56.776736594714436)','4326'),'','Килемары',4005,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.544593693520937 57.177344094715522)','4326'),'','Шаранга',6569,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.803356293345715 56.633286894714274)','4326'),'','Медведево',17830,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.208940393428463 57.304933094716041)','4326'),'','Кикнур',4504,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.458286993532951 57.372271994716407)','4326'),'','Тонкино',4794,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.317428993552561 58.3581539947238)','4326'),'','Поназырево',4638,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.775715693627966 57.852869994719342)','4326'),'','Ветлуга',8503,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.519305993663657 58.37256999472396)','4326'),'','Шарья',23866,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.471381993670327 58.394446994724156)','4326'),'','Ветлужский',12128,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.616050993510989 57.673106994718097)','4326'),'','Шахунья',20370,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.028418993731997 58.730853994728008)','4326'),'','Георгиевское',2816,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (113.033164984265653 51.554679994775199)','4326'),'','Горный',11337,'2019-02-13 15:00:00','10.000000000000000',-22.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.856513990971905 54.459022994724634)','4326'),'','Звериноголовское',5608,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.434020991030707 55.952407994714861)','4326'),'6','Каргаполье',7979,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (113.649383984179892 51.918082994766664)','4326'),'','Атамановка',10364,'2019-02-13 15:00:00','10.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.987594990814458 54.789660994721501)','4326'),'','Половинное',5200,'2019-02-13 15:00:00','6.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (113.792670984159926 51.77466199476995)','4326'),'','Новокручининский',10159,'2019-02-13 15:00:00','10.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (114.929946784001629 51.283117694781964)','4326'),'','Могойтуй',11046,'2019-02-13 15:00:00','10.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.333831990905466 55.343978994717482)','4326'),'','Кетово',7251,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (114.540800584055802 51.10576089478657)','4326'),'','Агинское',17943,'2019-02-13 15:00:00','10.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (114.340629984083677 51.623401994773552)','4326'),'','Карымское',12861,'2019-02-13 15:00:00','10.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.808288990839429 55.372256994717326)','4326'),'6','Варгаши',9129,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (113.984252984133249 51.663695994772581)','4326'),'','Дарасун',6896,'2019-02-13 15:00:00','10.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (65.321876990907128 55.454349994716871)','4326'),'4','Курган',326292,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (115.586936983910164 50.943686994790923)','4326'),'','Оловянная',7472,'2019-02-13 15:00:00','10.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.502242990742801 55.273005994717899)','4326'),'','Лебяжье',5787,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (113.500892984200547 52.033408994764066)','4326'),'4','Чита',347088,'2019-02-13 15:00:00','10.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (64.812056990978078 55.653098994715926)','4326'),'','Красный Октябрь',4370,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (115.638282983903025 51.669295994772448)','4326'),'','Первомайский',11334,'2019-02-13 15:00:00','10.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (66.77060699070546 55.808597994715313)','4326'),'','Мокроусово',5137,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (115.699042983894543 50.876666994792757)','4326'),'','Ясногорск',7076,'2019-02-13 15:00:00','10.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (67.252738990638349 55.208320994718321)','4326'),'','Макушино',7896,'2019-02-13 15:00:00','6.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (116.025893983849073 51.85163899476818)','4326'),'','Шилка',12784,'2019-02-13 15:00:00','10.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.291917993556112 56.290349994714269)','4326'),'','Юрино',3138,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (116.646041983762728 51.578788994774605)','4326'),'','Балей',11370,'2019-02-13 15:00:00','10.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.433055593675668 56.83833329471458)','4326'),'','Воскресенское',5937,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (115.550948983915191 52.365973994757013)','4326'),'','Вершино-Дарасунский',5478,'2019-02-13 15:00:00','10.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.120500793719181 57.170603394715499)','4326'),'','Ветлужский',5386,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (116.588340983770777 51.976939994765324)','4326'),'','Нерчинск',14912,'2019-02-13 15:00:00','10.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.166409593712785 57.126834794715343)','4326'),'','Красные Баки',7374,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.501840992691683 57.703724994718264)','4326'),'6','Красногорское',4302,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.64643879267156 58.140119594721703)','4326'),'','Глазов',93995,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.107932592746515 58.244242394722683)','4326'),'','Яр',6446,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.176249992737013 58.668303994727253)','4326'),'','Омутнинск',22442,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.011097892620796 57.97445269472027)','4326'),'','Балезино',14875,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.355268392712084 59.044008294732144)','4326'),'','Песковка',4185,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.244708992727482 58.787472494728704)','4326'),'','Восточный',7117,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.775369592514402 56.421605794714189)','4326'),'','Сигаево',5659,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.262729992585768 58.865420994729696)','4326'),'','Афанасьево',3413,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.034546292478332 56.815437694714525)','4326'),'','Новый',5963,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.819295692508284 56.477333994714179)','4326'),'','Сарапул',98569,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.150070392462254 56.778746794714444)','4326'),'','Чайковский',83056,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.194561292456051 56.265251494714306)','4326'),'','Камбарка',10577,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.86901099250138 57.295314994716016)','4326'),'','Шаркан',6523,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.990611992484439 57.0525049947151)','4326'),'','Воткинск',98134,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.213807792731778 56.44276989471421)','4326'),'','Можга',49733,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.614731592815168 57.10813779471529)','4326'),'','Сюмси',5250,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.005508492621573 56.549545494714202)','4326'),'','Малая Пурга',7768,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.99725119262272 56.525459694714215)','4326'),'','Агрыз',19738,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.377600492569783 56.784661994714448)','4326'),'','Завьялово',9243,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.209416592593193 56.866556994714607)','4326'),'4','Ижевск',643496,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.188439392735312 56.982661594714905)','4326'),'6','Ува',19843,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.158507992600271 57.190009994715588)','4326'),'','Якшур-Бодья',7211,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.138146792742312 57.309496394716085)','4326'),'','Селты',5252,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.75121949293537 57.831645894719173)','4326'),'','Богородское',2591,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.09918029260853 57.546744194717306)','4326'),'','Игра',20624,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.595381792817861 58.358057194723798)','4326'),'','Фалёнки',4812,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.489831592832566 57.754392594718645)','4326'),'','Уни',4338,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.841074092922867 58.840681694729398)','4326'),'','Белая Холуница',10597,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.138860492881413 58.406024094724309)','4326'),'','Зуевка',10697,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.588920993375574 60.737220994764236)','4326'),'','Лальск',3096,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.25540499342199 60.63032899476169)','4326'),'','Луза',10461,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.88375899347372 61.248668994777212)','4326'),'','Вычегодский',12956,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.647628993506594 61.252150994777288)','4326'),'','Котлас',60981,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.160762593435166 61.315165894779014)','4326'),'','Коряжма',37587,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.91893799346883 61.331332994779466)','4326'),'','Сольвычегодск',2217,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.280040993279364 59.848189994745312)','4326'),'','Опарино',3911,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.969648293183376 59.397974194737472)','4326'),'','Мураши',6384,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.978309993321375 61.115703994773689)','4326'),'','Ильинско-Подомское',3682,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.618274993093074 60.334033994755075)','4326'),'','Объячево',5699,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.677590492945619 56.520631394714215)','4326'),'','Малмыж',7591,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.596576195323323 45.440092495006667)','4326'),'','Новосёловское',3362,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.489565995338218 45.768332694990256)','4326'),'','Раздольное',7300,'2019-02-13 15:00:00','2.000000000000000',4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.06139929289219 56.944901494714799)','4326'),'','Кильмезь',5648,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.284267692861171 56.257380194714301)','4326'),'','Сосновка',11420,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.690409095310251 46.113260994973452)','4326'),'','Армянск',22530,'2019-02-13 15:00:00','2.000000000000000',5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.934595292770638 56.773621594714456)','4326'),'','Вавож',5721,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.519262592828454 56.285025494714269)','4326'),'','Кизнер',9320,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.657433693087626 58.539375494725761)','4326'),'','Леваши',3017,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.058944893031736 57.833511494719183)','4326'),'','Суна',2078,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.663902893086721 58.603525694726486)','4326'),'4','Киров',496986,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.671660793085643 58.535708594725683)','4326'),'','Кокуй',1549,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.280262793140139 59.042207394732117)','4326'),'','Юрья',5404,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.459344193115207 58.737341594728086)','4326'),'','Мурыгино',7437,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.177123393015286 58.727781594727965)','4326'),'','Слободской',33334,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.034088893035197 58.54219629472577)','4326'),'','Кирово-Чепецк',74134,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.805385993623844 59.992084994748048)','4326'),'','Кичменгский Городок',5754,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.45276299367292 59.53133799473968)','4326'),'','Никольск',7989,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.089026993445152 60.354205994755496)','4326'),'','Демьяново',5061,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.064769993448536 60.279063994753898)','4326'),'','Подосиновец',3782,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.301466593554778 60.761285194764781)','4326'),'','Великий Устюг',31806,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.785712993348177 60.250529994753279)','4326'),'','Пинюг',1953,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.477824293530233 60.961719494769739)','4326'),'','Красавино',6301,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.934134993605909 61.556373994785787)','4326'),'','Красноборск',4771,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.684242992527096 63.562458494856031)','4326'),'4','Ухта',98293,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.576293992542119 63.433318994850751)','4326'),'','Ярега',7665,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.035763895401374 45.30806189501341)','4326'),'','Мирный',4210,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.855475992364049 63.643744994859432)','4326'),'','Нижний Одес',9203,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.930554592492797 63.58952979485715)','4326'),'','Сосногорск',26670,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (32.707774995447046 45.508596995003209)','4326'),'','Черноморское',10991,'2019-02-13 15:00:00','2.000000000000000',6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.908282992495906 65.008689994922705)','4326'),'','Ижма',3753,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.575249395326281 45.094313795024448)','4326'),'','Новофёдоровка',6493,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.156207992739795 65.438682994945239)','4326'),'','Усть-Цильма',4877,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.127542992047779 56.549766094714215)','4326'),'','Сарс',4964,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.117030295390073 45.383716595009545)','4326'),'','Новоозёрное',7242,'2019-02-13 15:00:00','2.000000000000000',8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.575541792124618 56.88362789471465)','4326'),'','Уинское',4304,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (33.601751595322597 45.131090295022538)','4326'),'','Саки',24156,'2019-02-13 15:00:00','2.000000000000000',9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.905410992078707 57.195716994715596)','4326'),'','Орда',5375,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.203556692037203 56.514307794714185)','4326'),'','Октябрьский',9943,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.395133892010541 57.146392194715432)','4326'),'','Суксун',8158,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.944327992073276 57.428843994716665)','4326'),'','Кунгур',66311,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.726710991964374 56.475646994714211)','4326'),'','Сарана',2337,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.244001792031575 57.360984394716333)','4326'),'','Усть-Кишерть',4629,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.771312991958169 56.604537994714235)','4326'),'','Красноуфимск',39252,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.871395491944234 56.475345294714202)','4326'),'','Натальинск',1645,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.324655492437941 59.32868749473635)','4326'),'','Юрла',4094,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.560653992822694 61.814940994793425)','4326'),'','Корткерос',4700,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.327331992437571 60.304130994754416)','4326'),'','Гайны',4050,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.311660892439754 59.597642494740775)','4326'),'','Кочёво',3504,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.689860992526313 61.684791994789535)','4326'),'','Усть-Кулом',5141,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.989825992345359 59.944385994747122)','4326'),'','Коса',2383,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.088965993166759 62.172481994804684)','4326'),'','Яренск',3660,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.000789693735832 62.235364094806734)','4326'),'','Верхняя Тойма',3940,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.082179993028497 62.358237994810828)','4326'),'','Микунь',9919,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.588819993097175 62.089874394802024)','4326'),'','Жешарт',7613,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (45.767241993629149 64.902480994917326)','4326'),'','Лешуконское',4406,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.706183993220044 63.429545994850599)','4326'),'','Усогорск',5198,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.314700792717737 61.939808294797302)','4326'),'','Сторожевск',1665,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.887927992916339 62.598296994819137)','4326'),'','Емва',13180,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.185378992178933 62.714461994823267)','4326'),'','Троицко-Печорск',6430,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.408072992565543 63.505031994853688)','4326'),'','Водный',6244,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.557038892266405 57.943967294720025)','4326'),'','Уральский',7802,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.582873992262797 57.702384994718287)','4326'),'','Юго-Камский',8019,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.246722992170398 58.0149649947206)','4326'),'4','Пермь',1041880,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.758694292238324 58.081261294721187)','4326'),'','Краснокамск',53964,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.699271092246597 58.57037559472608)','4326'),'','Ильинский',6288,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.963511992349012 58.96367599473102)','4326'),'','Юсьва',4679,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.80173089292834 59.315914094736179)','4326'),'','Нагорск',4500,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.153380992183386 58.78498799472866)','4326'),'','Чёрмоз',3566,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.241823192727878 59.33989709473655)','4326'),'','Кирс',9589,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.006999992899765 60.441256994757417)','4326'),'','Койгородок',2868,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.473819992695589 59.615107994741095)','4326'),'','Рудничный',4458,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.366446992710536 59.420855994737842)','4326'),'','Светлополянск',2768,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.768477992932979 61.627002994787851)','4326'),'','Выльгорт',11756,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.129435992743524 59.781718994744068)','4326'),'','Лесной',4310,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.98411199290296 61.679706994789406)','4326'),'','Краснозатонский',8632,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.834957992923719 61.668973394789077)','4326'),'4','Сыктывкар',243536,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.931701992353446 56.270759994714304)','4326'),'','Янаул',25894,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.806392992510098 57.652350994717963)','4326'),'','Дебёсы',5778,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.07627879219411 56.500681994714185)','4326'),'','Чернушка',32982,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.590762992261709 56.433505994714189)','4326'),'','Куеда',9551,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.915761692355659 57.050387194715114)','4326'),'','Елово',5334,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.586966992262234 56.930186994714759)','4326'),'','Барда',8826,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.46020589227988 57.282920694715976)','4326'),'','Оса',21143,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.971841392347862 57.291822794716012)','4326'),'','Частые',4859,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.715822992383501 57.883617494719573)','4326'),'','Очёр',14151,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.713920992522965 57.89644599471967)','4326'),'6','Кез',10706,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.380030992430243 58.381386794724044)','4326'),'','Сива',4659,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.667484692390232 58.07210449472111)','4326'),'','Верещагино',22261,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.386050992290208 57.7217577947184)','4326'),'','Оханск',7098,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.664134992390693 59.014605994731717)','4326'),'','Кудымкар',31007,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.927207992354077 58.265578994722866)','4326'),'','Карагай',6682,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.331634892297771 57.943422994720031)','4326'),'','Нытва',18863,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.982921293181519 55.768549594715452)','4326'),'','Верхний Услон',,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.744577393214691 55.752260294715548)','4326'),'','Иннополис',96,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.268008193141831 55.201562894718364)','4326'),'','Камское Устье',4496,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.124226593161858 55.782354694715401)','4326'),'4','Казань',1216960,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.927548793050022 54.903484494720537)','4326'),'','Базарные Матаки',,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.546837593103028 55.404335794717149)','4326'),'','Лаишево',8228,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.140620493020364 55.46442119471682)','4326'),'','Рыбная Слобода',7755,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.112891793024225 55.304964894717727)','4326'),'','Алексеевское',11615,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.657091293087674 55.750211094715539)','4326'),'','Пестрецы',7300,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.453909893115956 56.249470994714329)','4326'),'','Большая Атня',3651,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.307204793136385 55.910181394714996)','4326'),'','Высокая Гора',,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.233498493007446 55.891884594715044)','4326'),'','Тюлячи',2943,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.877182793057038 56.090991594714573)','4326'),'','Арск',19681,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.446780192977755 56.010623194714718)','4326'),'','Богатые Сабы',8372,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.763361493072885 54.14837539472807)','4326'),'','Новая Майна',5867,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.603898193095084 54.218899494727253)','4326'),'','Димитровград',,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.469777292974548 54.204267694727413)','4326'),'','Кошки',7969,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.930843393049578 54.205065694727402)','4326'),'','Новая Малыкла',3273,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.292896393277573 54.972286594720011)','4326'),'','Буинск',20854,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.003333993317881 55.162865794718613)','4326'),'','Яльчики',2732,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.831667693202569 54.934310794720297)','4326'),'','Тетюши',11449,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.506861193247794 55.202671694718369)','4326'),'','Апастово',5306,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.944691293326045 55.680293394715811)','4326'),'','Урмары',6201,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.030207493174942 54.97474369471999)','4326'),'','Болгар',8542,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.361859793267968 55.863657894715146)','4326'),'','Волжск',54701,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.248423093283762 55.841476394715222)','4326'),'','Козловка',9335,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.016104993316112 55.971823894714824)','4326'),'','Звенигово',11681,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.509703093247403 55.847760494715189)','4326'),'','Зеленодольск',98462,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.52237519324563 55.799632394715367)','4326'),'','Нижние Вязовые',8060,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.320624593273706 56.154153394714442)','4326'),'','Красногорский',6400,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.722065393357028 56.117807694714529)','4326'),'','Мариинский Посад',8772,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.487034093389752 56.114002294714524)','4326'),'','Новочебоксарск',124869,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.787218193208759 53.958873294730402)','4326'),'','Сенгилей',6702,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.367122993267238 53.716112094733688)','4326'),'','Тереньга',,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.364277093267646 54.310759294726211)','4326'),'4','Ульяновск',619492,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.391654093263824 54.146409294728109)','4326'),'','Новоульяновск',,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.967855493322823 54.519563394724038)','4326'),'','Большое Нагаткино',5462,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.271084593280612 54.425076294724974)','4326'),'','Ишеевка',10618,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.705344693220155 54.341151494725906)','4326'),'','Октябрьский',5678,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.139935793298875 54.592244394723302)','4326'),'','Цильна',3902,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.925921593189457 54.607223494723172)','4326'),'','Старая Майна',6341,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (48.848997893200163 54.360060494725687)','4326'),'','Чердаклы',11482,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.3932799929852 53.493594994736895)','4326'),'','Красный Яр',7958,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.407573993122405 53.514949994736597)','4326'),'','Тольятти',710567,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (49.393366393124381 54.217322394727262)','4326'),'','Мулловка',,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.288917992999728 53.867003994731604)','4326'),'','Елховка',3268,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.200658593568811 55.940797594714908)','4326'),'','Ядрин',8691,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.013613993594852 56.129679194714484)','4326'),'','Васильсурск',1153,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.038911193452122 55.304300394717728)','4326'),'','Ибреси',7881,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.418672493538473 55.498516194716622)','4326'),'','Шумерля',30347,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (46.952900293464097 55.49170949471668)','4326'),'','Вурнары',9739,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.554750793380322 55.050496594719412)','4326'),'','Шыгырдан',5418,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.51650999338564 54.885476094720687)','4326'),'','Шемурша',4297,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.545599893381599 55.262265694717982)','4326'),'','Комсомольское',4905,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.604200693373443 55.068155894719276)','4326'),'','Батырево',5702,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.780588093348889 55.516373294716537)','4326'),'6','Янтиково',3151,'2019-02-13 15:00:00','4.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.506778193387007 55.511381794716591)','4326'),'','Канаш',,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.215658193427529 56.069402594714589)','4326'),'','Новые Лапсары',6955,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.473702993391605 55.866107194715141)','4326'),'','Цивильск',13708,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.244699393423488 56.130758394714498)','4326'),'5','Чебоксары',473895,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (47.298795593415946 56.031550194714683)','4326'),'','Кугеси',12143,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (103.927571285533162 57.138633494715407)','4326'),'','Новая Игирма',9496,'2019-02-13 15:00:00','9.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.446909892699331 54.599432394723237)','4326'),'','Лениногорск',63635,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (100.216963486049693 64.274195494887124)','4326'),'4','Тура',5562,'2019-02-13 15:00:00','8.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.54162599268615 54.091788994728759)','4326'),'','Северное',5800,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (102.734191985699283 57.959472994720137)','4326'),'4','Усть-Илимск',82455,'2019-02-13 15:00:00','9.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.235701592589528 54.403086594725224)','4326'),'','Бавлы',22114,'2019-02-13 15:00:00','4.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (102.77511598569356 57.908488994719761)','4326'),'','Железнодорожный',6463,'2019-02-13 15:00:00','9.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.587389092679778 54.69439769472234)','4326'),'','Карабаш',4955,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (105.746493685279972 56.78036709471445)','4326'),'','Усть-Кут',42272,'2019-02-13 15:00:00','9.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.802577492649817 54.81319609472132)','4326'),'','Актюбинский',9120,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (104.122939985505965 56.577914994714206)','4326'),'','Железногорск-Илимский',23643,'2019-02-13 15:00:00','9.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.795595292650795 54.538415194723832)','4326'),'','Бугульма',86747,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (111.491756184480224 65.951636294973781)','4326'),'4','Айхал',13962,'2019-02-13 15:00:00','10.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.224883992869437 55.061644694719341)','4326'),'','Новошешминск',4576,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (108.116294984950088 57.776355994718791)','4326'),'','Киренск',11310,'2019-02-13 15:00:00','9.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.805534492927812 54.846350994721014)','4326'),'','Аксубаево',9984,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.410158392843648 55.425502494717023)','4326'),'','Камские Поляны',15645,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (112.251729384374428 66.411767995000901)','4326'),'','Удачный',11835,'2019-02-13 15:00:00','10.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.636731092951308 55.37148309471732)','4326'),'','Чистополь',61110,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.897208692915051 56.186531794714398)','4326'),'','Кукмор',17694,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.005604692760762 55.286650894717809)','4326'),'','Заинск',41046,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.143556392880768 56.243501794714319)','4326'),'','Красная Поляна',6204,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.067265692891382 56.224041494714349)','4326'),'','Вятские Поляны',33053,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.816037592787147 55.64128789471598)','4326'),'8','Нижнекамск',235448,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.408903192843823 55.709075694715708)','4326'),'','Мамадыш',15528,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (90.685805987376426 56.951709994714825)','4326'),'','Новобирилюссы',4141,'2019-02-13 15:00:00','8.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.796481992233055 52.760974994749262)','4326'),'','Кумертау',61312,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (90.495396387402948 56.269484594714285)','4326'),'','Ачинск',105264,'2019-02-13 15:00:00','8.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.186482492317978 53.177197394741931)','4326'),'','Фёдоровка',4128,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (92.174816887169172 58.453221194724819)','4326'),'','Енисейск',17999,'2019-02-13 15:00:00','8.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.924640992215224 53.361686994738953)','4326'),'','Салават',153973,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (92.485969987125841 58.223510994722474)','4326'),'','Лесосибирск',59642,'2019-02-13 15:00:00','8.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.92861199221467 52.963279994745612)','4326'),'','Мелеуз',59064,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (93.138015987035075 56.909846994714712)','4326'),'','Большая Мурта',7888,'2019-02-13 15:00:00','8.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.165011992877773 53.941279994730642)','4326'),'','Сергиевск',8661,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (93.278567587015516 56.499874994714212)','4326'),'','Сухобузимское',4293,'2019-02-13 15:00:00','8.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.218028992870394 53.903327994731143)','4326'),'','Суходол',13525,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (95.221389986745081 56.838004994714559)','4326'),'','Дзержинское',7374,'2019-02-13 15:00:00','8.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.534872092826291 54.132514094728272)','4326'),'','Исаклы',4334,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (93.532859986980128 56.25093799471432)','4326'),'','Железногорск',84144,'2019-02-13 15:00:00','8.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.475465392834565 53.465446694737338)','4326'),'','Кинель-Черкассы',17252,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (93.281028987015176 57.694407994718219)','4326'),'','Казачинское',3627,'2019-02-13 15:00:00','8.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.081700092889363 54.419781694725046)','4326'),'','Челно-Вершины',5747,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (94.898597986790008 57.216041994715681)','4326'),'','Тасеево',8038,'2019-02-13 15:00:00','8.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.801957892928314 54.429735094724968)','4326'),'','Нурлат',33102,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (94.694297986818441 58.184207994722094)','4326'),'','Мотыгино',5323,'2019-02-13 15:00:00','8.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.027982992757643 54.258401994726803)','4326'),'','Клявлино',6967,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (93.031730987049869 58.080123994721149)','4326'),'','Стрелка',4792,'2019-02-13 15:00:00','8.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.46372129283619 54.437423194724872)','4326'),'','Шентала',6613,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (96.067763986627241 56.676669994714302)','4326'),'','Абан',9187,'2019-02-13 15:00:00','8.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.123343992744381 53.646796994734657)','4326'),'','Похвистнево',28140,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (93.032996987049685 60.374701994755945)','4326'),'4','Северо-Енисейский',6747,'2019-02-13 15:00:00','8.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.5053222928304 54.661101294722656)','4326'),'','Черемшан',5600,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (99.182914986193609 58.596328994726377)','4326'),'4','Кодинск',16312,'2019-02-13 15:00:00','8.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.144076992741482 54.112330994728509)','4326'),'','Камышла',4889,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (97.461577986433241 58.382815994724041)','4326'),'','Богучаны',11232,'2019-02-13 15:00:00','8.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.416999992703495 53.620799994735023)','4326'),'','Бугуруслан',49870,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (108.051398984959135 51.923121994766554)','4326'),'','Онохой',10890,'2019-02-13 15:00:00','9.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (108.270614984928613 51.834292994768589)','4326'),'','Заиграево',5362,'2019-02-13 15:00:00','9.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.879500992639116 52.919600994746354)','4326'),'6','Грачёвка',6100,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (107.635688985016984 52.201255994760437)','4326'),'','Турунтаево',5901,'2019-02-13 15:00:00','9.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.996371992344436 51.161288994785146)','4326'),'','Соль-Илецк',27279,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (108.854484984847346 51.275214994782189)','4326'),'','Петровск-Забайкальский',16524,'2019-02-13 15:00:00','10.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.207091992454309 51.874724994767661)','4326'),'','Переволоцкий',9600,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (109.032767984822513 53.408309994738197)','4326'),'','Усть-Баргузин',7061,'2019-02-13 15:00:00','9.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.097117992330425 51.767451994770113)','4326'),'4','Оренбург',561279,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (108.221999984935366 52.950694994745803)','4326'),'','Турка',1450,'2019-02-13 15:00:00','9.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.626479992256733 51.006438994789235)','4326'),'','Акбулак',13900,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (110.457974884624107 51.362843594779946)','4326'),'','Хилок',10724,'2019-02-13 15:00:00','10.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.333400992297527 51.984599994765162)','4326'),'','Сакмара',5000,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (109.913146984699949 51.849559994768228)','4326'),'','Кижинга',6373,'2019-02-13 15:00:00','9.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (111.538062984473768 52.528613994753734)','4326'),'','Сосново-Озёрское',6128,'2019-02-13 15:00:00','9.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.413417992425586 52.680560994750749)','4326'),'','Александровка',4000,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (109.779639984718557 52.161250994761296)','4326'),'','Хоринск',8241,'2019-02-13 15:00:00','9.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.653701992531346 52.081000994763052)','4326'),'6','Новосергиевка',13700,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (107.45262898504248 56.176497994714424)','4326'),'','Магистральный',6286,'2019-02-13 15:00:00','9.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.121264992466251 53.314845994739699)','4326'),'','Пономарёвка',5200,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (109.632743984738994 53.617637994735063)','4326'),'','Баргузин',5702,'2019-02-13 15:00:00','9.000000000000000',-22.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.487155292554519 52.848017094747654)','4326'),'','Плешаново',3500,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (109.571761984747511 55.783572994715406)','4326'),'','Нижнеангарск',4520,'2019-02-13 15:00:00','9.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.507575992273281 52.345225994757435)','4326'),'6','Октябрьское',7700,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (109.33564798478038 55.635966994716)','4326'),'','Северобайкальск',23673,'2019-02-13 15:00:00','9.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.74480099237946 52.927539994746219)','4326'),'','Шарлык',8300,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (111.730102984447029 56.146827994714457)','4326'),'','Новый Уоян',3351,'2019-02-13 15:00:00','9.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.834735992227742 52.703258994750357)','4326'),'','Ермолаево',6480,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (110.323256984642882 54.326335994726044)','4326'),'','Курумкан',5968,'2019-02-13 15:00:00','9.000000000000000',-24.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.161254992182293 52.342067994757471)','4326'),'','Тюльган',10200,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (105.517875985311775 53.067225994743787)','4326'),'','Баяндай',2669,'2019-02-13 15:00:00','9.000000000000000',-25.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.639090992811781 51.90234399476703)','4326'),'','Первомайский',6600,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (106.654319985153592 52.055407994763605)','4326'),'','Кабанск',6373,'2019-02-13 15:00:00','9.000000000000000',-17.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (102.515990985729644 53.566237994735829)','4326'),'','Залари',9576,'2019-02-13 15:00:00','9.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.383326992568982 51.527263994775865)','4326'),'','Илек',9700,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (106.404563985188346 52.799556994748542)','4326'),'','Еланцы',4027,'2019-02-13 15:00:00','9.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (102.178515785776639 54.112330094728499)','4326'),'','Саянск',38897,'2019-02-13 15:00:00','9.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.867850992919138 52.095469994762709)','4326'),'','Большая Черниговка',6356,'2019-02-13 15:00:00','4.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (102.052726985794152 53.928401994730798)','4326'),'','Зима',31229,'2019-02-13 15:00:00','9.000000000000000',-21.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.740146992658516 51.769164994770115)','4326'),'','Ташла',7100,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (103.054023985654766 54.006797994729816)','4326'),'','Балаганск',3909,'2019-02-13 15:00:00','9.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.163863992877928 52.80380999474847)','4326'),'','Нефтегорск',18358,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (101.506194985870238 54.344153994725872)','4326'),'','Куйтун',9487,'2019-02-13 15:00:00','9.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.273314992862687 52.583079994752644)','4326'),'','Алексеевка',4513,'2019-02-13 15:00:00','4.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (101.633490685852507 56.151708494714448)','4326'),'4','Братск',231602,'2019-02-13 15:00:00','9.000000000000000',-18.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.333106992854368 53.057624994743954)','4326'),'','Богатое',5922,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (103.028228985658359 54.174808994727762)','4326'),'','Усть-Уда',5144,'2019-02-13 15:00:00','9.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (50.633227992951795 53.21973799474123)','4326'),'','Кинель',34690,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (105.885146985260675 53.960818994730396)','4326'),'','Качуг',6950,'2019-02-13 15:00:00','9.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.348052992852296 53.376174994738719)','4326'),'','Отрадный',47593,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (105.152289985362671 54.812667994721309)','4326'),'','Жигалово',4983,'2019-02-13 15:00:00','9.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.69865799280349 53.0259249947445)','4326'),'','Борское',8953,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (107.357604985055701 51.483729994776937)','4326'),'','Тарбагатай',4308,'2019-02-13 15:00:00','9.000000000000000',-28.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.831740992645763 52.540389994753497)','4326'),'','Тоцкое Второе',10628,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (107.828536984990137 51.046996994788131)','4326'),'','Мухоршибирь',5162,'2019-02-13 15:00:00','9.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.748412992657364 52.530070994753686)','4326'),'','Тоцкое',7955,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (107.583910485024205 51.835784094768556)','4326'),'4','Улан-Удэ',431922,'2019-02-13 15:00:00','9.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.253898992726199 52.788501994748756)','4326'),'','Бузулук',85199,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (107.281173985066317 51.74505199477067)','4326'),'','Иволгинск',8251,'2019-02-13 15:00:00','9.000000000000000',-27.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.154174992600879 52.426970994755756)','4326'),'','Сорочинск',28367,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.410422992286804 55.836902994715231)','4326'),'','Бураево',10558,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.981875992207257 55.031142994719552)','4326'),'','Благовещенск',35037,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.923465992215384 56.00044299471476)','4326'),'','Старобалтачево',5601,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.047339992337342 55.987582994714806)','4326'),'','Краснохолмский',8325,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.385604992290261 54.589679994723319)','4326'),'','Чишмы',22008,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.013869992342002 54.691817994722371)','4326'),'','Языково',6477,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.947726992212019 54.726287994722036)','4326'),'4','Уфа',1110980,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.168818992181237 54.367450994725594)','4326'),'','Кармаскалы',9104,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.653658192392157 55.13847609471879)','4326'),'','Чекмагуш',11018,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.799040692511113 55.181191894718516)','4326'),'','Бакалы',10000,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.057727192475113 55.722179894715659)','4326'),'','Актаныш',8148,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.299230292441479 55.449059694716908)','4326'),'','Верхнеяркеево',9481,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.937420192491849 55.899275994715033)','4326'),'','Агидель',15616,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.705164992524182 56.010523194714729)','4326'),'','Каракулино',4724,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.261511292446741 56.099229994714555)','4326'),'','Нефтекамск',125915,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.170278692459434 56.128631194714494)','4326'),'','Николо-Берёзовка',6222,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.342200992296299 55.107123994719011)','4326'),'','Кушнаренково',9251,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.790097892373161 55.97011699471485)','4326'),'','Калтасы',4599,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.540717892268667 55.420677394717067)','4326'),'','Бирск',46132,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.86389499236288 55.490615994716677)','4326'),'','Дюртюли',30986,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.800921992371656 53.629291994734892)','4326'),'','Киргиз-Мияки',7473,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.268615992445753 53.693442994733985)','4326'),'','Бижбуляк',6446,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.791649592512144 54.420453294725043)','4326'),'','Серафимовский',10028,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.466006192557472 54.480972194724394)','4326'),'','Октябрьский',113626,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.697400392525253 54.606536994723179)','4326'),'','Туймазы',68340,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.466325892557421 54.599332394723248)','4326'),'','Уруссу',10577,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.001657392482905 54.818250894721253)','4326'),'','Шаран',5539,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.104853392468534 54.551987994723689)','4326'),'','Кандры',12448,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.2567249923082 53.438548994737744)','4326'),'','Стерлибашево',5775,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.532399292409025 54.569638894723511)','4326'),'','Буздяк',10450,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (116.533068483778464 50.385180794806821)','4326'),'','Борзя',28874,'2019-02-13 15:00:00','10.000000000000000',-26.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.043994992198613 53.454654994737488)','4326'),'','Ишимбай',65822,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (116.312911983809101 50.528159994802621)','4326'),'','Шерловая Гора',12132,'2019-02-13 15:00:00','10.000000000000000',-28.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.941627992352068 54.068694994729043)','4326'),'','Раевский',19517,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.952258992211384 53.632373994734856)','4326'),'','Стерлитамак',279692,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (117.329024983667665 49.644652994830018)','4326'),'','Забайкальск',13141,'2019-02-13 15:00:00','10.000000000000000',-19.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.026660992340219 54.218570994727273)','4326'),'','Давлеканово',23820,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (118.041343983568524 50.096991994815554)','4326'),'4','Краснокаменск',52811,'2019-02-13 15:00:00','10.000000000000000',-20.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (55.886462992220544 54.010341994729764)','4326'),'','Толбазы',10114,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.301484592719568 54.899649494720578)','4326'),'','Альметьевск',151157,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (51.819143992786721 55.682488794715788)','4326'),'','Красный Ключ',2821,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.588717592679593 55.252250094718057)','4326'),'','Сарманово',6352,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.423130692702642 54.862469594720885)','4326'),'','Нижняя Мактама',10059,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.738991992658676 55.021970994719616)','4326'),'','Джалиль',13442,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.079227492611309 54.862955494720865)','4326'),'8','Азнакаево',34720,'2019-02-13 15:00:00','4.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.053993792754021 55.757713094715506)','4326'),'','Елабуга',72929,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.194148192595314 55.305925494717712)','4326'),'','Муслюмово',7392,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.399217292705963 55.742011694715565)','4326'),'6','Набережные Челны',524444,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.308442992718604 55.887870594715061)','4326'),'','Менделеевск',22200,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.107181492607424 55.725558494715628)','4326'),'','Мензелинск',16952,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (52.475530892695346 56.184881194714393)','4326'),'','Алнаши',5990,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.65570099253106 53.682799994734147)','4326'),'','Абдулино',19353,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.482028992555236 53.511855994736621)','4326'),'','Матвеевка',3000,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (54.107810992468139 54.106494994728585)','4326'),'','Белебей',59204,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (53.931327992492704 53.893931994731268)','4326'),'','Приютово',19768,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.459281991862412 54.818255994721255)','4326'),'','Трёхгорный',32521,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.20578399189769 54.753478994721803)','4326'),'','Катав-Ивановск',16333,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.672141992111179 55.194285994718413)','4326'),'','Красная Горка',3980,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.640298191837189 54.789971794721488)','4326'),'','Трёхгорный-1',4500,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.548502091989171 55.070913894719254)','4326'),'','Миньяр',9342,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.285632992025768 54.989913994719863)','4326'),'','Аша',29946,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.685687791970082 54.989634194719891)','4326'),'','Сим',13365,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.578567992124185 56.085547994714581)','4326'),'','Аскино',6918,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.155066991904746 55.182555994718498)','4326'),'','Малояз',4914,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.15332399190499 54.924514994720376)','4326'),'','Усть-Катав',22536,'2019-02-13 15:00:00','6.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.427806991866795 54.870074994720831)','4326'),'','Юрюзань',11908,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.239238991893032 55.534694994716467)','4326'),'','Месягутово',9761,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.028033991783232 55.040286994719494)','4326'),'','Сатка',42437,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.810248991813545 54.936656994720288)','4326'),'','Бакал',19942,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.268699991888923 55.952189994714871)','4326'),'','Большеустьикинское',7557,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.603152991842379 55.406959994717127)','4326'),'','Верхние Киги',8072,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.940234991656247 51.520965994776027)','4326'),'6','Адамовка',7700,'2019-02-13 15:00:00','6.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.873267991665585 51.036956994788419)','4326'),'','Ясный',15674,'2019-02-13 15:00:00','6.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.722304991686585 52.084140994762983)','4326'),'','Кваркено',3900,'2019-02-13 15:00:00','6.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.850287991529562 50.820312994794307)','4326'),'6','Светлый',8000,'2019-02-13 15:00:00','6.000000000000000',-13.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.134913991768357 53.296946994739983)','4326'),'','Агаповка',6561,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.331225991601819 52.425406994755797)','4326'),'','Бреды',9468,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.63917199155896 53.053260994744036)','4326'),'','Карталы',28703,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.614516991562375 53.042560994744221)','4326'),'','Локомотивный',8522,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.470560392139227 53.896161594731232)','4326'),'','Красноусольский',12421,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (60.978362591511733 53.377581894738682)','4326'),'','Варна',9869,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.409980992147673 54.823749994721197)','4326'),'','Иглино',14784,'2019-02-13 15:00:00','6.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.784121992095592 54.4057239947252)','4326'),'','Архангельское',5819,'2019-02-13 15:00:00','6.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.961493491931691 54.234353194727071)','4326'),'','Межгорье',16019,'2019-02-13 15:00:00','6.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.409954891869262 53.968070494730298)','4326'),'','Белорецк',66171,'2019-02-13 15:00:00','6.000000000000000',-3.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.350795992016707 51.47875599477706)','4326'),'','Кувандык',24715,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.358512992154843 51.787223994769668)','4326'),'','Саракташ',17200,'2019-02-13 15:00:00','6.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.298526991884778 51.196368994784208)','4326'),'','Новотроицк',89905,'2019-02-13 15:00:00','6.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.58031379198475 51.404943494778898)','4326'),'','Медногорск',26174,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.440516991865017 51.471442994777256)','4326'),'','Гай',36092,'2019-02-13 15:00:00','6.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.473801491860385 51.230501494783333)','4326'),'','Орск',231104,'2019-02-13 15:00:00','6.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.441546992004071 52.233706994759764)','4326'),'','Зилаир',5861,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.985720691789119 51.38128969477949)','4326'),'','Новоорск',11295,'2019-02-13 15:00:00','6.000000000000000',-15.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.307559991883522 52.597918994752362)','4326'),'','Баймак',17475,'2019-02-13 15:00:00','6.000000000000000',-9.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (57.432867692005281 53.103463294743172)','4326'),'','Старосубхангулово',4872,'2019-02-13 15:00:00','6.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.893695991801927 52.725539994749937)','4326'),'','Кизильское',6651,'2019-02-13 15:00:00','6.000000000000000',-12.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.665465991833713 52.720424994750033)','4326'),'','Сибай',61534,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.983135991789489 53.424218394737977)','4326'),'5','Магнитогорск',419100,'2019-02-13 15:00:00','6.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (58.506054791855888 53.339106194739308)','4326'),'','Аскарово',7634,'2019-02-13 15:00:00','6.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.86751599166638 51.025271994788746)','4326'),'','Комаровский',8050,'2019-02-13 15:00:00','6.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (59.536776991712408 50.760066994796006)','4326'),'','Домбаровский',8600,'2019-02-13 15:00:00','6.000000000000000',-14.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (56.40954199214773 51.398890994779052)','4326'),'6','Беляевка',5000,'2019-02-13 15:00:00','6.000000000000000',-11.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.268184995229831 62.209289994805893)','4326'),'','Кондопога',31501,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (43.171481993990483 61.090484994773028)','4326'),'','Октябрьский',9137,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.310686795223916 63.74350869486365)','4326'),'','Сегежа',27813,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.473338995201274 62.915023994830605)','4326'),'','Медвежьегорск',14647,'2019-02-13 15:00:00','4.000000000000000',-6.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.266010895230131 63.892404694870066)','4326'),'','Надвоицы',7964,'2019-02-13 15:00:00','4.000000000000000',-7.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (38.094821994697163 63.911643994870879)','4326'),'','Онега',20051,'2019-02-13 15:00:00','4.000000000000000',-8.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.293296994391127 62.709136994823055)','4326'),'','Плесецк',10421,'2019-02-13 15:00:00','4.000000000000000',-1.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (34.337601895220175 66.678033895017279)','4326'),'','Умба',4908,'2019-02-13 15:00:00','4.000000000000000',-10.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.136100994413006 62.934218994831312)','4326'),'','Савинский',7127,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.328643994386198 62.762351994824996)','4326'),'4','Мирный',32066,'2019-02-13 15:00:00','4.000000000000000',-2.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.823768994456479 64.563384994900687)','4326'),'','Северодвинск',186172,'2019-02-13 15:00:00','4.000000000000000',-5.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (39.893275994446817 59.218875994734695)','4326'),'4','Вологда',311166,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (44.311274993831816 58.825496994729185)','4326'),'','Кологрив',3080,'2019-02-13 15:00:00','4.000000000000000',-4.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.340583994384545 59.501475194739172)','4326'),'','Кадников',4642,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (119.090133983422504 50.365901994807388)','4326'),'','Приаргунск',7283,'2019-02-13 15:00:00','10.000000000000000',-23.00000000,0.00000000,0.00000000,93.00000000) ;
INSERT INTO is_grib.grib_towns_odkb_weather (shape,admin_leve,name,population,time_data,time_zone,temper,rain,snow,cloud) 
VALUES (ST_GeomFromText('POINT (40.112857994416252 59.462798994738542)','4326'),'','Сокол',37562,'2019-02-13 15:00:00','4.000000000000000',0.00000000,0.00000000,0.00000000,93.00000000) ;
