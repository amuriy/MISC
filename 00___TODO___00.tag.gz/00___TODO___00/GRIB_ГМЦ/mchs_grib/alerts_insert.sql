delete 
from public.object_attr
where objectid in
(
select 
objectid
from
is_grib.hazard_regions
)
;


INSERT INTO public.object_attr
(
  id,              -- Уникальный идентификатор записи атрибута (объекта данных)
  objectid,        -- Уникальный идентификатор пространственных данных объекта в системе, с которым связана эта запись данных атрибутов
  type_id,         -- Идентификатор тип атрибута по справочнику атрибутов (VIEW type_attr, словарь системы с dictionar.parent_id = 1000000039)
  name_type,       -- Имя формата значения данных (типа данных СУБД) из справочника (VIEW type_name, словарь системы с dictionar.parent_id = 1000000009)
  d_timestamptz,   -- значения данных - дата-время с учетом врем.зоны (timestamp with time zone)
  d_text           -- текстовые значения данных
)
SELECT
    public.uuid_generate_v1() as id,
    hr.objectid,
    1000000943 as type_id,
    'text' as name_type,
    now() as d_timestamptz,
    hr.name || ': ' || paa10.date_trunc::date || ' - прогнозируется превышение критического уровня осадков' as d_text
FROM
    is_grib.hazard_regions_with_avg paa10, is_grib.hazard_regions hr
WHERE
        paa10.date_trunc::date >= now()::date
  AND paa10.calc_precip_level_accum >= paa10.precip_level_accum
    AND    paa10.hazard_region_id = hr.objectid
;




-- SELECT
--     public.uuid_generate_v1() as id,
--     hr.objectid,
--     1000000943 as type_id,
--     'text' as name_type,
--     now() as d_timestamptz, 
--     hr.name || ': ' || paa10.date_trunc::date || ' - прогнозируется превышение критического уровня осадков' as d_text
-- FROM
--     is_grib.precip_avg_accum10days paa10, is_grib.hazard_regions hr,
--     (select value_int from public.dictionar where id = '1000012819') AS crit
-- WHERE
--         paa10.date_trunc::date = now()::date
--     AND    paa10.avg >= crit.value_int
--     AND    paa10.hazard_region_id = hr.objectid
--     AND    paa10.archive IS FALSE
-- ;

