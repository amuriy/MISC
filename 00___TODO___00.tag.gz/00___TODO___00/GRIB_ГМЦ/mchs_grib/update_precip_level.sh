#!/bin/sh

#Создаем временные директории
mkdir -p tmp/shp
mkdir -p tmp/tif

#Получаем список тифов из базы:                                     запрос                          обрезаем последнюю строку и пихаем в файл
psql "dbname='bpd_postgis_dev' user='bpd_owner' password='Prime#52' host='172.24.2.192'" -t -c 'SELECT location FROM is_grib.grib_precip_time_index' | sed '/^$/d' > tmp/list_tif.txt
#Получаем список регионов из базы:
psql "dbname='bpd_postgis_dev' user='bpd_owner' password='Prime#52' host='172.24.2.192'" -t -c 'SELECT objectid FROM is_grib.hazard_regions' | sed '/^$/d' > tmp/list_hazard.txt

#Получаем полигоны из базы
while read polygon; do
    pol_name=$polygon

    ogr2ogr -f "ESRi Shapefile" tmp/shp/${pol_name}.shp -lco ENCODING=UTF-8 PG:"dbname='bpd_postgis_dev' user='bpd_owner' password='Prime#52' host='172.24.2.192'" -sql "SELECT shape,name from is_grib.hazard_regions WHERE objectid::varchar='${pol_name}';"

        #Читаем файл со списком растров
        while read LINE; do

        cut_name=$(echo "$LINE" | sed 's/^.*\(.\{26\}\)$/\1/')

        #Обрезаем растры по вектору
        gdalwarp -srcnodata 0 -cutline tmp/shp/${pol_name}.shp $LINE tmp/tif/${pol_name}_${cut_name} -crop_to_cutline -overwrite -dstalpha>/dev/null 2>&1
        #считаем статистику
        stat_res=$(gdalinfo -stats tmp/tif/${pol_name}_${cut_name} | grep 'STATISTICS_MEAN' | cut -d'=' -f2 | head -n1 | sed 's/32767/0/')

        #убираем лишнее из названия тифа, оставляем только цифры  вставляем пробел в число и добавляем нули
        echo ${pol_name}";"$(echo "$cut_name" | sed -e 's/^.*\(.\{14\}\)$/\1/;s/.tif//g;s/^\(........\)/\1 /;s/$/0000/')";"${stat_res}>> tmp/temp.txt

        done < tmp/list_tif.txt

    done < tmp/list_hazard.txt

#записываем заголовок файла
#sed -i '1i hazard_region_id;time_data;value' temp.txt
set_false='FALSE'
#формируем sql
cat tmp/temp.txt | while read data; do
    hazard_region=$(echo $data | cut -d';' -f1 | sed 's+"++g')
    time_data=$(echo $data | cut -d';' -f2 | sed 's+"++g')
    value=$(echo $data | cut -d';' -f3 | sed 's+"++g')
    echo "UPDATE is_grib.precip_level SET value = '$value' WHERE time_data='$time_data' AND hazard_region_id='$hazard_region';" >> tmp/update.sql
    echo "INSERT INTO is_grib.precip_level (hazard_region_id,time_data,value,archive) SELECT '$hazard_region','$time_data','$value','$set_false' WHERE NOT EXISTS (select time_data from is_grib.precip_level where time_data='$time_data' AND hazard_region_id='$hazard_region');" >> tmp/insert.sql
done

#Пишем его в базу
psql "dbname='bpd_postgis_dev' user='bpd_owner' password='Prime#52' host='172.24.2.192'" --file=tmp/update.sql
psql "dbname='bpd_postgis_dev' user='bpd_owner' password='Prime#52' host='172.24.2.192'" --file=tmp/insert.sql
psql "dbname='bpd_postgis_dev' user='bpd_owner' password='Prime#52' host='172.24.2.192'" -c 'UPDATE is_grib.precip_level SET archive=TRUE WHERE time_data<now();'

#Очищаем папку
rm -R tmp/
