#!/bin/sh

####!!! EDIT !!! ####
bin_dir='/gip/tools/mchs_grib'
dload_dir='/gip/tools/mchs_grib/grib'
tif_dir='/gip/tools/mchs_grib/tif_wind'
####!!! EDIT !!! ####

cd $bin_dir

if [ ! -d "$tif_dir" ]; then
    mkdir -p $tif_dir
else
    find $tif_dir -type f -exec rm -f "{}" \;
fi

## processing wind data
ls $dload_dir/gfs.* | awk 'NR%2==0' | while read file; do
    echo Processing file from wind $(date): "$file" >> grib_update.log 2>&1
    $bin_dir/grib_proc2.sh $file $tif_dir
done


pg_dump -Fc --data-only --blobs --host 172.24.2.192 --port 5432 --username "bpd_owner" --no-password --verbose  --table is_grib.grib_wind_speed_dir2 -d "bpd_postgis_dev" --file /tmp/grib_wind_speed_dir2.backup > /dev/null 2>&1
psql "dbname='bpd_postgis_dmz' user='bpd_owner' password='Prime#52' host='172.24.2.192'" -t -c 'TRUNCATE TABLE is_grib.grib_wind_speed_dir2 RESTART IDENTITY;' > /dev/null 2>&1
pg_restore --host 172.24.2.192 --port 5432 --username "bpd_owner" -d "bpd_postgis_dmz" --no-password --verbose /tmp/grib_wind_speed_dir2.backup
rm -f /tmp/grib_wind_speed_dir2.backup

