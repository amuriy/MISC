﻿DO $$
DECLARE
    tables CURSOR FOR
       SELECT tablename
       FROM pg_tables
       WHERE schemaname = 'is_grib'
       AND tablename LIKE 'grib%_index';
       -- or tablename LIKE 'grib_precip_time%'                                                                                                                                                                                 
       -- and tablename not like 'grib_towns%'                                                                                                                                                                                  
       -- and tablename not like 'grib_wind_speed%';                                                                                                                                                                            
BEGIN
    FOR table_record IN tables LOOP
    EXECUTE 'DELETE FROM ' || '"is_grib".' || '"' || table_record.tablename || '" WHERE time_data < (now() - ''10 days''::interval);' ;
    END LOOP;
END$$;





