#!/bin/sh

rm -f /tmp/tifs*

ogrinfo -ro PG:"dbname='bpd_postgis_dev' user='bpd_owner' password='Prime#52' host='172.24.2.192'" \
    | grep 'is_grib.grib_' | grep 'index' | cut -d' ' -f2 \
    | while read tbl; do
    export PGPASSWORD='bpd_reader@123'
    echo "select location from $tbl" | psql --host=172.24.2.192 --username=bpd_reader --dbname=bpd_postgis_dev \
	| grep 'gip' | sed 's/ //g' >> /tmp/tifs_db

done

cat /tmp/tifs_db | sort | uniq > /tmp/tifs_db_list
find /gip/data/grib/ -maxdepth 1 -name "*.tif" | sort | uniq > /tmp/tifs_file_list

grep -Fxvf /tmp/tifs_db_list /tmp/tifs_file_list > /tmp/tifs_list_todel
perl -lne 'unlink' /tmp/tifs_list_todel 











