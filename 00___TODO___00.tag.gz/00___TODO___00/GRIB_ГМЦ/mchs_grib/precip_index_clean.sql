delete
from
	IS_GRIB.GRIB_PRECIP_TIME_INDEX
where
	time_data in
(	
select
	time_data
FROM 
     IS_GRIB.GRIB_PRECIP_TIME_INDEX
GROUP by
      time_data
HAVING count(*) > 1 
) 
  and location like '%apcp12%'
;



delete
from
	IS_GRIB.GRIB_PRECIP_TIME_INDEX
where
	location like '%apcp12%' 
	and (time_data::text like '%09:00:00%' 
	or time_data::text like '%21:00:00%')
	;