#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pandas as pd
import codecs
import geocoder
import sys

coor_list = []

infile = sys.argv[1]
outfile = sys.argv[2]

with open('%s' % infile, 'rb') as f:
    df = pd.read_csv(f, sep='\t', header=0)

    # select address field in CSV file ("number of column - 1")
    addr_col = df.iloc[:, 2]
    for addr in addr_col:
        print addr
        coor = geocoder.yandex('%s' % addr)
        if not coor:
            coor = geocoder.google('%s' % addr)
        coor_latlng2 = []        
        for row in coor.latlng:
            coor_latlng2.append(str(row))
        print coor_latlng2
        coor_list.append(coor_latlng2)
        
    se = pd.Series(coor_list)
    df['X'] = se.values
    
    df.to_csv('%s' % outfile, sep='\t')
    

