#!/bin/sh

rm -f .TMP_*

cat $1 | sed -e 's/\[//g' -e 's/\]//g' -e "s/'//g" -e 's/,//g' | sed '1d' > .TMP_cl
cat .TMP_cl | awk -F'\t' 'BEGIN{FS="\t";OFS="\t"} {$NF=""; print $0}' > .TMP_cl2
cat .TMP_cl | awk -F'\t' '{print $(NF)}' > .TMP_coords
awk -F' ' '{print $1}' .TMP_coords > .TMP_coord_N.txt
awk -F' ' '{print $2}' .TMP_coords | sed 's/ //g' > .TMP_coord_E.txt
paste .TMP_cl2 .TMP_coord_N.txt .TMP_coord_E.txt > $2

rm -f .TMP_*
