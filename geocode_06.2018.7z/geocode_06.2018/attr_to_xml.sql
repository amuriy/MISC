﻿INSERT INTO "IS_0028"."geoMultyPoint"
(id, name, class_id, attributes, shape)
select 
  field_1 as id,
  field_2 as name,
  '133041500000',
  
     XMLPARSE (CONTENT '<attributes>'

  ||   case when field_2 is null then '' else '<attribute name="field_2" alias="Наименование" type="String">' || field_2 || '</attribute>' end
  ||   case when field_3 is null then '' else '<attribute name="field_3" alias="Структура" type="String">' || field_3 || '</attribute>' end
  ||   case when field_4 is null then '' else '<attribute name="field_4" alias="Адрес (место дислокации)" type="String">' || field_4 || '</attribute>' end
  ||   case when field_5 is null then '' else '<attribute name="field_5" alias="Деж. телефон" type="String">' || field_5 || '</attribute>' end
  ||   case when field_6 is null then '' else '<attribute name="field_6" alias="Руководитель" type="String">' || field_6 || '</attribute>' end
  ||   '</attributes>') as attributes,

  ST_Multi(shape) as shape

from "IS_STUFF".obj_geocoded
;