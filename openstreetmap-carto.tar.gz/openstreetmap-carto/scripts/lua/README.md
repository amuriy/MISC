# Lua helper scripts #

These scripts are for developing, testing, and profiling the [Lua tag transform](../../openstreetmap-carto.lua). There is a symlink to the transform in this directory so it can be `require`d by other files.

They are not necessary for map rendering or most development.
